function [pks idx varargout] = findpeaks (data, varargin)

  if (nargin < 1)
    print_usage ();
  endif

  if (! (isvector (data) && numel (data) >= 3))
    error ("findpeaks:InvalidArgument",
           "findpeaks: DATA must be a vector of at least 3 elements");
  endif

  transpose = (rows (data) == 1);

  if (transpose)
    data = data.';
  endif

  ## --- Parse arguments --- #
  __data__ = abs (detrend (data, 0));

  posscal = @(x) isscalar (x) && x >= 0;

  parser = inputParser ();
  parser.FunctionName = "findpeaks";

  ## FIXME: inputParser was first implemented in the general package in the
  ##        old @class type.  This allowed for a very similar interface to
  ##        Matlab but not quite equal.  classdef was then implemented in
  ##        Octave 4.0 release, which enabled inputParser to be implemented
  ##        properly.  However, this causes problem because we don't know
  ##        what implementation may be running.  A new version of the general
  ##        package is being released to avoid the two implementations to
  ##        co-exist.
  ##
  ##        To keep supporting older octave versions, we have an alternative
  ##        path that avoids inputParser.  And if inputParser is available,
  ##        we check what implementation is is, and act accordingly.

  ## Note that in Octave 4.0, inputParser is classdef and Octave behaves
  ## weird for it. which ("inputParser") will return empty (thinks its a
  ## builtin function).
  if (exist ("inputParser") == 2
      && isempty (strfind (which ("inputParser"),
                           ["@inputParser" filesep "inputParser.m"])))
    ## making use of classdef's inputParser ..
    parser.addParamValue ("MinPeakHeight", 2*std (__data__),posscal);
    parser.addParamValue ("MinPeakDistance", 4, posscal);
    parser.addParamValue ("MinPeakWidth", 2, posscal);
    parser.addSwitch ("DoubleSided");
    parser.parse (varargin{:});
    minH      = parser.Results.MinPeakHeight;
    minD      = parser.Results.MinPeakDistance;
    minW      = parser.Results.MinPeakWidth;
    dSided    = parser.Results.DoubleSided;
  else
    ## either old @inputParser or no inputParser at all...
    lvarargin = lower (varargin);

    ds = strcmpi (lvarargin, "DoubleSided");
    if (any (ds))
      dSided = true;
      lvarargin(ds) = [];
    else
      dSided = false;
    endif

    [~, minH, minD, minW] = parseparams (lvarargin,
                                         "minpeakheight", 2 * std (__data__),
                                         "minpeakdistance", 4,
                                         "minpeakwidth", 2);
    if (! posscal (minH))
      error ("findpeaks: MinPeakHeight must be a positive scalar");
    elseif (! posscal (minD))
      error ("findpeaks: MinPeakDistance must be a positive scalar");
    elseif (! posscal (minW))
      error ("findpeaks: MinPeakWidth must be a positive scalar");
    endif
  endif


  if (dSided)
    [data, __data__] = deal (__data__, data);
  elseif (min (data) < 0)
    error ("findpeaks:InvalidArgument",
           'Data contains negative values. You may want to "DoubleSided" option');
  endif

  ## Rough estimates of first and second derivative
  df1 = diff (data, 1)([1; (1:end)']);
  df2 = diff (data, 2)([1; 1; (1:end)']);

  ## check for changes of sign of 1st derivative and negativity of 2nd
  ## derivative.
  ## <= in 1st derivative includes the case of oversampled signals.
  idx = find (df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0);

  ## Get peaks that are beyond given height
  tf  = data(idx) > minH;
  idx = idx(tf);

  ## sort according to magnitude
  [~, tmp] = sort (data(idx), "descend");
  idx_s = idx(tmp);

  ## Treat peaks separated less than minD as one
  D = abs (bsxfun (@minus, idx_s, idx_s'));
  if (any (D(:) < minD))

    i = 1;
    peak = cell ();
    node2visit = 1:size(D,1);
    visited = [];
    idx_pruned = idx_s;

    ## debug
##    h = plot(1:length(data),data,"-",idx_s,data(idx_s),'.r',idx_s,data(idx_s),'.g');
##    set(h(3),"visible","off");

    while (! isempty (node2visit))

      d = D(node2visit(1),:);

      visited = [visited node2visit(1)];
      node2visit(1) = [];

      neighs  = setdiff (find (d < minD), visited);
      if (! isempty (neighs))
        ## debug
##        set(h(3),"xdata",idx_s(neighs),"ydata",data(idx_s(neighs)),"visible","on")
##        pause(0.2)
##        set(h(3),"visible","off");

        idx_pruned = setdiff (idx_pruned, idx_s(neighs));

        visited    = [visited neighs];
        node2visit = setdiff (node2visit, visited);

        ## debug
##        set(h(2),"xdata",idx_pruned,"ydata",data(idx_pruned))
##        pause
      endif

    endwhile
    idx = idx_pruned;
  endif

  extra = struct ("parabol", [], "height", [], "baseline", [], "roots", []);

  ## Estimate widths of peaks and filter for:
  ## width smaller than given.
  ## wrong concavity.
  ## not high enough
  ## data at peak is lower than parabola by 1%
  if (minW > 0)
    ## debug
##    h = plot(1:length(data),data,"-",idx,data(idx),'.r',...
##          idx,data(idx),'og',idx,data(idx),'-m');
##    set(h(4),"linewidth",2)
##    set(h(3:4),"visible","off");

    idx_pruned = idx;
    n  = numel (idx);
    np = numel (data);
    struct_count = 0;
    for i=1:n
      ind = (round (max(idx(i)-minD/2,1)) : ...
             round (min(idx(i)+minD/2,np)))';
      pp = polyfit (ind, data(ind), 2);
      H  = pp(3) - pp(2)^2/(4*pp(1));

      ## debug
##      x = linspace(ind(1)-1,ind(end)+1,10);
##      set(h(4),"xdata",x,"ydata",polyval(pp,x),"visible","on")
##      set(h(3),"xdata",ind,"ydata",data(ind),"visible","on")
##      pause(0.2)
##      set(h(3:4),"visible","off");

      rz = roots ([pp(1:2) pp(3)-mean([H,minH])]);
      width = abs (diff (rz));
      if (width < minW || pp(1) > 0 || H < minH || data(idx(i)) < 0.99*H)
        idx_pruned = setdiff (idx_pruned, idx(i));
      elseif (nargout > 2)
        struct_count++;
        extra.parabol(struct_count).x  = ind([1 end]);
        extra.parabol(struct_count).pp = pp;

        extra.roots(struct_count,1:2)= rz;
        extra.height(struct_count)   = H;
        extra.baseline(struct_count) = mean ([H minH]);
      endif

      ## debug
##      set(h(2),"xdata",idx_pruned,"ydata",data(idx_pruned))
##      pause(0.2)

    endfor
    idx = idx_pruned;
  endif


  if (dSided)
    pks = __data__(idx);
  else
    pks = data(idx);
  endif

  if (transpose)
    pks = pks.';
    idx = idx.';
  endif

  if (nargout() > 2)
    varargout{1} = extra;
  endif

endfunction

///////////////////////////////////////////////////////////////////////////////

data = [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];
y = data - ones(10,1)*mean(data);
__data__ = abs(y)

[data, __data__] = deal (__data__, data);
df1 = diff (data, 1)([1; (1:end)']);
df2 = diff (data, 2)([1; 1; (1:end)']);
idx = find (df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0);

diff(data, 1) = diff(data)
diff (data, 2) = diff(diff (data, 1))
([1; (1:end)']) => create column vector with row 0 is first value & column value
([1; 1; (1:end)']) => create column vector with row 0 & row 1 is first value & column value

df1
  -1  
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   1 

diff(data, 2)
   0                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   0

df2
   0                                                                                                
   0 
   0                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   0

idx = find (df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0);
[df1(2:end); 0] => column vector with df1 value 2->end & append 0 value
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   0
df1.*[df1(2:end); 0] => create vector with dot element.   
   1                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   0

[df2(2:end); 0]
   0                                                                                                
   0                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   0                                                                                                
   0
df1.*[df1(2:end); 0] <= 0 => create vector with boolean value for value <= 0
[df2(2:end); 0] < 0 => create vector with boolean value for value < 0
df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0 => & logic each element and return vector with value is index for element has logic true
=> idx: vector with index of value has logic true [5 6 10]

tf  = data(idx) > minH; => filter data by index > minH, return vector with boolean value for this condition. [0 0 1]
idx = idx(tf); => filter index that has boolean is true (return vector with value is index that boolean is true) [10]

## sort according to magnitude
  [~, tmp] = sort (data(idx), "descend"); => sort descend data by idx and return vector index after sorted [3 1 2]
  idx_s = idx(tmp); => arrange idx value by sorted index [10 5 6]

## Treat peaks separated less than minD as one
D = abs (bsxfun (@minus, idx_s, idx_s'));           //'

[10; 5; 6] - [10 5 6]
0   5   4
-5  0   -1
-4  1   0
Mat(3,3);
for i=0; i<3; i++
  for j=0; j<3; j++
    a[i][j] = v[i]-v[j]

##
if (any (D(:) < minD)) => exist any element < minD
peak = cell (); => create array empty
node2visit = 1:size(D,1); => return vector with value from 1->size of D (1,2,3)
d = D(node2visit(1),:); => d is first row of D
visited = [visited node2visit(1)]; => append node2visit(1) to visited
node2visit(1) = []; => remove node2visit(1) on node2visit => [2, 3]
neighs  = setdiff (find (d < minD), visited); => find index d < minD, filter data in result and not in visited, then sort results
% C = setdiff(A,B) returns the data in A that is not in B, with no repetitions. C is in sorted order. (ascend)
idx_pruned = setdiff (idx_pruned, idx_s(neighs)); => idx_s(neighs): return vector by index on neighs
visited    = [visited neighs]; => append neighs to visited
node2visit = setdiff (node2visit, visited);
n  = numel (idx); => number of element in array

ind = (round (max(idx(i)-minD/2,1)) : ...
             round (min(idx(i)+minD/2,np)))';   '=> vector value from min -> max

pp = polyfit (ind, data(ind), 2);   => get polyfit vector
H  = pp(3) - pp(2)^2/(4*pp(1));

rz = roots ([pp(1:2) pp(3)-mean([H,minH])]);
[pp(1:2) pp(3)-mean([3,0.1])] => vector {pp(1), pp(2), pp(3)-mean([3,0.1])}
=> vector with roots

width = abs (diff (rz));
if (width < minW || pp(1) > 0 || H < minH || data(idx(i)) < 0.99*H)
        idx_pruned = setdiff (idx_pruned, idx(i));

==============================================
  template<class T> inline
    Vec<T> Vec<T>::detrend(void)
    {
        Vec<T> temp(datasize);
        T meanVal = mean();
        for (int i=0; i<datasize; i++) {
            temp[i] = data[i] - meanVal;
        }
        return temp;
    }
==============================================

%! #----------------------------------------------------------------------------

https://www.jdoodle.com/execute-octave-matlab-online
http://cpp.sh/

%! #----------------------------------------------------------------------------
function p = fPolyFit(x, y, n)
% Construct Vandermonde matrix:
x = x(:);
V = ones(length(x), n + 1);
for j = n:-1:1
   V(:, j) = V(:, j + 1) .* x;
end
% Solve least squares problem:
[Q, R] = qr(V, 0);
p      = transpose(R \ (transpose(Q) * y(:)));
endfunction

%! #----------------------------------------------------------------------------
http://www.bragitoff.com/2015/09/c-program-for-polynomial-fit-least-squares/
%! #----------------------------------------------------------------------------
//Polynomial Fit
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main()
{
    int i,j,k,n,N;
    cout.precision(4);                        //set precision
    cout.setf(ios::fixed);
    cout<<"\nEnter the no. of data pairs to be entered:\n";        //To find the size of arrays that will store x,y, and z values
    cin>>N;
    double x[N],y[N];
    cout<<"\nEnter the x-axis values:\n";                //Input x-values
    for (i=0;i<N;i++)
        cin>>x[i];
    cout<<"\nEnter the y-axis values:\n";                //Input y-values
    for (i=0;i<N;i++)
        cin>>y[i];
    cout<<"\nWhat degree of Polynomial do you want to use for the fit?\n";
    cin>>n;                                // n is the degree of Polynomial 
    double X[2*n+1];                        //Array that will store the values of sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
    for (i=0;i<2*n+1;i++)
    {
        X[i]=0;
        for (j=0;j<N;j++)
            X[i]=X[i]+pow(x[j],i);        //consecutive positions of the array will store N,sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
    }
    double B[n+1][n+2],a[n+1];            //B is the Normal matrix(augmented) that will store the equations, 'a' is for value of the final coefficients
    for (i=0;i<=n;i++)
        for (j=0;j<=n;j++)
            B[i][j]=X[i+j];            //Build the Normal matrix by storing the corresponding coefficients at the right positions except the last column of the matrix
    double Y[n+1];                    //Array to store the values of sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
    for (i=0;i<n+1;i++)
    {    
        Y[i]=0;
        for (j=0;j<N;j++)
        Y[i]=Y[i]+pow(x[j],i)*y[j];        //consecutive positions will store sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
    }
    for (i=0;i<=n;i++)
        B[i][n+1]=Y[i];                //load the values of Y as the last column of B(Normal Matrix but augmented)
    n=n+1;                //n is made n+1 because the Gaussian Elimination part below was for n equations, but here n is the degree of polynomial and for n degree we get n+1 equations
    cout<<"\nThe Normal(Augmented Matrix) is as follows:\n";    
    for (i=0;i<n;i++)            //print the Normal-augmented matrix
    {
        for (j=0;j<=n;j++)
            cout<<B[i][j]<<setw(16);
        cout<<"\n";
    }    
    for (i=0;i<n;i++)                    //From now Gaussian Elimination starts(can be ignored) to solve the set of linear equations (Pivotisation)
        for (k=i+1;k<n;k++)
            if (B[i][i]<B[k][i])
                for (j=0;j<=n;j++)
                {
                    double temp=B[i][j];
                    B[i][j]=B[k][j];
                    B[k][j]=temp;
                }
    
    for (i=0;i<n-1;i++)            //loop to perform the gauss elimination
        for (k=i+1;k<n;k++)
            {
                double t=B[k][i]/B[i][i];
                for (j=0;j<=n;j++)
                    B[k][j]=B[k][j]-t*B[i][j];    //make the elements below the pivot elements equal to zero or elimnate the variables
            }
    for (i=n-1;i>=0;i--)                //back-substitution
    {                        //x is an array whose values correspond to the values of x,y,z..
        a[i]=B[i][n];                //make the variable to be calculated equal to the rhs of the last equation
        for (j=0;j<n;j++)
            if (j!=i)            //then subtract all the lhs values except the coefficient of the variable whose value                                   is being calculated
                a[i]=a[i]-B[i][j]*a[j];
        a[i]=a[i]/B[i][i];            //now finally divide the rhs by the coefficient of the variable to be calculated
    }
    cout<<"\nThe values of the coefficients are as follows:\n";
    for (i=0;i<n;i++)
        cout<<"x^"<<i<<"="<<a[i]<<endl;            // Print the values of x^0,x^1,x^2,x^3,....

    cout<<"\nHence the fitted Polynomial is given by:\ny=";
    for (i=0;i<n;i++)
        cout<<" + ("<<a[i]<<")"<<"x^"<<i;
    cout<<"\n";
    return 0;
}//output attached as .jpg

%! #----------------------------------------------------------------------------
https://www.programiz.com/cpp-programming/examples/quadratic-roots
%! #----------------------------------------------------------------------------
#include <iostream>
#include <cmath>
using namespace std;

int main() {

    float a, b, c, x1, x2, determinant, realPart, imaginaryPart;
    cout << "Enter coefficients a, b and c: ";
    cin >> a >> b >> c;
    determinant = b*b - 4*a*c;
    
    if (determinant > 0) {
        x1 = (-b + sqrt(determinant)) / (2*a);
        x2 = (-b - sqrt(determinant)) / (2*a);
        cout << "Roots are real and different." << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    }
    
    else if (determinant == 0) {
        cout << "Roots are real and same." << endl;
        x1 = (-b + sqrt(determinant)) / (2*a);
        cout << "x1 = x2 =" << x1 << endl;
    }

    else {
        realPart = -b/(2*a);
        imaginaryPart =sqrt(-determinant)/(2*a);
        cout << "Roots are complex and different."  << endl;
        cout << "x1 = " << realPart << "+" << imaginaryPart << "i" << endl;
        cout << "x2 = " << realPart << "-" << imaginaryPart << "i" << endl;
    }

    return 0;
}

%! #----------------------------------------------------------------------------
https://www.jdoodle.com/execute-octave-matlab-online
%! #----------------------------------------------------------------------------
data = [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];
y = data - ones(10,1)*mean(data);
__data__ = abs(y)

[data, __data__] = deal (__data__, data);
df1 = diff (data, 1)([1; (1:end)']);
df2 = diff (data, 2)([1; 1; (1:end)']);
idx = find(df1.*[df1(2:end); 0] <= 0)% & [df2(2:end); 0] < 0
tf  = data(idx) > 0;
  idx = idx(tf);
  [~, tmp] = sort (data(idx), "descend");
  idx_s = idx(tmp)
D = abs (bsxfun (@minus, idx_s, idx_s'));

node2visit = 1:size(D,1); % 1 2 3
visited = [];
d = D(node2visit(1),:); % 0 5 4
visited = [visited node2visit(1)]; % [1]
node2visit(1) = []; % [2 3]
neighs  = setdiff (find (d < 5), visited);disp(neighs);
visited = [visited neighs];
extra = struct ("parabol", [], "height", [], "baseline", [], "roots", []);
x = linspace(0,1,5);disp(x)
y = 1./(1+x);disp(y)
pp = polyfit(x,y,2);
disp(pp)
rz = roots ([pp(1:2) pp(3)-mean([3,0.1])]);
disp(roots ([3 -2 4]))
width = abs (diff (roots ([3 -2 4])));
disp(width)
%! #----------------------------------------------------------------------------

2016-12-14 02:29:54.733 TestLib[51451:1187560] m1:
329 781 1876 444 65508 65347 135 0.317677 0.400367 0.555916 0.655549 
339 407 2097 459 38 81 71 0.317189 0.400448 0.555821 0.655817 
349 536 2009 478 65474 65506 202 0.316638 0.40089 0.555333 0.656226 
359 360 1987 560 65518 130 151 0.315937 0.401104 0.554858 0.656835 
370 222 2052 548 0 105 161 0.315014 0.400972 0.554812 0.657397 
380 314 1922 599 65429 65427 238 0.314675 0.401723 0.553798 0.657956 
390 181 2009 568 65472 65423 199 0.314447 0.402491 0.55291 0.658343 
400 236 1837 447 65366 65199 288 0.314699 0.403963 0.551299 0.658671 
410 174 1847 419 65419 65126 288 0.315163 0.405928 0.54954 0.658712 
420 190 1747 305 65401 65088 342 0.315634 0.408186 0.547588 0.658716 
430 122 1809 264 65441 65183 315 0.315879 0.410243 0.545885 0.658735 
440 65528 1708 252 65406 65367 313 0.315724 0.411695 0.54438 0.659148 
450 65269 1775 183 65456 65523 263 0.315138 0.412376 0.543441 0.659777 
460 65130 1779 159 65483 65375 272 0.314756 0.413321 0.542494 0.660147 
470 65274 1710 169 4 65164 311 0.314775 0.415233 0.541337 0.659888 
480 65166 1727 146 59 65261 251 0.314728 0.417104 0.540384 0.659512 
491 65129 1727 197 100 65293 248 0.314462 0.418684 0.539856 0.65907 
501 65085 1745 232 151 65326 226 0.314088 0.420253 0.539493 0.658547 
511 65020 1769 251 186 65382 204 0.313554 0.421613 0.539456 0.657962 
521 64873 1787 341 228 65417 168 0.312955 0.422773 0.539667 0.657329 
531 64744 1866 346 292 65315 158 0.312477 0.424168 0.540065 0.65633 
541 64804 1948 378 347 65127 148 0.312438 0.426252 0.540358 0.654755 
552 64734 2012 384 384 65115 96 0.312619 0.428506 0.540751 0.652871 
562 64699 2154 423 423 65122 51 0.312847 0.430592 0.541463 0.650796 
572 64675 2179 454 428 65105 16 0.313219 0.43265 0.542258 0.648586 
582 64633 2219 535 437 65112 65516 0.313716 0.434598 0.543146 0.646297 
592 64612 2293 568 450 65148 65493 0.314203 0.436388 0.544179 0.643981 
602 64562 2304 639 433 65197 65477 0.314652 0.437934 0.545279 0.641778 
613 64485 2396 743 413 65303 65439 0.315 0.439029 0.546551 0.639774 
623 64284 2382 847 347 65485 65394 0.315124 0.439335 0.547998 0.638263 
633 63998 2374 957 280 36 65317 0.315363 0.438852 0.54959 0.637108 
2000 0 2 12 0 65460 65265 0.316203 0.438213 0.550971 0.635937 
2654 63585 2429 1146 147 65192 65222 0.31806 0.438109 0.551853 0.634316 
2665 63484 2489 1178 60 64904 65171 0.321126 0.43868 0.552114 0.632146 
2676 63403 2558 1188 65507 64677 65090 0.325391 0.439718 0.55178 0.629529 
2686 63304 2647 1243 65414 64576 64994 0.330608 0.440734 0.551117 0.626675 
2696 63217 2740 1267 65327 64541 64877 0.336549 0.441359 0.550347 0.623743 
2707 63162 2859 1267 65216 64532 64708 0.343291 0.441386 0.549528 0.620765 
2718 63004 2950 1352 65061 64606 64491 0.350839 0.440323 0.548808 0.61793 
2728 62819 3046 1305 64917 64592 64235 0.359481 0.438148 0.548136 0.615098 
2739 62715 3084 1286 64765 64389 64018 0.369657 0.435445 0.547224 0.61179 
2749 62764 3154 1246 64659 64025 63834 0.381654 0.432956 0.545603 0.607624 
2760 62910 3213 1260 64546 63690 63662 0.395412 0.430881 0.54324 0.602396 
2771 63045 3351 1191 64430 63591 63460 0.410379 0.428388 0.540469 0.596629 
2781 63217 3445 1203 64272 63666 63233 0.426144 0.42482 0.537592 0.590698 
2792 63218 3648 1334 64150 64037 62889 0.442162 0.418935 0.535525 0.584978 
2802 63260 3832 1385 63992 64348 62563 0.458438 0.410584 0.53433 0.579437 
2812 63259 4222 1516 63845 64641 62175 0.475108 0.399757 0.533975 0.573879 
2824 63238 4452 1658 63659 64730 61755 0.492771 0.386665 0.534084 0.567822 
2834 63128 4893 1953 63535 64623 61371 0.511804 0.372032 0.534082 0.560718 
2844 63289 5262 1787 63497 64077 61146 0.53247 0.357481 0.533113 0.551792 
2855 63785 5137 2121 63151 63467 60920 0.556083 0.343574 0.528572 0.54161 
2865 63172 5661 1924 63233 63832 60531 0.578932 0.327513 0.526196 0.529803 
2876 64088 5497 1883 62811 62297 60681 0.605426 0.313711 0.517181 0.517271 
2887 64194 5436 1795 62633 62403 60552 0.632091 0.299302 0.507673 0.503137 
2897 64641 5706 1584 62543 62057 60516 0.658996 0.28489 0.495418 0.489002 
2907 64722 5287 1540 62193 62107 60589 0.685168 0.269557 0.482495 0.474428 
2918 64985 5405 1266 61996 61868 60850 0.710863 0.253748 0.466872 0.460778 
2928 65334 5176 1041 61853 61460 61228 0.735697 0.238917 0.448507 0.447783 
2938 258 5130 658 61717 61476 61568 0.759236 0.224753 0.428295 0.435443 
2949 354 4925 520 61454 62115 61603 0.780612 0.208459 0.408814 0.424336 
2958 65298 5001 391 61377 62989 61490 0.799486 0.189109 0.392444 0.413578 
2968 3 4433 105 61102 62955 61782 0.816837 0.168724 0.375771 0.403863 
2978 146 4257 65494 61134 63059 61840 0.833062 0.148328 0.358679 0.394152 
2988 247 3852 65145 61175 63145 61975 0.847932 0.127807 0.341769 0.384538 
2999 510 3594 64943 61228 63185 62175 0.861483 0.10766 0.324572 0.375379 
3009 659 3116 64563 61321 63250 62350 0.873666 0.0878831 0.307742 0.366441 
3019 819 3216 64495 61524 63444 62416 0.884668 0.0686068 0.291186 0.357584 
3030 985 2848 64226 61630 63599 62646 0.894254 0.0499543 0.275523 0.349144 
3040 1017 2677 64184 61847 63798 62751 0.902667 0.0319915 0.260906 0.34073 
3050 1112 2373 64038 62045 63839 62925 0.910071 0.0150012 0.246745 0.332659 
3061 1335 2073 63706 62285 63913 63078 0.916615 -0.000853045 0.233082 0.324792 
3072 1727 1678 63764 62496 63835 63219 0.922446 -0.0154071 0.219547 0.317262 
3082 1962 1505 63254 62857 63969 63498 0.927452 -0.0283414 0.206779 0.310278 
3093 2223 1083 63021 63183 63817 63812 0.931764 -0.0391914 0.194108 0.304305 
3103 2546 892 62870 63697 63527 64166 0.93561 -0.0470693 0.180778 0.299563 
3113 2964 845 62752 64162 63434 64644 0.938837 -0.0517531 0.167354 0.296478 
3124 3318 866 62808 64533 63920 64973 0.941158 -0.0545928 0.156201 0.294692 
3134 2809 572 62868 64768 65069 65210 0.942195 -0.0575654 0.150417 0.293819 
3144 2350 902 62924 65413 149 65339 0.942537 -0.0590203 0.14987 0.292711 
3155 2372 769 63080 72 80 231 0.942301 -0.05873 0.150248 0.293333 
3165 2197 946 63184 533 297 415 0.941696 -0.056458 0.151826 0.294906 
3176 2172 1132 63263 892 629 636 0.940638 -0.0524141 0.155775 0.296963 
3186 2019 1299 63533 1208 989 794 0.938949 -0.0473628 0.16208 0.299771 
3197 1855 1411 63688 1487 1117 994 0.936865 -0.0406689 0.169859 0.302949 
3207 1927 1626 63827 1723 1198 1287 0.934158 -0.0327215 0.178504 0.307268 
3218 1849 1975 63901 1989 1391 1496 0.930756 -0.0235371 0.188375 0.312497 
3228 1714 2364 63965 2219 1545 1675 0.926655 -0.0131352 0.199595 0.318276 
3239 1646 2810 63987 2434 1605 1866 0.921863 -0.00148714 0.21154 0.324681 
3250 1583 3182 64013 2643 1660 2066 0.916299 0.0114292 0.224119 0.331718 
3260 1577 3577 63990 2857 1466 2346 0.909982 0.0259041 0.236451 0.339637 
3271 1772 4053 63827 3103 962 2667 0.903126 0.0428386 0.247004 0.348592 
3281 2099 4447 63519 3388 348 2999 0.895868 0.0626677 0.254917 0.358484 
3292 2439 5002 63103 3880 65206 3322 0.888069 0.0864393 0.260346 0.368892 
3302 3117 5709 62573 4437 64503 3689 0.879518 0.114774 0.262991 0.37962 
3313 3890 6466 61859 4965 64428 4009 0.869282 0.146799 0.264962 0.390633 
3323 4188 7540 60807 5606 65193 4296 0.855892 0.180818 0.27027 0.402129 
3334 4627 8532 59971 6213 422 4706 0.838345 0.216821 0.280017 0.414436 
3345 5156 9393 59381 6842 1662 5128 0.81588 0.253378 0.294754 0.428088 
3355 4057 10464 58600 7533 4072 5592 0.785871 0.288148 0.318587 0.444836 
3370 3549 12334 57988 8401 5522 6848 0.74594 0.323391 0.350384 0.464997 
3381 2568 15354 57722 9172 7402 7788 0.695452 0.357857 0.386428 0.488831 
3392 1622 18374 58275 9512 9330 8777 0.632521 0.38863 0.427884 0.515554 
3402 311 21856 58532 9523 11156 9985 0.557811 0.413893 0.468968 0.545531 
3413 64314 25382 61532 8807 13043 11443 0.47053 0.430604 0.506734 0.579997 
3424 60933 25269 62651 8353 12775 13208 0.373984 0.444 0.534395 0.614342 
3435 32768 32767 32767 7316 6680 16452 0.279722 0.471533 0.539344 0.639153 
3445 32768 1601 32768 32768 32768 51827 0.425733 0.412233 0.479206 0.647286 
3457 59982 8420 39781 39167 32767 32767 0.388267 0.401332 0.305957 0.770916 
3467 56855 7556 32768 2478 32767 32767 0.208337 0.292905 0.274903 0.891666 
3478 42544 64058 32768 20210 32767 31921 -0.0251703 0.198075 0.34271 0.917853 
3489 61356 8985 46473 23735 32767 58467 -0.102378 0.0282421 0.441469 0.890908 
3499 63700 3821 53896 14393 32767 61260 -0.162243 -0.144567 0.497024 0.840047 
3510 2322 1336 55829 65469 32767 44202 -0.176142 -0.334153 0.476722 0.793699 
3521 64912 4597 54302 46563 32767 65482 -0.242853 -0.477825 0.366397 0.760515 
3531 58155 64897 46717 54686 32767 10888 -0.374348 -0.567386 0.275612 0.679639 
3542 1165 480 61073 61515 32767 2030 -0.443916 -0.66343 0.208278 0.565133 
3552 58633 142 32768 62436 32767 6618 -0.498378 -0.738186 0.131613 0.435122 
3562 728 289 62341 3577 32767 3847 -0.516848 -0.805847 0.0741679 0.279162 
3572 384 321 63460 982 32767 2210 -0.520204 -0.843485 -0.0124729 0.133125 
3583 63049 3838 62313 6789 24280 4393 -0.491733 -0.868034 -0.0681123 -0.00773774 
3593 63555 2199 61460 3973 28020 57118 -0.456837 -0.865816 -0.168756 -0.114701 
3604 63779 4490 2235 64326 19650 64308 -0.43108 -0.847519 -0.234167 -0.202588 
3613 65149 908 64900 62274 14119 62884 -0.424988 -0.818775 -0.277576 -0.268223 
3623 65410 438 65354 63182 11377 63872 -0.420166 -0.791173 -0.30834 -0.320049 
3634 65148 1027 483 64861 9038 64391 -0.41093 -0.76957 -0.332134 -0.358587 
3643 64579 2135 65462 390 6410 65080 -0.398313 -0.754737 -0.350905 -0.385467 
3653 64583 2139 6 504 3126 65255 -0.389522 -0.746824 -0.361791 -0.399542 
3663 64982 1565 65498 565 7 65283 -0.387016 -0.745492 -0.365761 -0.400849 
3673 205 1479 65110 1493 63105 65428 -0.386364 -0.751671 -0.365002 -0.390495 
3683 1109 2424 65145 2472 62652 65212 -0.383222 -0.761791 -0.364908 -0.373708 
3694 1770 2669 65526 1656 63898 65047 -0.380025 -0.768799 -0.366358 -0.360987 
3704 1420 2072 65228 68 541 65363 -0.378838 -0.769221 -0.36803 -0.359631 
3714 777 2220 65390 65096 2336 65219 -0.376932 -0.763964 -0.372725 -0.367911 
3724 165 1987 65055 64599 2846 149 -0.37462 -0.756876 -0.375871 -0.381471 
3734 65348 1895 65084 64748 2268 49 -0.373082 -0.750041 -0.379059 -0.393143 
3744 65465 2024 65305 65156 994 72 -0.372314 -0.746383 -0.380293 -0.39959 
3755 251 1938 64929 65330 65303 205 -0.373009 -0.746051 -0.379448 -0.400364 
3765 602 2067 65041 45 64771 4 -0.374418 -0.747517 -0.377885 -0.397785 
3775 832 2245 64962 65466 64948 96 -0.375702 -0.749037 -0.376142 -0.395358 
3785 492 1995 64920 65053 222 37 -0.377142 -0.748362 -0.375088 -0.396267 
3795 283 2213 64825 65026 576 28 -0.378156 -0.746097 -0.375229 -0.399425 
3805 262 1969 64838 64838 428 142 -0.379627 -0.744019 -0.374094 -0.402955 
3815 179 2016 64836 65008 350 150 -0.380959 -0.742275 -0.37314 -0.40579 
3825 200 2037 64844 65060 169 162 -0.382164 -0.741098 -0.371955 -0.407889 
3835 233 2043 64795 65106 59 175 -0.383473 -0.740328 -0.370514 -0.409369 
3846 235 1992 64782 65142 32 170 -0.384704 -0.739707 -0.369094 -0.410616 
3856 244 2029 64768 65225 5 166 -0.3857 -0.739311 -0.367766 -0.411587 
3866 230 2013 64808 65274 59 132 -0.386444 -0.7389 -0.366758 -0.412524 
3876 183 1993 64838 65322 82 99 -0.387018 -0.738446 -0.36606 -0.413418 
3886 245 2059 64925 65395 31 70 -0.387453 -0.738125 -0.365553 -0.414032 
3896 285 1983 64983 65411 65485 32 -0.387959 -0.738012 -0.3651 -0.414159 
3907 319 1979 65011 65460 65464 4 -0.388553 -0.737918 -0.364743 -0.414085 
3917 358 2017 64960 65517 65408 65512 -0.388996 -0.738038 -0.364537 -0.413637 
3927 285 1959 64956 65531 65380 65473 -0.389503 -0.738213 -0.364458 -0.412915 
3937 270 1993 64930 72 65356 65439 -0.389949 -0.738454 -0.364592 -0.411944 
3947 184 1985 64948 97 65361 65381 -0.390326 -0.73875 -0.365002 -0.410691 
3957 165 1990 64979 140 65357 65345 -0.390617 -0.738988 -0.365734 -0.409333 
3968 211 1979 64994 162 65336 65303 -0.391016 -0.739259 -0.366549 -0.407731 
3978 195 2022 65051 205 65395 65248 -0.391212 -0.739421 -0.367813 -0.406107 
3988 265 2005 65075 195 65337 65225 -0.391578 -0.739537 -0.369127 -0.404348 
3998 303 2002 65082 217 65320 65208 -0.39199 -0.739731 -0.370433 -0.402394 
4008 356 2031 65118 219 65318 65197 -0.392358 -0.73992 -0.371817 -0.400407 
4018 363 2049 65106 222 65325 65186 -0.392767 -0.740087 -0.373209 -0.398398 
4029 369 2048 65156 207 65406 65188 -0.393046 -0.740102 -0.374736 -0.396657 
4038 402 1975 65131 172 65457 65208 -0.393291 -0.739948 -0.376263 -0.395254 
4049 383 2002 65182 181 23 65212 -0.393428 -0.739606 -0.377885 -0.394207 
4059 340 1996 65179 157 113 65214 -0.393339 -0.739041 -0.379741 -0.393572 
4069 348 1988 65189 146 87 65234 -0.393349 -0.738446 -0.38146 -0.393018 
4080 343 1983 65223 131 119 65232 -0.393345 -0.737808 -0.38316 -0.392565 
4090 306 1964 65220 115 129 65226 -0.393327 -0.7371 -0.384913 -0.392197 
4100 302 1977 65190 101 100 65228 -0.39346 -0.736381 -0.386566 -0.391788 
4110 299 1974 65267 89 79 65229 -0.393654 -0.735706 -0.388138 -0.391309 
4120 291 2006 65209 96 66 65202 -0.393926 -0.735014 -0.38976 -0.390723 
4130 255 2019 65212 71 91 65178 -0.394278 -0.734203 -0.39148 -0.390171 
4141 269 1987 65204 49 44 65180 -0.394778 -0.733385 -0.393128 -0.389547 
4151 268 1946 65212 20 69 65145 -0.395481 -0.732439 -0.394771 -0.388952 
4161 278 2053 65190 54 116 65111 -0.396026 -0.731378 -0.396739 -0.388392 
4171 286 2020 65133 25 116 65104 -0.396675 -0.730197 -0.398747 -0.387895 
4181 379 2018 65188 13 130 65094 -0.397354 -0.72897 -0.400771 -0.387422 
4191 370 2056 65133 22 138 65083 -0.398001 -0.727691 -0.402828 -0.387028 
4204 352 2088 65138 24 138 65092 -0.39858 -0.726449 -0.404899 -0.386605 
4214 374 2099 65143 14 34 65131 -0.399302 -0.725387 -0.406671 -0.385992 
4224 403 2092 65109 65535 65484 65163 -0.400238 -0.724587 -0.408042 -0.385078 
4235 397 2093 65092 65521 65502 65181 -0.401168 -0.723811 -0.40931 -0.384223 
4244 436 2052 65073 65502 65484 65216 -0.402133 -0.723067 -0.410405 -0.383446 
4254 447 2051 65081 65484 5 65230 -0.403055 -0.72228 -0.411432 -0.382861 
4265 426 2036 65075 65482 93 65247 -0.40375 -0.721317 -0.412605 -0.382682 
4275 471 2050 65045 65480 97 65292 -0.404338 -0.720393 -0.413657 -0.382665 
4285 433 2061 65033 65488 179 65315 -0.404699 -0.719432 -0.414739 -0.382921 
4295 421 2036 65083 65480 199 65362 -0.404893 -0.718449 -0.41577 -0.383441 
4305 423 2014 65034 65505 199 65403 -0.404963 -0.717617 -0.416625 -0.383998 
4315 363 2009 65037 65523 263 65418 -0.404772 -0.716756 -0.417585 -0.384764 
4326 355 2046 65038 12 246 65450 -0.404446 -0.715998 -0.418491 -0.385534 
4336 331 2034 65061 10 242 65480 -0.40405 -0.715343 -0.419261 -0.386326 
4346 320 2010 65096 17 251 65495 -0.403584 -0.71472 -0.419991 -0.387172 
4356 310 2039 65074 38 243 65509 -0.403046 -0.714163 -0.420696 -0.387994 
4366 266 2001 65121 27 220 65524 -0.402523 -0.713674 -0.421303 -0.388778 
4376 270 2007 65125 20 180 65534 -0.4021 -0.713265 -0.421769 -0.389461 
4387 214 2071 65173 21 160 65533 -0.401756 -0.712905 -0.422158 -0.390052 
4397 198 2053 65160 65516 126 8 -0.401532 -0.712543 -0.422454 -0.390624 
4407 228 2011 65192 65461 32 23 -0.401717 -0.712273 -0.422347 -0.391042 
4417 198 2000 65175 65451 61 65533 -0.401993 -0.71195 -0.422257 -0.391443 
4427 179 2010 65158 65431 37 65525 -0.402363 -0.71154 -0.422216 -0.391853 
4437 223 2003 65157 65397 65494 65529 -0.403038 -0.711228 -0.421906 -0.39206 
4447 209 2025 65139 65394 65493 65509 -0.403787 -0.710916 -0.421608 -0.392175 
4457 209 2019 65113 65378 65428 65512 -0.404719 -0.710636 -0.42121 -0.392149 
4467 273 1991 65104 65363 65378 65525 -0.405815 -0.710503 -0.420577 -0.391936 
4478 217 2039 65082 65377 65428 65512 -0.406821 -0.710309 -0.420057 -0.391804 
4488 247 2038 65019 65371 65418 65521 -0.407806 -0.710089 -0.419547 -0.391725 
4498 226 1952 65078 65347 65456 65534 -0.408735 -0.709863 -0.419007 -0.391745 
4508 266 2057 65037 65402 65503 12 -0.409499 -0.70958 -0.418555 -0.391941 
4518 232 2014 65045 65369 50 3 -0.410108 -0.709134 -0.418269 -0.392418 
4528 229 2061 65052 65388 99 20 -0.410483 -0.708619 -0.418123 -0.393111 
4539 246 2065 65028 65396 129 38 -0.410785 -0.708069 -0.417955 -0.393964 
4549 249 2046 65069 65392 215 36 -0.41087 -0.707404 -0.417952 -0.395072 
4559 243 2058 65081 65418 256 46 -0.410771 -0.706649 -0.418078 -0.396391 
4569 230 2067 65072 65424 278 59 -0.410553 -0.705898 -0.418229 -0.397793 
4579 217 2080 65110 65443 288 61 -0.410231 -0.70516 -0.418428 -0.399222 
4590 206 2082 65110 65461 267 72 -0.409847 -0.704501 -0.418615 -0.400582 
4600 190 2070 65099 65471 226 85 -0.409477 -0.703978 -0.41869 -0.401798 
4610 180 2064 65132 65486 196 86 -0.409124 -0.703559 -0.418705 -0.402874 
4620 160 2051 65128 65507 175 89 -0.40874 -0.703239 -0.418716 -0.403812 
4630 159 2070 65163 65521 151 87 -0.408359 -0.702995 -0.418712 -0.404624 
4640 135 2053 65172 65529 134 75 -0.408004 -0.702791 -0.418721 -0.405328 
4651 144 2046 65198 4 110 69 -0.407685 -0.702633 -0.418733 -0.405909 
4661 138 2028 65193 8 110 53 -0.407389 -0.702478 -0.418778 -0.406427 
4671 111 2031 65210 31 134 34 -0.407017 -0.702277 -0.418988 -0.406932 
4681 113 2077 65232 46 147 18 -0.4066 -0.702039 -0.419326 -0.407411 
4691 116 2061 65211 50 176 0 -0.406137 -0.701717 -0.419802 -0.407938 
4701 119 2025 65215 58 214 65512 -0.405611 -0.701284 -0.420447 -0.408541 
4712 103 2023 65256 81 252 65485 -0.404984 -0.700748 -0.421321 -0.40918 
4721 98 2013 65271 84 252 65468 -0.404358 -0.700145 -0.422311 -0.409811 
4731 89 1989 65300 99 261 65450 -0.403714 -0.699532 -0.423392 -0.410376 
4742 107 1985 65289 111 285 65430 -0.403017 -0.698856 -0.424619 -0.410945 
4752 103 2006 65300 122 327 65400 -0.402248 -0.698039 -0.426063 -0.411592 
4761 59 1988 65297 123 316 65388 -0.401487 -0.697188 -0.427586 -0.412197 
4772 83 1975 65330 131 281 65380 -0.400803 -0.696398 -0.429075 -0.412651 
4781 66 2014 65299 142 268 65362 -0.400165 -0.695632 -0.430591 -0.412984 
4791 40 2055 65320 147 253 65347 -0.399549 -0.69489 -0.432159 -0.413191 
4802 60 2094 65326 146 198 65352 -0.399034 -0.694225 -0.433651 -0.413243 
4811 67 2054 65336 114 183 65344 -0.398719 -0.693543 -0.435009 -0.413265 
4821 42 2009 65352 95 201 65327 -0.398446 -0.69277 -0.436418 -0.41334 
4831 58 2007 65335 75 183 65324 -0.398295 -0.691952 -0.437792 -0.413402 
4841 71 2009 65334 48 177 65318 -0.398288 -0.691082 -0.439092 -0.413486 
4851 66 2064 65338 35 183 65303 -0.398337 -0.690147 -0.44042 -0.413587 
4861 60 2082 65284 7 184 65295 -0.398504 -0.689116 -0.441743 -0.413736 
4871 75 2011 65304 65494 153 65309 -0.398872 -0.688071 -0.442877 -0.413908 
4881 97 2004 65253 65474 163 65307 -0.39933 -0.686988 -0.443923 -0.414144 
4891 90 1991 65277 65445 203 65296 -0.399807 -0.685744 -0.445038 -0.414549 
4901 104 1984 65234 65420 205 65303 -0.400341 -0.684428 -0.446102 -0.415064 
4911 146 2000 65236 65409 233 65305 -0.400867 -0.683053 -0.447153 -0.41569 
4922 133 2015 65215 65381 263 65306 -0.401399 -0.681552 -0.448215 -0.416497 
4932 149 2026 65214 65364 274 65318 -0.401935 -0.680001 -0.449233 -0.417417 
4941 166 2026 65208 65348 298 65327 -0.402458 -0.678394 -0.450212 -0.418472 
4952 166 2034 65192 65335 334 65327 -0.402942 -0.67668 -0.451226 -0.419686 
4962 147 2039 65208 65332 337 65336 -0.403389 -0.674945 -0.452238 -0.42096 
4972 165 2075 65206 65326 309 65343 -0.4039 -0.673253 -0.453158 -0.422188 
4982 142 2066 65199 65312 265 65347 -0.404531 -0.671633 -0.453945 -0.423318 
4992 163 2071 65194 65306 189 65359 -0.405323 -0.670178 -0.454533 -0.424234 
5002 161 2077 65154 65306 117 65370 -0.406278 -0.66891 -0.454907 -0.42492 
5013 172 2053 65160 65299 36 65384 -0.407405 -0.667849 -0.455054 -0.425352 
5023 175 2067 65175 65303 2 65395 -0.408615 -0.666927 -0.455053 -0.42564 
5033 187 2032 65138 65297 65528 65404 -0.409845 -0.666059 -0.454975 -0.425899 
5043 192 2022 65153 65301 16 65406 -0.410995 -0.665193 -0.454912 -0.426212 
5053 169 2041 65171 65316 72 65410 -0.411989 -0.664219 -0.45498 -0.426698 
5063 178 2023 65189 65327 95 65430 -0.41284 -0.66323 -0.455098 -0.427288 
5074 203 1999 65164 65327 116 65445 -0.413599 -0.662248 -0.455196 -0.427972 
5084 181 1996 65182 65351 163 65453 -0.414156 -0.661233 -0.455398 -0.428787 
5094 177 2008 65183 65365 187 65468 -0.414565 -0.660206 -0.455657 -0.429698 
5104 193 1979 65189 65377 197 65490 -0.414837 -0.659238 -0.455903 -0.430659 
5114 163 2005 65200 65403 210 65510 -0.414954 -0.658328 -0.456162 -0.431664 
5124 164 1971 65256 65413 197 2 -0.414983 -0.657531 -0.456336 -0.432666 
5135 158 1998 65297 65440 199 27 -0.414883 -0.656837 -0.456467 -0.433676 
5145 174 1973 65281 65446 183 56 -0.414709 -0.656267 -0.456509 -0.43466 
5154 154 1969 65324 65466 160 83 -0.41447 -0.655851 -0.456437 -0.435592 
5165 160 1879 65307 65486 120 107 -0.414199 -0.655611 -0.456252 -0.436403 
5175 140 2152 65404 16 76 106 -0.413901 -0.655598 -0.455983 -0.436987 
5185 152 1979 65379 65474 65474 147 -0.413797 -0.655806 -0.455369 -0.437413 
5196 137 1955 65392 65522 65460 171 -0.413678 -0.656357 -0.454525 -0.437575 
2016-12-14 02:29:54.962 TestLib[51451:1187560] m2:
327 1403 64039 65253 260 64892 65071 0.40267 -0.78951 0.165737 -0.432507 
337 1694 64503 167 78 64987 65116 0.402694 -0.7909 0.162317 -0.431239 
348 1355 64305 65228 65446 65076 65127 0.401954 -0.792383 0.159576 -0.430228 
358 1418 63926 65141 65304 65118 65114 0.400498 -0.794125 0.157294 -0.429214 
368 1742 64256 65439 65261 65166 65108 0.3987 -0.795884 0.155271 -0.428367 
379 1752 64248 65463 65265 65179 65068 0.396778 -0.797595 0.153059 -0.427764 
389 1683 64129 65340 65285 65196 65057 0.394862 -0.799254 0.150823 -0.427235 
399 1809 64176 65300 65319 65240 65003 0.392971 -0.800785 0.148386 -0.426965 
410 1919 64799 351 65179 65343 64960 0.390595 -0.802307 0.146008 -0.427107 
420 1800 64328 14 64593 188 64916 0.38555 -0.804192 0.145352 -0.428368 
430 1687 63966 65373 64359 394 64858 0.378966 -0.806116 0.145661 -0.430516 
441 1574 63946 65334 64340 461 64858 0.371847 -0.807963 0.146408 -0.433002 
451 1538 63884 65227 64595 370 64826 0.3656 -0.809495 0.146488 -0.435426 
462 1281 63912 65152 64910 213 64798 0.360716 -0.810779 0.145435 -0.437458 
472 1291 64054 65203 65190 82 64802 0.357199 -0.811811 0.143435 -0.439088 
482 1347 64047 65291 65366 0 64794 0.354608 -0.812668 0.140739 -0.440474 
493 1287 64065 65249 65499 65508 64808 0.352646 -0.813339 0.13767 -0.441777 
503 1355 64031 65242 111 65463 64810 0.351354 -0.813811 0.13423 -0.442994 
514 1318 64003 65277 270 65419 64807 0.350763 -0.814092 0.130312 -0.444117 
524 1371 64033 65243 402 65391 64818 0.350841 -0.814138 0.126071 -0.445192 
535 1245 64120 65146 541 65356 64840 0.351529 -0.814001 0.121519 -0.446165 
545 1221 64081 65074 722 65301 64848 0.352962 -0.813672 0.116494 -0.446974 
556 1153 64003 64994 912 65201 64846 0.355306 -0.813163 0.110865 -0.447474 
566 1435 63873 65052 1016 65148 64878 0.358356 -0.812503 0.104909 -0.447677 
576 1489 63825 64996 994 65192 64958 0.361521 -0.811723 0.0992355 -0.44784 
587 1509 63784 65035 882 65271 65039 0.364414 -0.810873 0.0942608 -0.448109 
597 1587 63621 65051 780 65354 65117 0.36702 -0.80995 0.0900927 -0.448509 
608 1515 63750 65059 721 65457 65226 0.369526 -0.808848 0.0867287 -0.449104 
618 1595 63573 65080 693 65530 65342 0.372051 -0.807586 0.0840553 -0.449798 
629 1657 63569 65092 719 46 65455 0.374893 -0.8061 0.081961 -0.450489 
639 1494 63528 65044 748 112 44 0.378144 -0.804324 0.0804252 -0.451223 
650 1381 63765 64987 817 136 187 0.381923 -0.802287 0.079498 -0.45183 
660 1492 63822 64975 846 173 317 0.386176 -0.800039 0.0790424 -0.452281 
670 1504 63778 64782 844 246 431 0.390686 -0.797553 0.0791957 -0.452771 
681 1503 63902 64673 824 293 554 0.395353 -0.794929 0.0800205 -0.453189 
691 1838 63807 64501 802 345 648 0.400083 -0.792196 0.0813972 -0.453579 
703 1508 64112 64457 748 370 708 0.40476 -0.789415 0.0832343 -0.453943 
713 1738 64265 64428 718 364 753 0.409356 -0.786697 0.0853509 -0.454149 
723 1189 64800 64467 650 347 761 0.413724 -0.784114 0.0876318 -0.454223 
734 1690 64445 64121 552 349 757 0.417649 -0.781751 0.0901175 -0.454217 
744 1853 64619 64166 460 324 719 0.421134 -0.779605 0.0926905 -0.45417 
755 1825 64785 64382 352 326 698 0.42396 -0.777767 0.0953361 -0.454145 
765 2176 64767 64250 240 312 658 0.426252 -0.776198 0.0980587 -0.454104 
776 2060 64724 64112 132 279 591 0.427934 -0.77496 0.10074 -0.45405 
786 1861 64981 64198 113 232 557 0.429348 -0.773968 0.103215 -0.45385 
797 2086 64740 64275 85 170 446 0.430498 -0.773213 0.105184 -0.453595 
807 2100 64957 64310 117 106 397 0.431671 -0.772556 0.106757 -0.453234 
817 1922 64970 64340 91 122 303 0.432556 -0.771992 0.107985 -0.453059 
828 1891 64882 64370 26 159 244 0.432989 -0.771547 0.109107 -0.453134 
838 1747 64979 64267 65436 209 197 0.432867 -0.771248 0.110446 -0.453436 
849 1589 64800 64202 65327 228 131 0.432088 -0.771192 0.111913 -0.453915 
859 1534 64853 64179 65293 196 101 0.431023 -0.771328 0.113329 -0.454345 
869 1431 64753 64236 65300 131 35 0.429854 -0.771643 0.114374 -0.454654 
880 1455 64661 64283 65364 38 65526 0.428857 -0.77206 0.114913 -0.454753 
891 1515 64498 64418 65417 65494 65485 0.428051 -0.772574 0.114935 -0.454632 
901 1499 64367 64519 65453 65448 65459 0.427384 -0.77313 0.114612 -0.454397 
912 1526 64383 64581 65497 65410 65459 0.42694 -0.773663 0.114101 -0.454036 
922 1455 64307 64530 65476 65418 65438 0.426461 -0.774211 0.113494 -0.453704 
933 1390 64368 64532 65382 65447 65465 0.425685 -0.774867 0.113211 -0.453384 
944 1406 64417 64570 65242 65489 65475 0.424388 -0.77572 0.113405 -0.453093 
954 1382 64451 64663 65102 8 65491 0.422505 -0.776746 0.114104 -0.452919 
964 1362 64485 64771 65000 44 65493 0.42014 -0.777907 0.115209 -0.452846 
975 1313 64462 64872 64977 44 65468 0.41756 -0.779136 0.116357 -0.452827 
985 1279 64438 65017 65008 30 65451 0.415036 -0.780335 0.117342 -0.452828 
995 1269 64367 65198 65053 19 65426 0.412678 -0.78145 0.118102 -0.452862 
1006 1254 64316 65298 65083 27 65415 0.410452 -0.782463 0.118732 -0.452973 
1016 1298 64238 65379 65101 51 65406 0.408287 -0.783364 0.119322 -0.453216 
1027 1239 64237 65436 65128 75 65394 0.406185 -0.784145 0.119866 -0.453611 
1037 1183 64243 65474 65176 97 65376 0.404219 -0.784779 0.120299 -0.454156 
1047 1214 64215 65514 65234 109 65351 0.402434 -0.785262 0.120524 -0.454846 
1057 1176 64145 8 65278 139 65324 0.400776 -0.78559 0.120572 -0.45573 
1068 1154 64096 33 65301 185 65299 0.399162 -0.785759 0.120542 -0.456861 
1078 1192 63996 83 65290 247 65283 0.397465 -0.785797 0.120571 -0.458266 
1088 1152 63854 81 65263 325 65267 0.395591 -0.785701 0.120755 -0.460001 
1098 1153 63714 66 65245 398 65274 0.3936 -0.785448 0.12117 -0.462026 
1108 1172 63630 50 65251 456 65283 0.391605 -0.785027 0.121769 -0.464274 
1118 1204 63484 8 65277 501 65294 0.3897 -0.784423 0.122468 -0.466708 
1129 1215 63411 65514 65301 537 65314 0.387912 -0.783659 0.123264 -0.469265 
1139 1211 63376 65458 65330 565 65335 0.38628 -0.782741 0.124149 -0.471902 
1149 1197 63256 65411 65354 571 65342 0.384755 -0.781737 0.125053 -0.474566 
1160 1136 63140 65349 65398 550 65353 0.383439 -0.780672 0.125881 -0.477158 
1170 1085 62997 65356 65448 522 65374 0.382409 -0.779558 0.126616 -0.479605 
1180 978 62772 65402 65480 502 65398 0.381631 -0.7784 0.12732 -0.481914 
1191 843 62567 65404 65468 503 65461 0.381031 -0.777192 0.128262 -0.484083 
1201 736 62397 65489 65383 528 20 0.380401 -0.776001 0.129808 -0.486073 
1211 656 62202 12 65242 596 139 0.379532 -0.774816 0.132298 -0.487968 
1221 628 61995 72 65068 684 278 0.378275 -0.773633 0.135971 -0.489808 
1231 607 61834 118 64912 768 430 0.3767 -0.772408 0.140877 -0.491565 
1242 618 61669 216 64798 826 586 0.37498 -0.771105 0.146896 -0.493162 
1252 545 61339 196 64751 866 726 0.37334 -0.769645 0.153773 -0.494588 
1262 481 61046 242 64787 859 915 0.372252 -0.767937 0.161346 -0.49565 
1272 548 60856 349 64822 858 1147 0.371932 -0.765905 0.169709 -0.49624 
1282 649 60756 404 64776 927 1409 0.372126 -0.763476 0.179258 -0.496481 
1292 753 60759 495 64636 1043 1695 0.372453 -0.760628 0.190433 -0.496447 
1303 869 60735 528 64466 1184 1974 0.372627 -0.757343 0.203415 -0.496188 
1313 984 60730 530 64356 1301 2253 0.372807 -0.753527 0.218034 -0.495654 
1323 972 60462 400 64321 1373 2507 0.373224 -0.749116 0.233949 -0.494769 
1334 1066 60212 276 64482 1325 2780 0.374684 -0.743995 0.25054 -0.493268 
1344 1196 59999 204 64795 1202 3065 0.378029 -0.737993 0.267199 -0.490984 
1354 1326 59670 42 65156 1068 3374 0.383582 -0.730951 0.283751 -0.487914 
1366 1743 59421 65 65519 922 3736 0.39152 -0.722754 0.300248 -0.483932 
1375 2206 59433 0 202 927 4140 0.401331 -0.713167 0.317286 -0.479224 
1386 2708 59247 65257 188 1086 4517 0.411761 -0.702167 0.335694 -0.47405 
1397 2881 59073 65009 26 1309 4876 0.421847 -0.689939 0.355907 -0.468359 
1407 3388 59439 64783 65408 1477 5333 0.431582 -0.676279 0.378412 -0.461723 
1417 3656 59323 64934 65167 1661 5506 0.440681 -0.661708 0.401809 -0.454415 
1428 3766 59812 64181 64672 2024 5907 0.44731 -0.646059 0.428263 -0.446219 
1439 4220 60080 64524 64303 2029 6152 0.452706 -0.629853 0.456247 -0.436097 
1449 4287 60269 64062 64233 2078 6275 0.45709 -0.612909 0.48449 -0.425066 
1460 4618 61240 63828 64047 1985 6431 0.460972 -0.595318 0.512697 -0.412605 
1472 4582 61901 63500 63572 1958 6434 0.462962 -0.578037 0.541239 -0.398246 
1484 4489 61946 63574 63193 1767 6308 0.46317 -0.56169 0.569272 -0.381978 
1496 4288 61720 63843 63097 1465 6200 0.462902 -0.545841 0.595924 -0.364217 
1508 4308 61648 64178 63263 1100 6161 0.46337 -0.52994 0.620524 -0.345546 
1521 4393 62040 64388 63524 757 6155 0.465201 -0.51338 0.643032 -0.326404 
1532 4390 62256 64604 63665 486 6096 0.467872 -0.496483 0.663643 -0.306886 
1545 4538 62880 64988 63735 308 6058 0.470939 -0.479276 0.682779 -0.286921 
1556 4571 63475 65063 63780 223 5951 0.473878 -0.461896 0.700656 -0.266784 
1568 4381 64008 65198 63826 137 5768 0.476518 -0.444635 0.717189 -0.246719 
1580 4106 64443 65310 63825 87 5574 0.478747 -0.427691 0.732444 -0.226733 
1592 4315 64887 58 63947 65516 5372 0.480924 -0.410924 0.746287 -0.207144 
1603 4126 65201 61 64052 65493 5118 0.48283 -0.394526 0.758799 -0.188277 
1615 4028 31 160 64150 65479 4866 0.484423 -0.378538 0.770102 -0.17025 
1626 3923 320 265 64238 65483 4604 0.485666 -0.363077 0.780303 -0.153069 
1638 3783 630 284 64382 65481 4333 0.486631 -0.348119 0.789465 -0.136927 
1650 3883 1570 406 64552 65466 4097 0.487546 -0.333554 0.797602 -0.12195 
1662 4049 2549 379 64653 65524 3726 0.488096 -0.319709 0.80489 -0.108173 
1674 3954 3404 260 64628 113 3258 0.487673 -0.307535 0.811459 -0.095559 
1685 3939 3962 65524 64582 228 2713 0.486185 -0.297511 0.817336 -0.0840994 
1698 3796 4066 65327 64616 237 2105 0.484094 -0.2899 0.822262 -0.0741284 
1709 3627 3998 65379 64837 115 1489 0.482358 -0.284527 0.825819 -0.0663238 
1721 3551 3822 65511 65127 65524 912 0.481423 -0.281017 0.827968 -0.0610785 
1733 3399 3660 71 65378 65462 378 0.481082 -0.279233 0.828971 -0.0582763 
1744 3313 3388 124 7 65454 65420 0.480975 -0.279211 0.829087 -0.0576043 
1757 3292 3035 196 116 65480 64973 0.480849 -0.280919 0.828506 -0.0587014 
1768 3136 2512 65499 327 65463 64540 0.4808 -0.284152 0.827213 -0.0617122 
1780 3243 2403 83 717 65332 64121 0.481811 -0.288354 0.824716 -0.0674778 
1792 3222 2290 65280 816 65367 63770 0.482758 -0.293782 0.821611 -0.0747822 
1804 3317 2002 65091 898 65300 63398 0.483786 -0.300582 0.817709 -0.0833878 
1816 3484 1609 65194 974 65226 63033 0.485006 -0.308841 0.812833 -0.0932207 
1828 3778 1245 65253 1046 65185 62714 0.486298 -0.318365 0.807029 -0.104221 
1839 4103 888 65172 1102 65185 62420 0.487415 -0.328993 0.800414 -0.11631 
1851 4533 681 65152 1133 65183 62129 0.488216 -0.340737 0.79297 -0.129389 
1863 5114 692 65168 1039 65248 61841 0.488314 -0.353749 0.784815 -0.143094 
1875 5789 771 65040 701 65462 61556 0.486648 -0.368468 0.776428 -0.156731 
1886 6614 888 64890 263 207 61237 0.482415 -0.385242 0.768109 -0.169921 
1898 7493 978 64595 65431 480 60850 0.47548 -0.404179 0.759648 -0.183012 
1910 8453 927 64314 65212 657 60391 0.466209 -0.425224 0.750461 -0.196576 
1922 9538 908 64078 65280 636 59862 0.455659 -0.448085 0.739532 -0.211392 
1934 11079 894 64075 116 372 59235 0.445262 -0.472515 0.725504 -0.228286 
1946 13135 1510 64559 764 65430 58500 0.436348 -0.498401 0.706909 -0.247945 
1958 15064 2645 65020 1426 64984 57508 0.428849 -0.52614 0.682558 -0.270888 
1971 16894 2590 64818 1899 64558 56127 0.421188 -0.557029 0.651203 -0.297076 
1982 18403 418 65098 2562 63762 54508 0.41357 -0.591783 0.610225 -0.326156 
1995 20863 62983 357 3417 62589 52969 0.407486 -0.629224 0.557379 -0.356875 
2007 23450 59902 410 4420 61218 51492 0.403277 -0.667958 0.490856 -0.387631 
2019 25664 57622 64397 5590 59717 50355 0.401269 -0.705164 0.41066 -0.416031 
2031 29386 56322 64296 6055 57674 49224 0.399728 -0.740869 0.3167 -0.437066 
2043 32222 55604 64994 4605 56839 48029 0.389531 -0.775032 0.213608 -0.449394 
2056 21129 32768 18948 467 57695 47574 0.357601 -0.806582 0.116603 -0.456009 
2069 11773 32768 52328 1136 3824 7337 0.35385 -0.806539 0.116296 -0.459085 
2082 55918 32768 7909 4672 1537 1762 0.383656 -0.798237 0.106336 -0.452017 
2094 59212 26041 3970 4662 3546 10105 0.389725 -0.79752 0.1139 -0.446208 
2105 4591 9615 61179 2066 65276 65422 0.404806 -0.791955 0.107068 -0.444382 
2118 62086 4210 64843 64989 1066 64294 0.404004 -0.787124 0.109937 -0.452914 
2130 3734 64142 5283 64194 344 64589 0.40088 -0.787528 0.110841 -0.454762 
2142 2192 64976 60043 63784 3187 65252 0.391635 -0.783982 0.119988 -0.466474 
2153 1286 2033 679 64741 1176 65474 0.386549 -0.782488 0.126969 -0.471351 
2165 4480 773 57695 65029 707 65162 0.382874 -0.781362 0.128611 -0.475753 
2178 63619 703 1318 64661 65455 64235 0.379293 -0.782021 0.127722 -0.477773 
2189 64168 64002 64488 65044 65418 64821 0.376924 -0.782865 0.126869 -0.478493 
2202 65348 55277 62223 64887 198 64870 0.37256 -0.784233 0.125699 -0.479977 
2214 3810 62958 64472 65208 23 64815 0.369404 -0.785739 0.124268 -0.480325 
2226 65245 3061 6060 204 65114 64898 0.368638 -0.786315 0.120956 -0.480816 
2238 669 61538 63121 1162 64677 65193 0.371144 -0.787158 0.115295 -0.478897 
2249 268 61485 63292 804 64797 64784 0.372891 -0.788023 0.108625 -0.477673 
2262 1117 65168 1204 795 64677 64701 0.375201 -0.788718 0.101989 -0.476179 
2273 736 63790 65241 691 64813 64785 0.376891 -0.789498 0.095411 -0.474913 
2285 1112 64001 72 488 64968 64754 0.377551 -0.790273 0.0896281 -0.474226 
2297 1084 63745 65375 356 65071 64795 0.377638 -0.790986 0.0845842 -0.473895 
2309 1094 63816 65295 330 65113 64851 0.377553 -0.791658 0.0800096 -0.473635 
2320 1185 63591 65156 384 65092 64920 0.377783 -0.792244 0.0756155 -0.473193 
2333 1073 63586 64984 555 65045 64979 0.378765 -0.792612 0.0710818 -0.472494 
2344 1262 63721 65093 775 64985 65075 0.380884 -0.792656 0.0662129 -0.471423 
2356 1327 63892 65178 922 64939 65186 0.383976 -0.792419 0.0612402 -0.469983 
2368 1359 63873 65236 949 64983 65286 0.387539 -0.791942 0.0565747 -0.468445 
2380 1407 63905 65323 884 65088 65387 0.391114 -0.791271 0.0526115 -0.467068 
2392 1474 63937 65273 759 65214 65484 0.394408 -0.790474 0.0495887 -0.465977 
2404 1479 64030 65248 644 65361 41 0.397392 -0.789532 0.0475634 -0.465249 
2416 1512 64033 65165 544 65498 128 0.400087 -0.788449 0.0464485 -0.464888 
2428 1485 64019 65019 451 83 197 0.402535 -0.787236 0.0461467 -0.46486 
2439 1471 64134 64875 386 173 255 0.404765 -0.785947 0.0465023 -0.46507 
2452 1635 64258 64884 364 226 291 0.40692 -0.784571 0.0472313 -0.46544 
2463 1608 64274 64835 364 262 309 0.409069 -0.783099 0.0481251 -0.465944 
2476 1653 64268 64697 372 269 334 0.411286 -0.781579 0.0491203 -0.466439 
2487 1652 64304 64660 382 251 363 0.4136 -0.780072 0.0501742 -0.466803 
2499 1674 64445 64700 384 229 394 0.416 -0.778592 0.0512973 -0.46702 
2511 1737 64539 64770 347 219 404 0.418313 -0.777201 0.0524952 -0.467136 
2523 1772 64559 64715 282 234 387 0.420343 -0.775907 0.0538014 -0.467318 
2535 1738 64649 64594 211 233 371 0.42202 -0.774768 0.0552309 -0.467529 
2546 1782 64673 64586 167 206 333 0.423393 -0.773819 0.056601 -0.467695 
2611 1782 64673 64586 167 206 333 -0.467794 0.111022 -0.0567626 0.00988796 
2622 1492 64194 64735 244 55 65401 0.403092 -0.760748 0.0239398 -0.508139 
2632 1528 64234 64733 246 17 65422 0.403721 -0.760231 0.0228611 -0.508464 
2642 1533 64264 64811 237 65516 65444 0.404379 -0.759826 0.0217987 -0.508593 
2656 1565 64283 64791 227 65484 65458 0.405047 -0.759523 0.0207485 -0.508558 
2666 1579 64271 64844 214 65461 65471 0.405698 -0.75931 0.0197269 -0.508398 
2676 1560 64328 64900 208 65445 65487 0.406364 -0.759155 0.0187487 -0.508134 
2687 1586 64333 64951 193 65428 65493 0.407006 -0.759061 0.0177956 -0.507795 
2697 1582 64338 65007 173 65430 65504 0.4076 -0.759008 0.0169239 -0.507427 
2707 1579 64332 65048 150 65446 65517 0.408146 -0.758957 0.0161931 -0.507089 
2718 1622 64296 65102 123 65475 65529 0.408621 -0.758883 0.0156411 -0.506834 
2729 1639 64267 65189 101 65507 17 0.409052 -0.758768 0.0153043 -0.506669 
2739 1626 64342 65190 93 16 39 0.409508 -0.758553 0.0151771 -0.506626 
2750 1606 64371 65169 89 54 47 0.409965 -0.758238 0.0151969 -0.506727 
2760 1612 64381 65175 89 86 56 0.410443 -0.757833 0.0153183 -0.506944 
2770 1632 64405 65172 83 126 60 0.410906 -0.75734 0.0155509 -0.507298 
2781 1623 64390 65149 57 166 63 0.411285 -0.756786 0.0159399 -0.507805 
2791 1628 64409 65096 31 209 72 0.411576 -0.756173 0.0165268 -0.508462 
2802 1604 64385 65023 7 235 73 0.41176 -0.755542 0.0172689 -0.509227 
2812 1617 64376 65014 2 237 77 0.411902 -0.754922 0.0180654 -0.510004 
2822 1614 64372 64977 7 233 85 0.412076 -0.754306 0.018881 -0.510743 
2833 1606 64374 64909 25 215 91 0.412315 -0.753703 0.0196381 -0.511411 
2843 1612 64395 64924 53 184 91 0.412671 -0.753121 0.0202906 -0.511957 
2854 1619 64355 64938 93 142 89 0.413173 -0.752565 0.0207347 -0.512352 
2865 1629 64347 64884 135 104 98 0.413866 -0.752021 0.0210027 -0.512581 
2875 1642 64377 64902 170 60 97 0.414708 -0.751519 0.021088 -0.512632 
2885 1678 64346 64912 212 18 101 0.415715 -0.751043 0.0209788 -0.512519 
2896 1654 64379 64870 251 65510 102 0.416893 -0.750593 0.0206722 -0.512234 
2906 1657 64381 64927 271 65473 99 0.418172 -0.750195 0.0201867 -0.511793 
2916 1674 64377 64941 269 65454 99 0.419465 -0.749844 0.0196406 -0.51127 
2927 1684 64365 64966 247 65443 96 0.420692 -0.74956 0.0191018 -0.510699 
2937 1688 64414 65013 215 65445 100 0.421799 -0.749342 0.0186509 -0.510123 
2948 1695 64406 65031 181 65451 97 0.422766 -0.749184 0.0182948 -0.509565 
2958 1683 64424 65048 145 65458 91 0.423569 -0.749088 0.0180312 -0.509049 
2969 1701 64433 65105 120 65459 85 0.424249 -0.749046 0.0178199 -0.508553 
2979 1720 64440 65087 97 65466 72 0.42481 -0.749031 0.0176409 -0.508111 
2989 1703 64443 65132 78 65476 64 0.425262 -0.749039 0.0174977 -0.507727 
3000 1697 64472 65111 74 65475 48 0.425648 -0.74905 0.0173231 -0.507392 
3010 1703 64450 65130 78 65472 27 0.425983 -0.749069 0.0170518 -0.507092 
3021 1690 64450 65178 87 65462 5 0.426299 -0.749094 0.0166621 -0.506803 
3031 1721 64436 65175 111 65447 65516 0.42663 -0.749105 0.0160832 -0.506527 
3042 1702 64443 65199 141 65424 65490 0.427006 -0.74911 0.0152818 -0.506229 
3052 1702 64453 65198 168 65407 65460 0.427428 -0.749098 0.0142398 -0.505919 
3062 1681 64484 65223 184 65397 65439 0.427859 -0.74908 0.0130278 -0.505614 
3073 1646 64480 65199 185 65395 65413 0.428244 -0.749054 0.0116972 -0.50536 
3083 1650 64463 65241 199 65384 65391 0.428606 -0.749029 0.0102291 -0.505122 
3094 1643 64467 65273 232 65369 65365 0.429022 -0.748971 0.00855507 -0.504886 
3105 1652 64465 65269 243 65367 65343 0.429445 -0.748889 0.0067221 -0.504676 
4000 0 2 12 0 65379 65328 0.429784 -0.7488 0.00487266 -0.50454 
5125 1625 64442 65308 209 65391 65317 0.430027 -0.748714 0.00306015 -0.504475 
5136 1690 64416 65318 184 65412 65309 0.430153 -0.748628 0.00132293 -0.504503 
5146 1724 64363 65387 161 65432 65302 0.430166 -0.748538 -0.000331912 -0.504626 
5156 1685 64371 65370 157 65456 65302 0.430144 -0.748388 -0.00192093 -0.504864 
5167 1649 64402 65382 173 65474 65302 0.430172 -0.748164 -0.00349096 -0.505164 
5177 1637 64368 65396 180 65494 65304 0.430239 -0.747864 -0.00503543 -0.505537 
5187 1649 64369 65364 192 65520 65312 0.430374 -0.747468 -0.00651747 -0.505991 
5198 1634 64355 65357 204 2 65320 0.430582 -0.74699 -0.00795468 -0.506499 
5209 1657 64305 65373 214 30 65328 0.430843 -0.746422 -0.00933462 -0.50709 
5219 1661 64341 65314 226 57 65342 0.431187 -0.745753 -0.0106144 -0.507757 
5230 1616 64360 65335 247 75 65357 0.43164 -0.744993 -0.0118553 -0.50846 
5240 1605 64339 65306 275 85 65369 0.432227 -0.744145 -0.0130783 -0.509173 
5250 1606 64371 65249 302 91 65383 0.432964 -0.743216 -0.0143097 -0.509871 
5261 1608 64332 65206 328 91 65395 0.43383 -0.742226 -0.0155611 -0.510539 
5271 1625 64353 65242 354 91 65410 0.434833 -0.741183 -0.016824 -0.511161 
5282 1605 64352 65190 377 90 65423 0.43597 -0.740081 -0.0180977 -0.511746 
5292 1600 64332 65177 403 80 65440 0.437238 -0.738948 -0.0193928 -0.512253 
5303 1608 64352 65168 431 76 65455 0.438654 -0.737767 -0.0207173 -0.512692 
5313 1626 64345 65194 446 70 65464 0.44016 -0.73656 -0.0220695 -0.51308 
5324 1663 64337 65177 443 76 65474 0.4417 -0.735337 -0.0233851 -0.513453 
5334 1663 64357 65136 419 101 65487 0.443196 -0.734098 -0.0245527 -0.513881 
5345 1684 64360 65177 372 136 65498 0.444561 -0.73287 -0.0254878 -0.51441 
5355 1680 64368 65127 313 178 65512 0.44575 -0.731663 -0.0261276 -0.515066 
5365 1680 64357 65118 247 218 65527 0.446726 -0.730505 -0.0264238 -0.51585 
5376 1675 64361 65086 198 249 2 0.44752 -0.729387 -0.0264384 -0.516742 
5386 1654 64339 65053 172 260 11 0.448213 -0.728306 -0.0262907 -0.517672 
5397 1642 64360 65032 174 248 13 0.448901 -0.727253 -0.0261356 -0.518564 
5407 1619 64363 65017 198 226 15 0.449658 -0.726215 -0.0260738 -0.519365 
5418 1602 64355 65037 216 193 17 0.450493 -0.725214 -0.0261316 -0.520036 
5428 1602 64351 65034 235 162 21 0.451405 -0.724256 -0.0262999 -0.520572 
2016-12-14 02:29:54.999 TestLib[51451:1187560] m3:
1670 64201 979 63617 2269 216 2485 -0.368416 -0.78274 -0.500695 0.0298663 
1680 64061 1238 63724 2145 65486 2421 -0.359388 -0.793597 -0.48999 0.0308832 
1690 64260 1330 63863 1232 65026 1538 -0.354334 -0.801029 -0.481348 0.0332168 
1701 64663 930 63934 65477 64990 203 -0.354888 -0.802762 -0.477895 0.0352547 
1711 64847 562 63846 64590 65361 64760 -0.358533 -0.799825 -0.480061 0.035725 
1721 64915 395 63552 64075 49 64566 -0.364029 -0.794759 -0.484444 0.033994 
1731 64850 218 63459 64256 47 64834 -0.369291 -0.79011 -0.488196 0.0318569 
1741 64762 129 63436 64913 60 65480 -0.372305 -0.787965 -0.489485 0.0300789 
1751 64696 293 63490 25 14 687 -0.372463 -0.789131 -0.487563 0.0287245 
1762 64650 494 63648 398 65477 970 -0.371303 -0.792214 -0.483476 0.0279631 
1772 64612 566 63865 403 6 802 -0.369468 -0.795302 -0.479823 0.0275469 
1782 64559 596 63874 65522 198 443 -0.368659 -0.796924 -0.477822 0.0262201 
1792 64528 471 63711 65136 405 65503 -0.369036 -0.796565 -0.478256 0.0238153 
1802 64492 350 63479 64954 344 65328 -0.370192 -0.795062 -0.47998 0.0212813 
1813 64401 208 63388 65098 1 65512 -0.371865 -0.793905 -0.480661 0.0199133 
1823 64401 212 63635 65512 65187 262 -0.372925 -0.794125 -0.479449 0.0205068 
1833 64523 338 63838 203 64987 480 -0.373453 -0.795527 -0.476621 0.0224186 
1844 64602 509 63746 107 65239 416 -0.373694 -0.796937 -0.474009 0.0236398 
1854 64628 557 63388 65343 65427 147 -0.374481 -0.797254 -0.472858 0.0235605 
1864 64622 433 63388 65273 65240 3 -0.375966 -0.796788 -0.472448 0.0239172 
1874 64644 286 63622 65522 64989 185 -0.377463 -0.796877 -0.471011 0.0256385 
1884 64648 215 63956 381 65110 468 -0.37732 -0.798423 -0.468382 0.0277248 
1894 64659 228 64100 490 30 660 -0.375432 -0.800948 -0.465548 0.0282545 
1905 64581 326 63885 325 681 657 -0.372577 -0.80343 -0.463707 0.0257271 
1915 64494 339 63557 164 964 565 -0.369342 -0.805403 -0.463102 0.0212123 
1925 64462 308 63396 178 836 578 -0.366379 -0.807226 -0.462459 0.0168351 
1936 64501 361 63378 420 559 761 -0.36319 -0.809717 -0.46072 0.0137473 
1946 64475 541 63481 790 279 1071 -0.359219 -0.813515 -0.457172 0.0121821 
1956 64384 747 63605 1213 65522 1390 -0.354246 -0.81883 -0.451528 0.0122518 
1967 64348 914 63812 1497 65353 1446 -0.348341 -0.824971 -0.444852 0.0137248 
1977 64354 1081 63900 1518 65185 1280 -0.342391 -0.830871 -0.438353 0.0163822 
1987 64369 1181 63947 1279 65102 1085 -0.337499 -0.835882 -0.432457 0.0194167 
1998 64312 1158 63975 937 65042 843 -0.334225 -0.839697 -0.427435 0.0223838 
2008 64321 1028 63933 600 64982 546 -0.332511 -0.842218 -0.423631 0.02532 
2019 64383 869 63907 471 65004 308 -0.331593 -0.843779 -0.421046 0.0283625 
2029 64436 815 63799 423 64998 332 -0.330909 -0.845142 -0.418635 0.0312819 
2039 64549 823 63737 459 64967 384 -0.330152 -0.846667 -0.415911 0.0342389 
2049 64650 839 63807 496 65015 415 -0.32918 -0.848313 -0.413069 0.0371377 
2060 64609 896 63834 477 65227 469 -0.327836 -0.85009 -0.410291 0.0391411 
2070 64507 990 63834 391 65448 464 -0.32634 -0.851811 -0.407835 0.0398993 
2080 64475 947 63792 257 65424 314 -0.325298 -0.853056 -0.406013 0.0403858 
2091 64595 868 63813 185 65288 231 -0.324907 -0.853853 -0.404537 0.0414841 
2101 64662 869 63744 201 65153 337 -0.324823 -0.854758 -0.40253 0.0429874 
2110 64697 865 63830 270 65051 441 -0.324726 -0.855984 -0.399773 0.0450072 
2121 64689 889 63878 249 65140 476 -0.32454 -0.857335 -0.396821 0.0467338 
2131 64656 883 63821 165 65302 387 -0.324338 -0.858467 -0.394415 0.0477077 
2141 64665 841 63887 67 65485 247 -0.32417 -0.859185 -0.392961 0.0479243 
2151 64616 795 63719 65461 188 156 -0.324064 -0.859517 -0.392436 0.0469849 
2161 64542 690 63652 65441 214 86 -0.323991 -0.859629 -0.392412 0.045609 
2172 64428 641 63730 65530 52 111 -0.323937 -0.859783 -0.39218 0.045076 
2182 64353 817 63723 94 65499 199 -0.323591 -0.860299 -0.391335 0.0450824 
2192 64517 799 63674 41 65324 76 -0.323641 -0.86058 -0.390575 0.0459276 
2202 64778 703 63772 25 65228 71 -0.324081 -0.86067 -0.389852 0.0472669 
2213 64759 679 63750 65522 65268 373 -0.324693 -0.861165 -0.388136 0.0481546 
2223 64617 904 63836 279 65463 485 -0.323786 -0.862557 -0.38577 0.04837 
2233 64575 982 63948 222 65464 329 -0.322929 -0.863717 -0.383859 0.0485981 
2243 64626 1007 63896 28 65522 143 -0.322672 -0.864216 -0.382944 0.0486634 
2253 64681 929 63803 65410 98 65526 -0.322963 -0.864111 -0.382998 0.0481595 
2264 64681 913 63714 65378 195 65510 -0.323343 -0.863819 -0.383467 0.0471043 
2274 64606 895 63666 65380 198 31 -0.323651 -0.863619 -0.383812 0.045832 
2284 64559 901 63711 65455 146 39 -0.323673 -0.863596 -0.383954 0.0449176 
2294 64550 927 63695 65425 96 57 -0.323943 -0.863532 -0.383954 0.0441843 
2305 64542 1020 63701 65492 28 31 -0.324126 -0.863519 -0.383868 0.0438411 
2314 64611 1017 63735 65435 65443 65480 -0.324537 -0.863306 -0.383969 0.0441112 
2325 64655 994 63750 65441 65371 65351 -0.325252 -0.862781 -0.384452 0.0449062 
2335 64662 1026 63779 65406 65378 65289 -0.326063 -0.862044 -0.385303 0.0458717 
2345 64672 985 63798 65333 65399 65313 -0.327134 -0.861207 -0.386179 0.0465939 
2356 64638 1007 63775 65344 65416 65298 -0.328257 -0.860354 -0.387057 0.0471662 
2366 64657 981 63796 65298 65382 65286 -0.329551 -0.859405 -0.387984 0.0478389 
2376 64643 991 63868 65270 65366 65288 -0.330981 -0.858389 -0.388924 0.0485573 
2386 64617 987 63840 65232 65405 65298 -0.332499 -0.857334 -0.38989 0.0490749 
2396 64633 988 63883 65241 65488 65216 -0.333921 -0.856181 -0.39117 0.0493698 
2406 64649 969 63891 65134 65520 65141 -0.335562 -0.854726 -0.392939 0.049398 
2417 64649 966 63873 65030 46 65101 -0.337612 -0.852961 -0.395057 0.0490488 
2427 64651 947 63861 64998 86 65076 -0.339693 -0.851057 -0.397447 0.0484464 
2437 64646 971 63799 65013 91 65080 -0.341762 -0.849154 -0.399818 0.0477689 
2447 64652 959 63811 65046 89 65066 -0.343667 -0.847268 -0.402244 0.0472102 
2457 64646 974 63857 65054 179 65017 -0.345354 -0.845341 -0.404936 0.0464347 
2467 64644 968 63831 65007 279 64939 -0.346928 -0.843206 -0.408157 0.0453035 
2478 64639 947 63825 64863 438 64842 -0.348759 -0.840655 -0.412049 0.0433829 
2488 64595 860 63839 64810 562 64797 -0.350549 -0.837825 -0.416528 0.0408492 
2498 64490 849 63798 64802 658 64847 -0.352202 -0.835024 -0.421026 0.0377566 
2508 64470 836 63755 64810 650 64836 -0.353768 -0.832224 -0.425507 0.034589 
2518 64539 807 63769 64827 575 64769 -0.355371 -0.829264 -0.43014 0.0318346 
2528 64539 802 63806 64843 564 64753 -0.356981 -0.826231 -0.434796 0.0293226 
2539 64454 781 63819 64836 634 64755 -0.358431 -0.823185 -0.439531 0.026573 
2549 64346 683 63886 64769 691 64696 -0.359929 -0.819908 -0.444577 0.0235264 
2559 64302 514 63958 64644 704 64601 -0.361837 -0.816154 -0.450059 0.0203148 
2570 64313 453 63934 64494 739 64519 -0.364283 -0.811864 -0.455951 0.01684 
2580 64311 383 63792 64332 725 64493 -0.36735 -0.807106 -0.462023 0.0130023 
2590 64446 318 63708 64220 613 64399 -0.371058 -0.801875 -0.468214 0.0093961 
2601 64591 187 63652 64207 550 64373 -0.375162 -0.796324 -0.47443 0.00612336 
2611 64658 137 63533 64301 593 64475 -0.378781 -0.79106 -0.480355 0.00279222 
2621 64778 120 63421 64504 583 64693 -0.381668 -0.786561 -0.485439 -0.000545471 
2631 64889 73 63410 64795 409 65013 -0.38362 -0.783376 -0.489028 -0.00318731 
2641 64940 133 63478 65176 245 65476 -0.384506 -0.782044 -0.490445 -0.00507621 
2651 64809 383 63540 65458 86 362 -0.384518 -0.782526 -0.489651 -0.00638497 
2661 64780 531 63632 65524 107 385 -0.384114 -0.7836 -0.488232 -0.00752886 
2671 64780 694 63667 51 405 134 -0.383099 -0.784219 -0.488009 -0.00912397 
2681 64838 771 63541 65456 711 65499 -0.381452 -0.784118 -0.489403 -0.0118017 
2692 64920 920 63588 0 859 65461 -0.37924 -0.783817 -0.491504 -0.0152273 
2702 64701 1048 63535 65532 921 149 -0.376761 -0.784006 -0.492968 -0.0191631 
2712 64419 1196 63444 128 948 143 -0.37374 -0.784539 -0.494245 -0.0232286 
2723 64381 1197 63556 132 545 65342 -0.37133 -0.784489 -0.496034 -0.0253256 
2733 64540 1053 63734 28 139 64934 -0.370554 -0.783217 -0.498633 -0.0250349 
2743 64645 926 63870 65495 39 64770 -0.370569 -0.78118 -0.501868 -0.0237614 
2754 64687 861 64007 65469 65521 64813 -0.370871 -0.779062 -0.50499 -0.0224314 
2763 64717 903 64133 65465 65424 64862 -0.371419 -0.777124 -0.507636 -0.020806 
2774 64846 933 64063 65269 65449 64749 -0.372613 -0.774705 -0.510506 -0.0193801 
2784 64868 812 63957 64905 135 64439 -0.374668 -0.770837 -0.514847 -0.0191761 
2794 64773 610 63714 64613 359 64254 -0.377461 -0.765629 -0.520502 -0.0203386 
2805 64689 491 63493 64624 375 64316 -0.380172 -0.760244 -0.526325 -0.0219077 
2815 64661 481 63349 64836 187 64580 -0.382488 -0.755807 -0.530978 -0.0228132 
2824 64603 490 63299 65108 65443 64904 -0.38443 -0.752825 -0.533815 -0.0225641 
2835 64543 566 63342 65341 65130 65209 -0.386216 -0.751255 -0.5348 -0.0209925 
2845 64499 667 63376 65469 64892 65393 -0.388111 -0.750663 -0.534355 -0.0184221 
2855 64516 717 63526 65480 64728 65350 -0.390396 -0.750181 -0.533473 -0.0150252 
2866 64576 674 63598 65439 64679 65232 -0.393057 -0.749302 -0.532847 -0.0112091 
2876 64649 631 63701 65409 64725 65148 -0.395782 -0.748071 -0.532627 -0.0073764 
2886 64673 580 63783 65370 64858 65091 -0.398305 -0.746563 -0.532899 -0.0039778 
2896 64684 556 63755 65346 65004 65069 -0.400517 -0.744896 -0.533586 -0.00118231 
2906 64680 545 63748 65354 65069 65076 -0.402476 -0.743207 -0.534466 0.00124065 
2916 64709 527 63775 65405 65065 65152 -0.404239 -0.741757 -0.535139 0.00363248 
2927 64715 584 63805 65482 65089 65288 -0.405677 -0.740814 -0.535338 0.00591499 
2937 64699 628 63844 65533 65166 65401 -0.406717 -0.740342 -0.535176 0.00782597 
2946 64614 650 63857 2 65283 65466 -0.407393 -0.740137 -0.534924 0.00919711 
2957 64575 662 63862 65486 65376 65410 -0.407909 -0.739785 -0.535002 0.010095 
4000 0 2 12 0 65419 65321 -0.40848 -0.739046 -0.535572 0.0108456 
4977 64593 605 63742 65451 65424 65346 -0.40901 -0.738281 -0.536207 0.0115291 
4987 64588 615 63749 0 65408 65475 -0.409317 -0.73797 -0.536386 0.012248 
4998 64522 644 63759 69 65432 59 -0.40929 -0.738204 -0.536071 0.0128427 
5008 64499 690 63814 84 65449 94 -0.409127 -0.738659 -0.535556 0.0133242 
5018 64471 686 63786 49 65489 87 -0.408964 -0.739058 -0.535123 0.0136089 
5028 64467 695 63773 18 65517 65 -0.408828 -0.739329 -0.53485 0.0136998 
5039 64482 679 63765 6 65512 66 -0.408753 -0.739539 -0.534616 0.0137511 
5049 64483 728 63771 21 65490 102 -0.408692 -0.73985 -0.534229 0.0138292 
5059 64477 766 63781 44 65460 138 -0.408625 -0.740318 -0.533627 0.0140053 
5070 64470 796 63820 53 65425 138 -0.408629 -0.740832 -0.532903 0.0143281 
5080 64502 788 63906 41 65424 137 -0.408698 -0.741323 -0.532156 0.014681 
5090 64497 770 63850 22 65454 124 -0.408772 -0.741742 -0.531508 0.0149031 
5101 64478 764 63819 28 65462 134 -0.408803 -0.742169 -0.530885 0.0150557 
5111 64456 775 63857 48 65452 147 -0.408782 -0.742676 -0.530185 0.0152554 
5121 64466 776 63836 52 65459 143 -0.408712 -0.743207 -0.529489 0.01548 
5131 64479 791 63865 52 65473 116 -0.408604 -0.743678 -0.528904 0.0156825 
5142 64477 800 63796 54 65472 92 -0.408497 -0.744072 -0.528425 0.0159494 
5154 64461 794 63786 54 65481 71 -0.408357 -0.744412 -0.528045 0.016235 
5166 64436 812 63817 56 65475 55 -0.408213 -0.744709 -0.527728 0.0165657 
5177 64418 801 63818 53 65459 44 -0.408119 -0.744963 -0.527429 0.0169892 
5189 64406 782 63840 45 65441 30 -0.408098 -0.745162 -0.527147 0.0174841 
5201 64427 773 63852 29 65423 10 -0.408186 -0.745276 -0.526898 0.0180595 
5213 64422 749 63838 9 65423 65535 -0.408359 -0.745305 -0.526704 0.0186258 
5225 64436 741 63839 0 65401 65531 -0.40862 -0.745292 -0.526498 0.0192322 
5236 64445 711 63825 10 65367 5 -0.408949 -0.745305 -0.526197 0.0199693 
5248 64452 715 63834 28 65346 43 -0.409279 -0.74544 -0.525718 0.0207798 
5260 64449 738 63851 55 65339 71 -0.409547 -0.745712 -0.525087 0.0216366 
5272 64460 746 63872 66 65362 81 -0.409709 -0.746065 -0.524426 0.0224346 
5284 64446 753 63840 60 65373 82 -0.409846 -0.746424 -0.523776 0.0231526 
5295 64458 757 63837 59 65364 73 -0.409988 -0.746754 -0.52316 0.0238924 
5307 64468 772 63841 60 65350 69 -0.410177 -0.747066 -0.522529 0.0247109 
5319 64460 761 63830 58 65357 74 -0.410357 -0.747387 -0.52189 0.0255098 
5331 64467 768 63837 54 65356 71 -0.410542 -0.747701 -0.521257 0.0262835 
5342 64482 771 63868 55 65332 51 -0.410784 -0.747963 -0.520644 0.0271576 
5354 64495 757 63895 60 65331 52 -0.41104 -0.748214 -0.52003 0.0281019 
5366 64481 776 63859 67 65365 67 -0.411192 -0.748522 -0.519422 0.0289266 
5378 64493 781 63845 66 65400 74 -0.411242 -0.748862 -0.518855 0.0295796 
5389 64490 786 63871 51 65425 70 -0.411265 -0.749178 -0.51835 0.0301039 
5401 64462 784 63860 36 65444 56 -0.411295 -0.749427 -0.517942 0.030531 
5416 64473 765 63853 26 65449 55 -0.411343 -0.749636 -0.517579 0.0308995 
5427 64450 747 63843 24 65454 56 -0.411391 -0.74984 -0.517224 0.0312416 
5439 64421 744 63838 15 65442 56 -0.411483 -0.750031 -0.516854 0.0315938 
5451 64438 724 63836 8 65405 47 -0.411687 -0.750176 -0.51645 0.032069 
5462 64424 705 63848 6 65372 40 -0.412 -0.75029 -0.515996 0.0327008 
5475 64429 677 63864 15 65348 42 -0.412351 -0.750412 -0.515489 0.0334569 
5486 64482 696 63849 31 65337 56 -0.412683 -0.750594 -0.514904 0.0342803 
5498 64485 717 63833 64 65340 78 -0.412915 -0.750892 -0.514225 0.0351316 
5510 64487 717 63831 107 65351 110 -0.412957 -0.751366 -0.51344 0.0359924 
5521 64484 727 63887 163 65393 134 -0.412707 -0.752037 -0.5126 0.0368042 
5533 64469 747 63853 196 65438 154 -0.412166 -0.752856 -0.511782 0.0375006 
5545 64466 765 63871 203 65437 172 -0.411558 -0.753754 -0.510902 0.0381318 
5557 64447 797 63888 174 65418 162 -0.411071 -0.754611 -0.509978 0.0388002 
5569 64452 790 63899 158 65447 100 -0.410636 -0.755273 -0.509299 0.039439 
5580 64449 793 63901 118 65459 66 -0.410237 -0.755751 -0.508865 0.0400203 
5592 64439 769 63896 56 65438 53 -0.410146 -0.75605 -0.508456 0.0405234 
5604 64438 744 63863 26 65461 20 -0.410154 -0.756186 -0.508212 0.0409448 
5616 64457 731 63860 6 65469 3 -0.410206 -0.756224 -0.508085 0.0413007 
5628 64435 719 63840 5 65474 13 -0.410265 -0.756254 -0.507968 0.0416174 
5639 64410 733 63799 31 65475 35 -0.410246 -0.756385 -0.507761 0.0419286 
5651 64416 732 63839 70 65452 54 -0.410119 -0.756646 -0.507439 0.0423695 
5663 64427 732 63876 108 65448 60 -0.409876 -0.757015 -0.507037 0.0429379 
5675 64420 757 63871 114 65474 65 -0.409522 -0.757431 -0.506658 0.0434514 
5686 64412 728 63841 105 65489 55 -0.409148 -0.757823 -0.506336 0.043877 
5698 64421 752 63857 83 65467 43 -0.408869 -0.758138 -0.506051 0.0443424 
5710 64413 759 63887 66 65451 24 -0.408719 -0.758358 -0.505795 0.0448692 
5722 64413 734 63867 48 65446 10 -0.40866 -0.758501 -0.50558 0.0454101 
5733 64425 741 63857 41 65447 65523 -0.408626 -0.758565 -0.505461 0.0459671 
5745 64424 732 63855 30 65427 65526 -0.408683 -0.758592 -0.505318 0.0465807 
5757 64421 716 63873 41 65434 65519 -0.408705 -0.758625 -0.505193 0.0472066 
5769 64423 710 63853 41 65444 65514 -0.408691 -0.758646 -0.505115 0.0478216 
5780 64416 712 63852 34 65444 65522 -0.408693 -0.758671 -0.505021 0.0483945 
5792 64422 716 63867 47 65466 65516 -0.408608 -0.758707 -0.504985 0.0489308 
5804 64387 706 63874 39 65474 65526 -0.408513 -0.758766 -0.504926 0.049404 
5815 64380 686 63874 41 65481 65523 -0.408391 -0.75882 -0.504902 0.049836 
5828 64385 664 63860 33 65438 4 -0.408375 -0.758883 -0.504767 0.0503654 
5839 64385 678 63841 12 65438 65529 -0.408483 -0.758894 -0.504608 0.0509114 
5851 64403 662 63839 34 65459 65499 -0.408467 -0.758855 -0.504628 0.0514324 
5863 64401 676 63850 43 65423 8 -0.408485 -0.75891 -0.504467 0.0520452 
5874 64402 688 63860 79 65454 27 -0.408371 -0.75911 -0.504199 0.0526257 
5887 64384 707 63875 83 65448 37 -0.408165 -0.759374 -0.503908 0.0531954 
5898 64373 705 63850 82 65462 36 -0.407962 -0.759644 -0.503607 0.0537359 
5910 64382 699 63864 68 65458 20 -0.407761 -0.759864 -0.503381 0.054268 
5922 64385 680 63875 51 65424 10 -0.407718 -0.76 -0.503143 0.0548867 
5933 64396 700 63867 43 65399 2 -0.407804 -0.760078 -0.502877 0.0556094 
5946 64425 694 63870 51 65422 65534 -0.407841 -0.760158 -0.502649 0.0563034 
5957 64403 681 63869 65 65449 9 -0.407738 -0.76029 -0.502465 0.0568973 
5969 64397 694 63877 71 65457 27 -0.407581 -0.760487 -0.502234 0.057428 
5981 64391 718 63883 85 65475 25 -0.407342 -0.760726 -0.502011 0.0579116 
5992 64369 703 63850 74 65447 35 -0.407162 -0.760968 -0.501728 0.0584517 
6004 64392 707 63863 70 65436 22 -0.407045 -0.761179 -0.501432 0.0590498 
6016 64384 706 63864 54 65435 1 -0.406979 -0.761301 -0.501228 0.059665 
6027 64381 682 63876 27 65447 65525 -0.407001 -0.761333 -0.501095 0.0602236 
6040 64365 683 63856 24 65460 65504 -0.406992 -0.761297 -0.501096 0.0607209 
6051 64364 690 63889 23 65430 65511 -0.407069 -0.761248 -0.501037 0.0613098 
6063 64379 691 63871 9 65455 65499 -0.407141 -0.761168 -0.501031 0.0618605 
6075 64367 676 63886 3 65478 65493 -0.407182 -0.761052 -0.501126 0.0622557 
6086 64369 656 63871 65529 65436 65509 -0.407337 -0.760939 -0.501108 0.0627629 
6098 64347 645 63878 65523 65479 65501 -0.40747 -0.760822 -0.501124 0.0631888 
6110 64354 648 63866 10 65485 65488 -0.407449 -0.760706 -0.501269 0.0635681 
6121 64365 651 63846 29 65431 65511 -0.407495 -0.760653 -0.501238 0.0641447 
6134 64347 659 63857 54 65419 65515 -0.407503 -0.760674 -0.501108 0.064859 
6145 64362 663 63891 54 65405 65529 -0.407513 -0.760735 -0.500906 0.0656379 
6157 64352 683 63871 51 65429 65525 -0.407512 -0.760793 -0.500727 0.0663358 
6169 64330 660 63874 36 65436 65515 -0.407513 -0.7608 -0.500633 0.0669588 
6180 64330 631 63917 34 65420 65519 -0.407575 -0.760788 -0.500511 0.0676286 
6192 64325 647 63874 23 65436 65515 -0.40765 -0.760765 -0.5004 0.0682519 
6204 64331 653 63878 37 65403 65504 -0.407729 -0.760718 -0.500307 0.0689766 
6216 64345 670 63880 37 65375 65497 -0.407887 -0.760648 -0.500162 0.0698586 
6227 64360 670 63866 28 65378 65494 -0.408067 -0.760563 -0.500018 0.0707651 
6239 64356 662 63858 18 65400 65468 -0.408255 -0.760401 -0.499994 0.0715828 
6251 64341 673 63874 32 65389 65463 -0.408386 -0.760222 -0.500031 0.0724752 
6263 64350 659 63904 52 65384 65490 -0.408477 -0.760136 -0.499951 0.0734021 
6275 64333 665 63895 58 65392 65499 -0.408529 -0.760107 -0.49982 0.0743064 
6286 64330 664 63906 53 65376 65501 -0.408603 -0.76008 -0.499665 0.0752183 
6298 64348 686 63934 35 65378 65481 -0.408767 -0.759982 -0.499537 0.0761545 
6362 64348 686 63934 35 65378 65481 0.0770965 -0.0715326 -0.100525 -0.00976569 
6373 64238 591 63973 65513 65383 65427 -0.418957 -0.748887 -0.502874 0.103733 
6383 64253 581 63940 65519 65368 65424 -0.419304 -0.74847 -0.503016 0.104653 
6393 64272 574 63957 65518 65361 65412 -0.419678 -0.748014 -0.503177 0.105635 
6404 64280 574 63948 65506 65358 65419 -0.420072 -0.747552 -0.503329 0.10661 
6414 64278 587 63949 65510 65378 65424 -0.420462 -0.7471 -0.503486 0.107491 
6425 64273 587 63961 65527 65384 65438 -0.420763 -0.746725 -0.503608 0.108351 
6435 64292 607 63961 10 65358 65455 -0.421046 -0.74642 -0.503621 0.109286 
6445 64309 616 63958 37 65345 65476 -0.421302 -0.746209 -0.50349 0.110336 
6456 64303 616 63964 50 65384 65503 -0.421425 -0.746135 -0.503296 0.111255 
6466 64275 621 63965 50 65427 65511 -0.421422 -0.746124 -0.503155 0.11197 
6476 64259 622 63960 30 65450 65496 -0.421408 -0.74606 -0.503129 0.112565 
6487 64295 649 63971 0 65456 65494 -0.421467 -0.745934 -0.503159 0.113046 
6497 64243 616 64008 65514 65532 65475 -0.421566 -0.745718 -0.503337 0.113306 
6507 64207 611 63973 65488 1 65479 -0.421594 -0.745476 -0.503652 0.113394 
6518 64212 626 63981 65485 65480 65471 -0.421751 -0.745183 -0.503907 0.113608 
6528 64234 592 63995 65486 65493 65473 -0.422004 -0.744862 -0.504106 0.11389 
6538 64204 601 63973 65496 65490 65474 -0.422143 -0.744583 -0.504341 0.114159 
6549 64209 597 63983 65509 65452 65482 -0.422335 -0.744324 -0.504472 0.114554 
6559 64203 592 63973 65531 65428 65496 -0.422531 -0.744125 -0.504478 0.115101 
6569 64210 587 63988 65529 65453 65500 -0.422683 -0.743967 -0.504468 0.115604 
6580 64211 575 64002 65502 65496 65487 -0.422804 -0.743761 -0.504603 0.115893 
6590 64197 584 64026 65474 65520 65471 -0.422951 -0.743464 -0.504885 0.116034 
6600 64225 596 63959 65454 65493 65461 -0.423207 -0.743078 -0.505206 0.116182 
6611 64175 555 63966 65453 0 65463 -0.4235 -0.742683 -0.505526 0.116246 
6621 64178 557 64003 65480 65510 65481 -0.423636 -0.742374 -0.505838 0.116366 
6631 64182 571 63965 65515 65478 65508 -0.423775 -0.742186 -0.505937 0.11663 
6642 64180 564 63989 10 65468 65527 -0.42383 -0.742127 -0.505891 0.117002 
6652 64175 579 63964 20 65463 65532 -0.423849 -0.74212 -0.505789 0.117422 
6663 64174 585 63989 17 65459 65527 -0.423884 -0.742096 -0.505694 0.117854 
6673 64180 586 63977 10 65454 65519 -0.42395 -0.742042 -0.505611 0.118307 
6683 64194 583 64015 65535 65460 65505 -0.424041 -0.741927 -0.505598 0.118759 
6694 64177 561 63964 65520 65472 65499 -0.42415 -0.741766 -0.505656 0.119132 
6704 64168 558 63979 65516 65461 65502 -0.424297 -0.741591 -0.505703 0.119497 
6714 64191 560 63991 65515 65453 65497 -0.424479 -0.741392 -0.505741 0.119925 
6728 64182 516 63984 65522 65443 65500 -0.424662 -0.741207 -0.505751 0.120375 
7659 64549 727 63435 1716 376 2000 -0.377846 -0.771949 -0.510331 0.0298069 
2016-12-14 02:29:55.042 TestLib[51451:1187560] m4:
1789 1687 65105 63479 59613 61766 1921 0.292816 0.801374 -0.336249 0.398743 
1802 2386 64693 63704 62378 62169 275 0.30085 0.801615 -0.353414 0.376831 
1814 2600 64477 63949 503 64689 64315 0.301224 0.805615 -0.353148 0.36815 
1826 2314 65400 64440 3051 1232 62747 0.296216 0.812588 -0.336483 0.372472 
1838 1706 353 64579 3848 2234 62840 0.289229 0.819101 -0.313506 0.383581 
1850 1248 403 64676 3008 2284 63779 0.282658 0.822485 -0.294312 0.396237 
1862 998 65269 64008 1332 1548 64539 0.280171 0.82315 -0.283015 0.40476 
1874 1302 65140 64195 1043 453 65001 0.277948 0.824079 -0.2768 0.408681 
1886 1490 64981 63588 889 64794 65197 0.273572 0.827089 -0.274072 0.407391 
1898 1835 64815 63483 714 64523 65170 0.26967 0.830859 -0.272086 0.403635 
1910 1839 65044 64014 944 64868 65529 0.264677 0.833803 -0.270856 0.401691 
1923 1730 64766 63665 1212 81 65017 0.259761 0.836232 -0.267544 0.402071 
1935 1795 64646 63709 2142 715 64413 0.25406 0.839023 -0.258425 0.405846 
1946 1717 64772 63791 3481 1449 63678 0.245045 0.842759 -0.242336 0.413502 
1959 1481 65255 64044 4382 2169 63444 0.232845 0.846254 -0.221108 0.425145 
1971 1196 506 64418 3897 2188 63682 0.221307 0.848222 -0.200395 0.437474 
1983 1204 1055 64720 2526 1252 64355 0.2131 0.849426 -0.185522 0.445696 
1995 1100 793 64643 643 64921 27 0.208537 0.851252 -0.181602 0.445984 
2007 1249 357 64254 64776 63529 597 0.207775 0.854289 -0.186979 0.438245 
2019 1481 169 63894 64266 63367 317 0.210083 0.857656 -0.193942 0.427409 
2031 1741 65414 63884 64629 63996 173 0.212531 0.860242 -0.199157 0.418511 
2043 1879 65289 64020 65456 65008 65531 0.212774 0.861617 -0.201067 0.414627 
2055 1893 65230 64061 661 359 64937 0.21152 0.862317 -0.19791 0.415332 
2067 1722 134 64231 1127 951 64628 0.209284 0.862568 -0.190681 0.419306 
2079 1570 113 64154 663 1057 64925 0.208114 0.861828 -0.184456 0.424167 
2091 1341 65298 64073 94 928 65315 0.208676 0.860175 -0.181566 0.428471 
2104 1347 65198 63934 65496 563 65332 0.209681 0.858872 -0.180104 0.431203 
2116 1425 65168 63947 65528 350 65314 0.210486 0.858232 -0.178761 0.43264 
2128 1551 65067 64120 72 309 65268 0.210966 0.857835 -0.177255 0.433812 
2140 1655 65219 64278 275 229 65173 0.210788 0.85784 -0.174986 0.434809 
2152 1717 65320 64185 292 150 65199 0.210187 0.858143 -0.17259 0.435459 
2164 1683 65291 64093 176 254 65326 0.209889 0.858111 -0.170816 0.436365 
2229 1683 65291 64093 176 254 65326 0.20954 0.857547 -0.169705 0.146002 
2235 1683 65291 64093 176 254 65326 0.20954 0.857547 -0.169705 0.146002 
2245 1496 770 64764 624 260 65195 0.212402 0.872108 -0.116027 0.425266 
2256 1509 880 64755 623 181 65249 0.21037 0.872561 -0.112974 0.426167 
2266 1262 932 64647 550 351 65407 0.208356 0.8726 -0.110467 0.427731 
2276 936 864 64501 407 389 73 0.206558 0.872178 -0.109108 0.429807 
2287 873 862 64450 313 22 178 0.204797 0.872179 -0.108833 0.430717 
2297 1022 810 64259 158 65039 298 0.203141 0.873128 -0.109957 0.42929 
2308 1245 809 63928 65 64656 364 0.201513 0.874876 -0.112231 0.425898 
2319 1511 873 63554 65525 64459 332 0.200083 0.877083 -0.114896 0.421297 
2329 1824 930 63176 65487 64151 160 0.198976 0.879853 -0.117321 0.415336 
2340 2428 785 62804 65115 63334 65531 0.198989 0.88391 -0.12015 0.405795 
2350 3103 449 62788 64128 62788 64 0.202481 0.888485 -0.125619 0.392192 
2361 3151 89 63333 63798 64453 196 0.209131 0.889833 -0.131938 0.383475 
2372 2158 263 64150 64821 1407 65383 0.214387 0.886999 -0.133025 0.386749 
2382 1143 574 64731 323 3366 64761 0.217234 0.881461 -0.126479 0.399799 
2392 439 708 64950 629 4218 64916 0.218665 0.873613 -0.116983 0.41869 
2403 107 666 65093 13 2895 119 0.219925 0.866353 -0.11213 0.434158 
2413 707 222 64912 64463 59 651 0.222952 0.863193 -0.115531 0.437998 
2423 1628 105 64335 63958 63395 940 0.226477 0.864833 -0.12501 0.430284 
2434 2179 65419 63821 63347 62731 997 0.231617 0.867786 -0.137585 0.417577 
2445 2401 65221 63406 63212 63286 935 0.238295 0.86953 -0.150324 0.405629 
2455 2040 65289 63277 63887 64641 715 0.243878 0.869267 -0.159657 0.399258 
2466 1451 65333 63486 64628 549 357 0.247849 0.867101 -0.163869 0.399818 
2477 1031 65390 63966 65096 1035 27 0.250778 0.864223 -0.164275 0.404033 
2487 1282 49 64330 65379 223 65256 0.252448 0.863171 -0.163245 0.405656 
2498 1725 217 64461 65342 64932 65324 0.253287 0.864125 -0.163019 0.403185 
2508 1805 258 64468 65059 64801 138 0.254369 0.865101 -0.165105 0.399547 
2519 1662 80 64223 64828 65012 428 0.256016 0.86511 -0.16908 0.396803 
2530 1551 65517 64140 64806 65228 521 0.257871 0.864418 -0.173527 0.395188 
2540 1587 65477 64207 64853 65255 521 0.259574 0.863545 -0.177852 0.394056 
2551 1711 33 64128 64886 65126 514 0.260976 0.862967 -0.182202 0.392404 
2561 1637 159 64045 64845 65251 501 0.262558 0.862267 -0.186466 0.390883 
2572 1427 161 63942 64802 10 405 0.264815 0.860952 -0.190139 0.390489 
2583 1387 189 63902 64972 146 131 0.267243 0.859647 -0.192265 0.390669 
2593 1592 230 64063 65331 176 65344 0.268878 0.859037 -0.192195 0.390924 
2604 1758 324 64201 52 255 65107 0.269782 0.858989 -0.190136 0.391412 
2615 1748 406 64192 65520 392 65219 0.270703 0.858667 -0.187934 0.392546 
2625 1472 208 64194 65206 513 31 0.272412 0.857335 -0.187525 0.394465 
2635 1364 134 64089 65111 365 142 0.27436 0.855748 -0.188446 0.396118 
2646 1384 120 64003 65165 267 122 0.276025 0.85451 -0.189511 0.397125 
2657 1424 183 64093 65322 238 36 0.277172 0.853592 -0.190024 0.398054 
2667 1529 296 64183 65406 67 65497 0.277874 0.853205 -0.190082 0.398366 
2680 1563 336 64185 65352 65380 10 0.278444 0.853209 -0.190589 0.397717 
2691 1632 281 64204 65281 65203 73 0.279034 0.853427 -0.191864 0.396219 
2702 1702 241 64172 65326 65143 31 0.279477 0.853883 -0.193179 0.394282 
2712 1762 272 64193 65423 65255 65502 0.279718 0.85438 -0.1939 0.392677 
2723 1756 278 64296 65483 65395 65496 0.279825 0.854694 -0.194152 0.391792 
2734 1707 263 64295 65490 65449 8 0.279857 0.85484 -0.194405 0.391324 
2744 1725 288 64257 65482 65470 57 0.279841 0.854869 -0.194894 0.39103 
2754 1732 243 64217 65517 65528 71 0.279709 0.854819 -0.195364 0.390999 
2765 1684 267 64214 33 96 57 0.279474 0.854647 -0.195541 0.391455 
2776 1631 281 64224 66 131 53 0.279125 0.854435 -0.195515 0.392179 
2786 1533 313 64141 78 117 54 0.278709 0.854249 -0.195464 0.392904 
2797 1519 302 64125 86 52 41 0.278215 0.854207 -0.195432 0.393361 
2808 1500 309 64110 121 27 65525 0.277644 0.854338 -0.19523 0.393582 
2818 1531 358 64138 176 20 65452 0.276959 0.85465 -0.194606 0.393695 
2829 1543 421 64129 221 40 65390 0.276232 0.855049 -0.193551 0.393858 
2840 1562 476 64149 247 26 65345 0.275474 0.855557 -0.192204 0.393947 
2851 1576 500 64188 253 27 65320 0.274732 0.856121 -0.190689 0.393975 
2861 1548 492 64205 204 4 65358 0.274085 0.856646 -0.189375 0.39392 
2871 1562 481 64198 160 65484 65403 0.273524 0.857131 -0.18844 0.393701 
2882 1589 432 64168 146 65475 65421 0.272954 0.857632 -0.18772 0.39335 
2893 1609 424 64140 164 65465 65409 0.272359 0.858152 -0.186953 0.392994 
2903 1641 409 64169 174 65490 65421 0.271701 0.858659 -0.186148 0.392723 
2914 1593 374 64175 175 68 65425 0.271111 0.858971 -0.185278 0.392862 
2925 1515 333 64147 218 149 65370 0.270571 0.859126 -0.183974 0.393507 
2935 1533 328 64120 258 96 65326 0.26988 0.859478 -0.182421 0.393934 
2946 1580 277 64053 288 39 65289 0.269056 0.860039 -0.180721 0.394058 
2956 1600 240 64082 345 130 65236 0.268143 0.860599 -0.178631 0.39441 
2967 1504 260 64110 456 257 65137 0.267095 0.861112 -0.175754 0.395293 
2978 1446 298 64169 539 273 65085 0.265814 0.861698 -0.172259 0.396417 
2988 1428 313 64136 564 171 65069 0.264325 0.862509 -0.168691 0.397181 
2999 1473 358 64106 606 65534 65052 0.262563 0.863708 -0.165203 0.397211 
3012 1554 419 64098 651 65404 65030 0.26051 0.86529 -0.161709 0.396558 
3023 1613 438 64144 649 65355 65034 0.258341 0.867023 -0.158275 0.395576 
3034 1628 449 64109 613 65471 65053 0.256347 0.868504 -0.154876 0.394969 
3044 1559 394 64177 586 92 65068 0.254566 0.86961 -0.151399 0.395036 
3055 1446 421 64194 555 156 65079 0.252968 0.870453 -0.14792 0.395523 
3066 1445 433 64193 519 161 65093 0.251527 0.87121 -0.14453 0.396029 
3076 1383 485 64134 512 163 65094 0.250153 0.8719 -0.141239 0.396566 
3087 1416 558 64067 590 92 65012 0.248612 0.872817 -0.137555 0.396814 
3098 1548 705 64084 675 5 64951 0.246752 0.874075 -0.133481 0.396597 
3108 1611 847 64081 699 4 64995 0.244658 0.875437 -0.129452 0.396226 
3119 1594 986 64100 678 234 65066 0.242617 0.876321 -0.125486 0.396803 
3130 1564 1078 64128 579 476 65203 0.240874 0.876474 -0.12187 0.398649 
3140 1498 1072 64202 392 594 65395 0.239636 0.875955 -0.119282 0.40131 
3152 1456 1104 64241 258 637 65505 0.238884 0.875009 -0.117601 0.404306 
3162 1423 1123 64309 206 646 65535 0.238352 0.87391 -0.116223 0.407385 
3173 1469 1092 64398 109 611 62 0.238087 0.872716 -0.115278 0.410356 
3184 1546 966 64502 65467 526 201 0.238242 0.871385 -0.115334 0.413071 
3194 1629 744 64562 65263 418 358 0.238903 0.869915 -0.116727 0.41539 
3204 1646 515 64566 65124 276 435 0.239953 0.868446 -0.119118 0.417174 
3215 1681 322 64497 65067 77 429 0.241162 0.867289 -0.122016 0.418046 
3226 1736 225 64523 65076 65407 383 0.242313 0.8666 -0.124994 0.41793 
3236 1816 123 64418 65033 65245 302 0.243615 0.866284 -0.127976 0.416925 
3247 1897 131 64333 65113 65181 124 0.244979 0.866351 -0.130276 0.415269 
3258 1927 150 64308 65294 65254 65462 0.246067 0.866639 -0.131284 0.413704 
3268 1927 278 64350 65508 65268 65291 0.246597 0.86727 -0.130901 0.412186 
3279 1859 325 64414 85 65393 65262 0.246704 0.867931 -0.129799 0.411078 
3290 1772 402 64475 137 65440 65301 0.246532 0.868471 -0.12856 0.410429 
3301 1729 439 64449 169 65426 65351 0.246094 0.869043 -0.127459 0.409824 
3311 1738 486 64370 219 65424 65347 0.245449 0.869649 -0.126339 0.409273 
3322 1783 479 64365 310 65427 65257 0.244544 0.870444 -0.124729 0.408617 
3333 1932 552 64390 404 65454 65108 0.243517 0.871395 -0.12221 0.407964 
3343 1975 453 64372 376 67 65076 0.242696 0.872109 -0.11924 0.407807 
3353 1914 387 64356 330 180 65077 0.242117 0.872502 -0.116198 0.408189 
3364 1845 323 64224 283 216 65100 0.241782 0.872681 -0.113263 0.408828 
3375 1710 286 64194 277 265 65119 0.241484 0.872745 -0.110444 0.409638 
3385 1648 292 64182 308 228 65132 0.241025 0.872856 -0.107631 0.410421 
3396 1604 344 64128 369 205 65119 0.240316 0.873116 -0.104715 0.411038 
3407 1575 398 64160 421 269 65131 0.239361 0.87335 -0.101617 0.411874 
3417 1535 470 64213 441 299 65187 0.238215 0.873472 -0.0986179 0.413007 
3428 1483 504 64248 427 203 65250 0.236924 0.873686 -0.0959964 0.413913 
3439 1486 480 64216 381 44 65291 0.23564 0.874157 -0.0938632 0.414142 
3450 1529 480 64258 354 65440 65299 0.2344 0.874894 -0.092072 0.413691 
3460 1563 487 64239 349 65378 65276 0.2332 0.875805 -0.0903395 0.412822 
3471 1589 527 64166 350 65336 65262 0.232033 0.876805 -0.0885502 0.411744 
3482 1583 612 64138 369 65396 65248 0.230846 0.877761 -0.086647 0.410777 
3492 1567 672 64135 378 65488 65270 0.229614 0.878522 -0.0846263 0.410262 
3503 1566 692 64149 339 26 65342 0.228428 0.879036 -0.0828368 0.410188 
3514 1578 710 64186 288 50 65407 0.227341 0.87938 -0.0814611 0.410329 
3524 1583 696 64193 237 41 65445 0.226384 0.879649 -0.0803894 0.410495 
3534 1617 665 64175 152 65526 65502 0.225662 0.879888 -0.0797752 0.4105 
3546 1645 581 64155 102 0 65528 0.225137 0.880057 -0.0795016 0.410478 
3556 1584 593 64147 96 72 65519 0.224695 0.880084 -0.0791747 0.410725 
3566 1519 622 64189 95 106 65514 0.224301 0.880005 -0.0787467 0.411193 
3577 1523 590 64204 72 53 65529 0.223962 0.879973 -0.0784432 0.411504 
3588 1535 588 64188 44 65510 20 0.22366 0.880065 -0.0784111 0.411478 
3598 1574 571 64166 20 65486 34 0.223419 0.880208 -0.0785771 0.41127 
3609 1576 567 64154 22 65507 28 0.223206 0.880318 -0.0787282 0.411122 
3620 1565 559 64175 36 27 3 0.223003 0.88034 -0.0786952 0.411191 
3631 1584 544 64197 35 34 0 0.222816 0.880323 -0.0785833 0.41135 
3641 1584 548 64203 14 6 13 0.222658 0.880344 -0.0785814 0.411391 
3652 1610 513 64173 6 7 15 0.222555 0.880357 -0.0786484 0.411408 
3663 1593 534 64178 24 46 65526 0.22245 0.880317 -0.0785708 0.411563 
3673 1606 586 64220 42 83 65509 0.222313 0.88022 -0.0782947 0.411897 
3684 1597 603 64263 34 58 65528 0.222169 0.880134 -0.0780709 0.412202 
3695 1613 611 64286 4 65533 39 0.222034 0.880117 -0.0781569 0.412294 
3705 1635 563 64278 65491 65450 112 0.221928 0.880188 -0.0787545 0.412086 
3716 1659 493 64247 65430 65396 178 0.221918 0.880296 -0.0798903 0.411641 
3727 1638 449 64203 65413 65397 197 0.221949 0.88039 -0.0812666 0.411153 
3737 1639 398 64202 65439 65441 167 0.221946 0.880437 -0.0824868 0.410811 
3748 1626 423 64194 65484 65484 111 0.221883 0.880461 -0.08332 0.410627 
3759 1599 457 64197 65517 65513 72 0.221757 0.880477 -0.0838044 0.410561 
3769 1581 476 64225 1 4 55 0.221592 0.88047 -0.0841059 0.410604 
3780 1571 500 64228 19 30 44 0.221384 0.880429 -0.084284 0.410768 
3791 1575 525 64194 21 33 44 0.221154 0.880381 -0.0844092 0.410969 
3801 1572 500 64222 18 32 49 0.220942 0.880323 -0.0845863 0.411171 
3812 1551 510 64221 34 27 42 0.220675 0.880295 -0.0847013 0.411351 
3823 1577 507 64216 22 6 56 0.220403 0.880291 -0.0848903 0.411465 
3833 1583 483 64240 10 65514 68 0.220154 0.880326 -0.0852082 0.411459 
3844 1599 479 64201 65531 65490 81 0.219926 0.880393 -0.0856403 0.411348 
3854 1601 478 64200 65526 65493 88 0.219705 0.880458 -0.08614 0.411221 
3865 1583 474 64245 65530 65523 86 0.219499 0.880471 -0.0866126 0.411205 
3876 1583 489 64241 8 21 67 0.219281 0.880421 -0.0869395 0.411359 
3886 1583 477 64230 7 7 62 0.219069 0.88039 -0.0872184 0.411479 
3897 1596 471 64201 3 65533 58 0.218874 0.880385 -0.0875165 0.411531 
3908 1598 464 64242 6 25 52 0.218695 0.88035 -0.0877562 0.411649 
3918 1606 474 64223 16 67 47 0.218507 0.880234 -0.0879191 0.411963 
3929 1580 477 64216 31 78 40 0.218276 0.880089 -0.0879806 0.41238 
3940 1600 510 64221 31 47 39 0.218022 0.880001 -0.088043 0.412691 
3950 1615 489 64214 22 29 59 0.217767 0.879951 -0.0882175 0.412895 
3961 1620 505 64198 22 17 60 0.217511 0.879914 -0.0884483 0.413059 
3972 1636 478 64234 13 65535 54 0.217281 0.879912 -0.0886819 0.413133 
3982 1646 474 64204 65533 65530 63 0.217096 0.87991 -0.0889863 0.41317 
3993 1639 470 64160 65528 18 71 0.216945 0.879854 -0.0893391 0.413292 
4004 1626 461 64212 0 48 69 0.216782 0.879743 -0.0896429 0.413547 
4014 1597 470 64204 12 57 60 0.216584 0.879616 -0.0898787 0.413872 
4025 1591 474 64203 9 35 57 0.216377 0.879515 -0.0900856 0.414148 
4035 1560 500 64248 22 56 56 0.216139 0.879412 -0.0902682 0.414451 
4046 1576 515 64231 27 19 53 0.215871 0.879364 -0.0904383 0.414655 
4057 1627 523 64267 8 65510 63 0.215638 0.879402 -0.0907249 0.414634 
4067 1625 503 64231 65512 65487 85 0.215482 0.87945 -0.0911924 0.414511 
4078 1658 501 64206 65480 65461 101 0.215431 0.879519 -0.0918461 0.414247 
4089 1624 498 64213 65458 65475 108 0.215472 0.879535 -0.0926 0.414023 
4099 1641 467 64183 65456 65500 104 0.215566 0.879498 -0.0933416 0.413886 
4110 1593 487 64219 65465 65519 109 0.215616 0.879412 -0.0940404 0.413885 
4121 1590 484 64226 65472 65510 112 0.215625 0.879342 -0.0947397 0.413868 
4131 1590 485 64212 65462 65470 116 0.215639 0.879339 -0.0955052 0.413694 
4142 1603 486 64206 65445 65456 130 0.215689 0.879364 -0.0963859 0.413408 
4152 1599 466 64253 65438 65482 141 0.215763 0.879326 -0.0973324 0.413229 
4163 1584 471 64233 65430 65467 146 0.21586 0.879288 -0.0983259 0.413024 
4174 1579 458 64230 65412 65437 149 0.216018 0.87929 -0.0994119 0.412677 
4184 1590 455 64224 65405 65421 149 0.216191 0.879312 -0.10054 0.412266 
4195 1580 438 64206 65405 65407 148 0.216372 0.879376 -0.101691 0.411752 
4206 1597 434 64153 65400 65405 155 0.216543 0.879442 -0.102873 0.411227 
4216 1550 439 64214 65413 65425 151 0.216698 0.879483 -0.104028 0.410767 
4227 1578 458 64205 65443 65431 137 0.216761 0.879538 -0.105038 0.41036 
4238 1572 470 64239 65451 65413 133 0.21677 0.879631 -0.105998 0.409908 
4248 1566 471 64224 65447 65383 141 0.216765 0.879785 -0.107022 0.409314 
4259 1575 484 64231 65447 65361 152 0.216732 0.87998 -0.108114 0.408624 
4270 1577 451 64211 65432 65331 161 0.216714 0.880214 -0.109327 0.407805 
4280 1585 449 64208 65421 65325 162 0.216721 0.880461 -0.110597 0.406925 
4291 1597 446 64193 65433 65334 152 0.216724 0.880698 -0.111817 0.406077 
4302 1600 441 64208 65455 65340 123 0.216676 0.880971 -0.112865 0.405219 
4312 1604 435 64158 65458 65376 114 0.216648 0.881191 -0.11379 0.404497 
4323 1616 425 64155 65471 65433 100 0.216636 0.881317 -0.114594 0.404001 
4333 1568 450 64174 65496 65497 89 0.216573 0.881339 -0.115209 0.403812 
4344 1537 464 64183 65507 65507 83 0.216477 0.881325 -0.115714 0.40375 
4355 1560 461 64207 65500 65472 83 0.216392 0.881366 -0.116257 0.403551 
4365 1571 462 64206 65494 65445 86 0.216309 0.881463 -0.116856 0.40321 
4376 1591 457 64187 65497 65438 80 0.216231 0.881591 -0.117461 0.402795 
4387 1605 458 64202 65516 65470 70 0.216102 0.881694 -0.117962 0.402494 
4397 1577 449 64225 65528 65489 63 0.21595 0.881757 -0.118367 0.402318 
4408 1592 469 64207 65522 65475 67 0.215788 0.881835 -0.11877 0.402115 
4419 1580 444 64183 65503 65468 83 0.215679 0.881905 -0.119295 0.401864 
4429 1556 422 64159 65503 65457 81 0.215584 0.881995 -0.11986 0.401548 
4440 1578 439 64164 65531 65458 48 0.215431 0.882126 -0.120263 0.401223 
4451 1615 433 64167 23 65487 26 0.215198 0.882266 -0.12045 0.400985 
4461 1598 439 64193 30 65522 20 0.214972 0.882344 -0.120536 0.400908 
4472 1604 466 64181 33 65532 15 0.214743 0.882391 -0.12056 0.400921 
4483 1605 453 64145 29 65532 10 0.214535 0.88244 -0.120567 0.400921 
4493 1607 472 64175 20 18 15 0.214373 0.882446 -0.120587 0.40099 
4504 1572 442 64196 26 60 16 0.214222 0.88237 -0.120567 0.401242 
4514 1556 452 64157 43 59 2 0.214031 0.882294 -0.120452 0.401546 
4525 1555 470 64157 39 44 2 0.213833 0.882251 -0.120334 0.401782 
4536 1569 479 64166 26 25 13 0.213659 0.882231 -0.120296 0.401929 
4546 1554 440 64208 15 19 16 0.213532 0.882211 -0.120321 0.402032 
4557 1576 461 64207 20 26 2 0.213415 0.882192 -0.120287 0.402148 
4568 1578 452 64222 15 32 0 0.213325 0.882153 -0.120232 0.402296 
4578 1596 450 64198 9 10 65533 0.213255 0.882146 -0.120188 0.402362 
4589 1578 432 64166 65531 13 1 0.213231 0.882133 -0.120203 0.402399 
6000 0 2 12 0 30 1 0.21323 0.882082 -0.120209 0.40251 
6610 1565 398 64182 11 27 65526 0.213182 0.882047 -0.120152 0.402628 
6621 1590 391 64150 27 24 65512 0.21308 0.882051 -0.119997 0.402721 
6632 1590 421 64164 42 26 65495 0.212944 0.88208 -0.119737 0.402807 
6642 1595 419 64201 53 41 65486 0.212791 0.882102 -0.119376 0.402946 
6653 1574 412 64167 61 53 65484 0.212615 0.882105 -0.118968 0.403152 
6664 1581 437 64194 64 50 65481 0.212427 0.882114 -0.118524 0.403362 
6674 1574 424 64185 58 29 65487 0.212235 0.882153 -0.11814 0.403491 
6685 1564 411 64195 55 18 65486 0.212056 0.882221 -0.117791 0.40354 
6695 1591 470 64181 59 14 65484 0.211863 0.882303 -0.117419 0.40357 
6706 1566 430 64185 56 8 65486 0.211678 0.882386 -0.117064 0.403587 
6717 1589 452 64158 49 65523 65489 0.2115 0.882501 -0.116752 0.403521 
6727 1597 447 64154 40 65505 65498 0.211339 0.882645 -0.116512 0.403359 
6738 1581 449 64146 37 65508 65506 0.211176 0.882785 -0.116336 0.403188 
6749 1582 434 64148 38 65514 65515 0.210995 0.882908 -0.116184 0.403058 
6759 1581 440 64135 41 65512 65517 0.210789 0.883026 -0.116052 0.402945 
6770 1591 427 64189 41 65497 65522 0.21056 0.883174 -0.11595 0.40277 
6781 1609 431 64179 35 65494 65534 0.21033 0.883319 -0.115917 0.402582 
6791 1582 431 64173 38 65506 65532 0.210107 0.883446 -0.115873 0.402432 
6802 1590 438 64185 44 65534 0 0.209863 0.883528 -0.115806 0.402399 
6813 1585 436 64173 44 13 7 0.209619 0.883566 -0.115736 0.402462 
6823 1591 438 64151 36 10 12 0.209385 0.883588 -0.115707 0.402545 
6837 1575 443 64192 31 15 22 0.209169 0.883598 -0.115734 0.402627 
7765 0 0 0 0 0 0 0 0.8125 -0.286486 0.431966 
7777 1149 44 63431 59918 63691 2325 0.277331 0.806908 -0.308856 0.420231 
(lldb) 