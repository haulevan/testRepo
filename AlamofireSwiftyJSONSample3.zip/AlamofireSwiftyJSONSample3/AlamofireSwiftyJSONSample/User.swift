//
//  User.swift
//  AlamofireSwiftyJSONSample
//
//  Created by rec12 on 4/12/16.
//  Copyright © 2016 Wayfarer. All rights reserved.
//

import Foundation

class User {
    var id: String!
    var name: String?
    var email: String?
    var address: String?
    var gender: String!
    var phone: Phone?
}