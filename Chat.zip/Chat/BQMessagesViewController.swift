
import UIKit
import Foundation
import JSQMessagesViewController
import MobileCoreServices
import imglyKit


class BQMessagesViewController: JSQMessagesViewController{
    
    var imageView: UIImageView?

    var messages = [JSQMessage]()
    var avatars = Dictionary<String, JSQMessagesAvatarImage>()

    let senderImageUrl = BQDataManager.sharedInstance.user?.profile?.avatar

    var outgoingBubbleImageView: JSQMessagesBubbleImage!
    var incomingBubbleImageView: JSQMessagesBubbleImage!
    var newMedia: Bool?
    var receiverId: String?
    var receiverAvatarUrl: String?
    var inputExistMessage: String?
    var currentPage = 0
    var reloadWaittingTime: Bool?
    var timeSet: Set? = Set<NSDate>()
    
    func setupIOSocket() {
        
        let nickName = (BQDataManager.sharedInstance.user?.username)!
        
        SocketIOManager.sharedInstance.connectToServerWithNickname(nickName, completionHandler: { (userList) -> Void in
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                print(userList)
            })
        })
    }
    
    func sendMessage(text: String!, sender: String!, receiver: String!) {
        // *** STEP 3: ADD A MESSAGE TO FIREBASE

        SocketIOManager.sharedInstance.sendMessage(text!, withNickname: self.senderId, toUser: receiver)

    }
    
    func tempSendMessage(text: String!, sender: String!) {
        let message = JSQMessage(senderId: sender, displayName: sender, text: text)
        messages.append(message)
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        BQDataManager.sharedInstance.messagePage = 0
        self.currentPage = 0

        
        SocketIOManager.sharedInstance.checkSocketStatus()
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(image:UIImage.init(named: "icon_back"), style:.Plain, target:self, action:#selector(BQMessagesViewController.backButtonPressed(_:)));

        setupBubbles()
        
        setupIOSocket()
        
        // Load the background for the chatting view
        UIGraphicsBeginImageContext(UIScreen.mainScreen().bounds.size)
        UIImage(named: "bg_landing")?.drawInRect(UIScreen.mainScreen().bounds)
        let image: UIImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        self.collectionView!.backgroundColor = UIColor(patternImage: image)
        self.imageView = UIImageView.init(frame: CGRectMake(0, 0, 500, 500))
        self.view .addSubview(self.imageView!)
        
        let avatar = UIImage(named: "icon_avatar")
        let diameter = UInt(collectionView!.collectionViewLayout.incomingAvatarViewSize.width)
        let avatarImage = JSQMessagesAvatarImageFactory.avatarImageWithImage(avatar, diameter: diameter)
        
        avatars[self.receiverId!] = avatarImage
        avatars[self.senderId!] = avatarImage

        if let currentUserURL = BQDataManager.sharedInstance.user?.profile?.avatar {
            self.imageView!.hnk_setImageFromURL(
                NSURL.init(string: currentUserURL)!,
                placeholder: nil,
                success: { image in
                    
                    let diameter = UInt(self.collectionView!.collectionViewLayout.incomingAvatarViewSize.width)
                    let myavatarImage = JSQMessagesAvatarImageFactory.avatarImageWithImage(image, diameter: diameter)
                    
                    self.avatars[self.senderId] = myavatarImage
                },
                failure: { error in
            })
        }

        if let _ = self.receiverAvatarUrl {
            self.imageView!.hnk_setImageFromURL(
                NSURL.init(string: self.receiverAvatarUrl!)!,
                placeholder: nil,
                success: { image in
                    
                    let diameter = UInt(self.collectionView!.collectionViewLayout.incomingAvatarViewSize.width)
                    let myavatarImage = JSQMessagesAvatarImageFactory.avatarImageWithImage(image, diameter: diameter)
                    
                    self.avatars[self.receiverId!] = myavatarImage
                },
                failure: { error in
            })
        }
        
        self.title = self.receiverId
        
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        collectionView!.collectionViewLayout.springinessEnabled = false
        
        NSNotificationCenter.defaultCenter().addObserver( self,
                                                          selector: #selector(receiveMessage),
                                                          name: kBQNotificationNewMessage,
                                                          object: nil)
        
        BQDataManager.sharedInstance.chatChannel = self.receiverId!
        
        SocketIOManager.sharedInstance.goToChatChannel(self.receiverId!)
        
        SocketIOManager.sharedInstance.notifyGetHistoryChatMessage(self.receiverId!)
        
        SocketIOManager.sharedInstance.getHistoryChatMessage{ (messages) -> Void in
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                print("Load page: \(self.currentPage)")
                self.reloadWaittingTime = true
                let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(2 * Double(NSEC_PER_SEC)))
                dispatch_after(delayTime, dispatch_get_main_queue()) {
                    self.reloadWaittingTime = false
                }
                
                let role = BQDataManager.sharedInstance.userRole()
                switch role {
                case BQUserRole.Agency:
                    NSNotificationCenter.defaultCenter() .postNotificationName(kBQNumberUnreadMessages, object: 0)
                    break;
                    
                case BQUserRole.Sale:
                    
                    let unreadMessage = BQDataManager.sharedInstance.unreadMessage
                    if (unreadMessage > 1) {
                        BQDataManager.sharedInstance.unreadMessage = BQDataManager.sharedInstance.unreadMessage - 1
                        NSNotificationCenter.defaultCenter() .postNotificationName(kBQNumberUnreadMessages, object: unreadMessage - 1)
                    }
                    else {
                        NSNotificationCenter.defaultCenter() .postNotificationName(kBQNumberUnreadMessages, object: 0)
                    }
                    break;
                    
                default:
                    NSNotificationCenter.defaultCenter() .postNotificationName(kBQNumberUnreadMessages, object: 0)
                    break;
                }
                
                for messageBQ in messages {
                    
                    if (messageBQ.text() .hasPrefix("http") &&
                        (messageBQ.text().hasSuffix(".png") || (messageBQ.text().hasSuffix(".jpg")))) {
                        self.imageView!.hnk_setImageFromURL(
                            NSURL.init(string: messageBQ.text())!,
                            placeholder: nil,
                            success: { image in
                                let message = JSQMessage(senderId: messageBQ.sender(), senderDisplayName: messageBQ.sender(), date: messageBQ.date(), media: JSQPhotoMediaItem(image: image))
                                
                                if (self.timeSet?.contains(message.date) == false) {
                                    if (self.currentPage == 0) {
                                        self.messages .append(message)
                                    }
                                    else {
                                        self.messages .insert(message, atIndex: 0)
                                    }
                                    self.timeSet?.insert(message.date)
                                    
                                }
                            },
                            failure: { error in
                                print(error?.localizedDescription)
                        })
                    }
                    else {
                        let message = JSQMessage(senderId: messageBQ.sender(), senderDisplayName: messageBQ.sender(), date: messageBQ.date(),text: messageBQ.text())
                        if (self.timeSet?.contains(message.date) == false) {

                            if (self.currentPage == 0) {
                                self.messages .append(message)
                            }
                            else {
                                self.messages .insert(message, atIndex: 0)
                            }
                            self.timeSet?.insert(message.date)

                        }
                    }
                }
                
                self.messages.sortInPlace({ (obj1: JSQMessage, obj2: JSQMessage) -> Bool in
                    return obj1.date .compare(obj2.date) == NSComparisonResult.OrderedAscending
                })
                
                if (self.currentPage == 0) {
                    self.finishReceivingMessage()
                }
                else {
                    self.collectionView .reloadData()
                }
            })
        }
        
        if let _ = self.inputExistMessage {
            // Try to input the message here.
            self.inputToolbar.contentView.textView.text = self.inputExistMessage
            self.inputToolbar.contentView.textView .becomeFirstResponder()
            
            self.didPressSendButton( self.inputToolbar.contentView.leftBarButtonItem, withMessageText: self.inputExistMessage, senderId: "", senderDisplayName: "", date: NSDate())
        }
    }
    
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        BQDataManager.sharedInstance.chatChannel = nil
        SocketIOManager.sharedInstance.disconnectHistoryChatMessage()
        
    }
   
    func addMessage(message: JSQMessage) {
    }

    func testFun() {
        
    }
    
    // ACTIONS
    func receiveMessage(notification: NSNotification) {
        let messages = notification.object as! [BQMessage]
        for messageBQ in messages {
            
            if (messageBQ.text() .hasPrefix("http") &&
                (messageBQ.text().hasSuffix(".png") || (messageBQ.text().hasSuffix(".jpg")))) {
                self.imageView!.hnk_setImageFromURL(
                    NSURL.init(string: messageBQ.text())!,
                    placeholder: nil,
                    success: { image in
                        let message = JSQMessage(senderId: messageBQ.sender(), displayName: messageBQ.sender(), media: JSQPhotoMediaItem(image: image))
                        
                        self.messages .append(message)
                        self.finishReceivingMessage()
                    },
                    failure: { error in
                        print(error?.localizedDescription)
                })
            }
            else {
                let message = JSQMessage(senderId: messageBQ.sender(), displayName: messageBQ.sender(), text: messageBQ.text())
                self.messages .append(message)
                self.finishReceivingMessage()
                
            }
        }
    }

    
    func loadMoreItemDataAtPage(page: Int)
    {
        print("Load more item")
        SocketIOManager.sharedInstance.notifyGetHistoryChatMessage(self.receiverId!)
    }
    
    func receivedMessagePressed(sender: UIBarButtonItem) {
        // Simulate reciving message
        showTypingIndicator = !showTypingIndicator
        scrollToBottomAnimated(true)
    }
    
    override func didPressSendButton(button: UIButton!, withMessageText text: String!, senderId: String!, senderDisplayName: String!, date: NSDate!) {
        
        sendMessage(text, sender: self.senderId, receiver: self.receiverId)
        let message = JSQMessage(senderId: self.senderId, displayName: self.senderDisplayName, text: text)
        
        self.messages .append(message)
        finishSendingMessage()

    }
    
    override func didPressAccessoryButton(sender: UIButton!) {
        self .showCamera()
    }
    
    override func collectionView(collectionView: JSQMessagesCollectionView!, messageDataForItemAtIndexPath indexPath: NSIndexPath!) -> JSQMessageData! {
        
        return messages[indexPath.item]
    }
    
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }
    
    override func collectionView(collectionView: JSQMessagesCollectionView!, messageBubbleImageDataForItemAtIndexPath indexPath: NSIndexPath!) -> JSQMessageBubbleImageDataSource! {
        let message = messages[indexPath.item] // 1
        if message.senderId == senderId { // 2
            return outgoingBubbleImageView
        } else { // 3
            return incomingBubbleImageView
        }
    }
    
    
    override func collectionView(collectionView: JSQMessagesCollectionView!, layout collectionViewLayout: JSQMessagesCollectionViewFlowLayout!, heightForCellTopLabelAtIndexPath indexPath: NSIndexPath!) -> CGFloat
    {
        if indexPath.item == 0 {
            return kJSQMessagesCollectionViewCellLabelHeightDefault
        }
        
        if (indexPath.item - 1 > 0) {
            let previousMessage = messages[indexPath.item - 1]
            let message = messages[indexPath.item]
            
            if (message.date .timeIntervalSinceDate(previousMessage.date) / 60 > 1) {
                return kJSQMessagesCollectionViewCellLabelHeightDefault
                
            }
        }
        
        return 0.0
    }

    
    override func collectionView(collectionView: JSQMessagesCollectionView!, attributedTextForCellTopLabelAtIndexPath indexPath: NSIndexPath!) -> NSAttributedString! {
        
        let message = messages[indexPath.item]

        if indexPath.item == 0 {
        
            return JSQMessagesTimestampFormatter .sharedFormatter().attributedTimestampForDate(message.date)
        }
    
        if indexPath.item - 1 > 0 {
            let previousMessage = messages[indexPath.item - 1]
            
            if (message.date .timeIntervalSinceDate(previousMessage.date) / 60 > 1) {
                return JSQMessagesTimestampFormatter .sharedFormatter().attributedTimestampForDate(message.date)

            }
        }
        
        return nil;
    }
    
    
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = super.collectionView(collectionView, cellForItemAtIndexPath: indexPath) as! JSQMessagesCollectionViewCell
        
        let message = messages[indexPath.item]
        
        if DeviceType.IS_IPAD {
            cell.textView?.font = UIFont(name: "VNF-Gotham", size: 17)
        }
        else {
            cell.textView?.font = UIFont(name: "VNF-Gotham", size: 15)
        }

        if message.senderId == senderId { // 1
            cell.textView?.textColor = UIColor.whiteColor() // 2
        } else {
            cell.textView?.textColor = UIColor.blackColor() // 3
        }
        
        if (indexPath.row == 0 && self.reloadWaittingTime == false) {
            self.currentPage += 1

            BQDataManager.sharedInstance.messagePage = self.currentPage
            self .loadMoreItemDataAtPage(self.currentPage)
        }

        return cell
    }
    
    override func collectionView(collectionView: JSQMessagesCollectionView!, avatarImageDataForItemAtIndexPath indexPath: NSIndexPath!) -> JSQMessageAvatarImageDataSource! {
        
        let message = messages[indexPath.item]
        
        if let avatar = avatars[message.senderId] {
            return avatar
        } else {
            setupAvatarImage(message.senderId, imageUrl: BQDataManager.sharedInstance.user?.profile?.avatar, incoming: true)
            return avatars[message.senderId]
        }
    }

    func setupAvatarImage(name: String, imageUrl: String?, incoming: Bool) {
        
        if let stringUrl = imageUrl {
            if let url = NSURL(string: stringUrl) {
                if let data = NSData(contentsOfURL: url) {
                    let image = UIImage(data: data)
                    let diameter = incoming ? UInt(collectionView!.collectionViewLayout.incomingAvatarViewSize.width) : UInt(collectionView!.collectionViewLayout.outgoingAvatarViewSize.width)
                    let avatarImage = JSQMessagesAvatarImageFactory.avatarImageWithImage(image, diameter: diameter)
                    avatars[name] = avatarImage
                }
            }
        }
    }
    
    private func setupBubbles() {
        let bubbleImageFactory = JSQMessagesBubbleImageFactory.init(bubbleImage: UIImage(named: "bubble_red"), capInsets: UIEdgeInsets(top: 20, left: 20,bottom: 40, right: 40))
        
        outgoingBubbleImageView = bubbleImageFactory.outgoingMessagesBubbleImageWithColor(UIColor(red: 240 / 255, green: 78/255, blue: 35 / 255, alpha: 1))
            
        incomingBubbleImageView = bubbleImageFactory.incomingMessagesBubbleImageWithColor(UIColor.whiteColor())
    }

    // MARK: IBAction
    func backButtonPressed(sender:UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    func showCamera() {
        
        let configuration = Configuration() { builder in
        }
        
        let cameraViewController = CameraViewController(configuration: configuration)
        
        cameraViewController .completionBlock = {(image: UIImage?, url: NSURL?) -> Void in
            
            if let _ = image {
                
                // Scale image to small
                let scale = max(image!.size.width / 310, image!.size.height / 310)
                let image1 = image!.RBResizeImage(CGSize.init(width: image!.size.width/scale, height: image!.size.height/scale))
                
//                self.dismissViewControllerAnimated(false, completion: nil)
                self.navigationController?.popViewControllerAnimated(true)
                // Close the capture image
                self .sendImageMessage(image1)
            }
        }
        
        self.navigationController?.pushViewController(cameraViewController, animated: true)
//        presentViewController(cameraViewController, animated: true, completion: { () -> Void in
//        })
    }
    
    func sendImageMessage(image: UIImage) {
        
        let message = JSQMessage(senderId: self.senderId, displayName: self.senderDisplayName, media: JSQPhotoMediaItem(image: image))
        
        // TODO: try to upload image to server.
        let imageString = UIImageJPEGRepresentation(image, 1.0)!.base64EncodedStringWithOptions(.Encoding64CharacterLineLength)
        
        BQDataManager .sharedInstance .postChatImage(imageString) { (result, error) in
            
            let uploadedImage = result as! BQImage
            self.sendMessage(uploadedImage.url, sender: self.senderId, receiver: self.receiverId)
        }
        
        self.messages .append(message)
        finishSendingMessage()
    }
    
    func image(image: UIImage, didFinishSavingWithError error: NSErrorPointer, contextInfo:UnsafePointer<Void>) {
        
        if error != nil {
            let alert = UIAlertController(title: "Save Failed",
                                          message: "Failed to save image",
                                          preferredStyle: UIAlertControllerStyle.Alert)
            
            let cancelAction = UIAlertAction(title: "OK",
                                             style: .Cancel, handler: nil)
            
            alert.addAction(cancelAction)
            self.presentViewController(alert, animated: true,
                                       completion: nil)
        }
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        picker.dismissViewControllerAnimated(true) { () -> Void in
            self.dismissViewControllerAnimated(false, completion: nil)
        }
    }
    
}
