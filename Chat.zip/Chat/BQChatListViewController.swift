//
//  BQChatListViewController.swift
//  BQOrder
//
//  Created by Prescott on 4/1/16.
//  Copyright © 2016 BQ. All rights reserved.
//

import UIKit


class BQChatListViewController: BQBaseViewController, UITableViewDelegate, UITableViewDataSource {
    // outlets
    @IBOutlet weak var tableView: UITableView!
    var refreshControl: UIRefreshControl!
    var isLoadingShowMore = false
    var isShowMore = false
    var currentPage = 1

    var agencies = [BQUser]()
    var chatAgencies = [BQChatUser]()

    var selectedIndexPath = NSIndexPath()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.addTarget(self, action: Selector("loadOrdersData"), forControlEvents: UIControlEvents.ValueChanged)
        self.tableView.addSubview(self.refreshControl)

        self .createBackBarButton()

        // Do any additional setup after loading the view.
        self.loadOrdersData()
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        SocketIOManager.sharedInstance.getUnreadThreadMessage { (result) in
            
            self.chatAgencies = result
            self.tableView .reloadData()
        }
        
        NSNotificationCenter.defaultCenter().addObserver( self,
                                                          selector: #selector(receiveMessage),
                                                          name: kBQNotificationNewMessage,
                                                          object: nil)

    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        SocketIOManager.sharedInstance.disconectGetUnreadThreadMessage()

        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func receiveMessage(messages: [BQMessage]) {
        SocketIOManager.sharedInstance.getUnreadThreadMessage { (result) in
            
            self.chatAgencies = result
            self.tableView .reloadData()
        }
    }
    
    func loadOrdersData() {
        
        if !self.refreshControl.refreshing {
            MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        }
        
        
        BQDataManager.sharedInstance.getAgencyByUser(1) { (result, error) -> Void in
            
            // Hide indicator
            if !self.refreshControl.refreshing {
                MBProgressHUD.hideAllHUDsForView(self.view, animated: true);
            }
            if self.refreshControl.refreshing {
                self.refreshControl.endRefreshing()
            }
            self.isLoadingShowMore = false
            
            // Check error
            if error != nil {
                let err = error! as NSError
                self.showAlertMessage(err.localizedDescription, title: "")
            }
            else if result != nil {
                self.agencies = result! as! [BQUser]
                self.tableView.reloadData()
            }
        }
    }
    
    // MARK: UITableViewDelegate&DataSource methods
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
        if (DeviceType.IS_IPAD) {
            return 75
        }
        else {
            return 60
        }
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.agencies.count
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("ChatListCellIdentifier", forIndexPath: indexPath) as! BQChatListTableViewCell
        let agency = self.agencies[indexPath.row]
        
        cell.userNameLabel?.text = agency.username
        
        if let _ = agency.profile?.avatar {
            cell.avatarImage.hnk_setImageFromURL(NSURL.init(string: (agency.profile?.avatar)!)!)
        }
        
        if let chatUser = self.findChatAgencyWithUsername(agency.username) {
            cell.lastMessageLabel.text = chatUser.lastMessage
            
            if chatUser.unreadMessageNumber > 0 {
                cell.backgroundColor = UIColor.init(red: 226.0/255.0, green: 238.0/255.0, blue: 246.0/255.0, alpha: 1)
            }
            else {
                cell.backgroundColor = UIColor.whiteColor()
            }
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath){
        
        self.selectedIndexPath = indexPath
        self .performSegueWithIdentifier(kBQChatSegue, sender: nil)
    }
    
    func findChatAgencyWithUsername(username: String) -> BQChatUser? {
        for chatUser in self.chatAgencies {
            if chatUser.username == username {
                return chatUser
            }
        }
        return nil
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if (segue.identifier == kBQChatSegue) {

            let destinationViewController = segue.destinationViewController as! BQMessagesViewController
            
            let agency = self.agencies[self.selectedIndexPath.row]
            destinationViewController.senderId = (BQDataManager.sharedInstance.user?.username)!
            destinationViewController.senderDisplayName = (BQDataManager.sharedInstance.user?.username)!
            destinationViewController.receiverId = agency.username
            
            if let _ = agency.profile?.avatar {
                destinationViewController.receiverAvatarUrl = agency.profile?.avatar
            }
        }
    }
    
    func backButtonPressed(sender:UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    
}
