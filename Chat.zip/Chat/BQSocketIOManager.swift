//
//  SocketIOManager.swift
//  SocketChat
//
//  Created by Gabriel Theodoropoulos on 1/31/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

import UIKit


class SocketIOManager: NSObject {
    static let sharedInstance = SocketIOManager()
//    
//    var socket: SocketIOClient = SocketIOClient(socketURL: NSURL(string: "http://139.59.252.173:3000")!)
    
    var socket: SocketIOClient = SocketIOClient(socketURL: NSURL(string: "http://139.59.252.173:3000")!, options: [.ConnectParams(["token": BQDataManager.sharedInstance.userToken])])

//    var socket: SocketIOClient = SocketIOClient(socketURL: NSURL(string: "https://immense-harbor-89119.herokuapp.com")!, options: [.ConnectParams(["Authorization": BQDataManager.sharedInstance().userToken])])
    var pageNumber: Int = 100

    override init() {
        super.init()
    }
    
    func establishConnection() {
        
        socket = SocketIOClient(socketURL: NSURL(string: "http://139.59.252.173:3000")!, options: [.ConnectParams(["token": BQDataManager.sharedInstance.userToken])])
        
        socket.connect()
    }
    
    
    func closeConnection() {
        socket.disconnect()
        
    }
    
    func checkSocketStatus() {
        socket.on("disconnect") { (dataArray, socketAck) -> Void in
            print(dataArray)
        }
    }
    
    
    func connectToServerWithNickname(nickname: String, completionHandler: (unreadNumber: Int!) -> Void) {
        
        socket.emit("connectUser", nickname)
        
        socket.on("userInfo") { ( dataArray, ack) -> Void in
            let result = dataArray[0] as! [String: AnyObject]
            if let unreadMessageNumber = result["numberNewMessages"] as? NSNumber {
                completionHandler(unreadNumber: unreadMessageNumber.integerValue)
            }
            self .closeListenUserInfor()
        }
        
        listenForOtherMessages()
    }
    
    func closeListenUserInfor() {
        socket.off("userInfo");
    }
    
    func goToChatChannel(channel:String) {
        socket.emit("joinRoom", channel)

    }

    func leaveChatChannel(channel:String) {
        socket.emit("leaveRoom", channel)
        
    }

    func getUnreadThreadMessage(completionHandler: (chatUser: [BQChatUser]) -> Void) {
        
        let nickName = (BQDataManager.sharedInstance.user?.username)!

        socket.emit("connectUser", nickName)

        socket.on("recentList") { (dataArray, ack) -> Void in
            print(dataArray)
            let result = dataArray[0] as! [String: AnyObject]
            if let arrayUser = result["users"] as? [String: AnyObject]{
                
                var users = [BQChatUser]()
                
                for (_, element) in arrayUser.keys.enumerate() {
                    let user = BQChatUser()
                    user.username = element
                    
                    if let infor = arrayUser[element] as? [String: AnyObject]{
                        
                        if let message = infor["message"] as? String{
                            user.lastMessage = message
                        }
                        
                        if let unreadNUmber = infor["numberNewMessages"] as? Int{
                            user.unreadMessageNumber = unreadNUmber

                        }
                    }
                    users.append(user)
                }
                completionHandler(chatUser: users)
            }
        }
    }
    
    func disconectGetUnreadThreadMessage(){
        socket.off("recentList")
        
    }

    func exitChatWithNickname(nickname: String, completionHandler: () -> Void) {
        socket.emit("exitUser", nickname)
        completionHandler()
    }
    
    
    func sendMessage(message: String, withNickname nickname: String, toUser: String) {
        
        var messageDictionary = [String: AnyObject]()
        messageDictionary["username"] = nickname
        messageDictionary["message"] = message
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
        let dateInFormat = dateFormatter.stringFromDate(NSDate())
        messageDictionary["when"] = dateInFormat
        
        socket.emit("privateMessage", toUser, messageDictionary)
    }
    
    
    func getChatMessage(completionHandler: (messages: [BQMessage]) -> Void) {
        socket.on("newChatMessage") { (dataArray, socketAck) -> Void in
            print(dataArray)
            
            var messages = [BQMessage]()

            for result in dataArray {
                if let message = BQMessage.messageFromJSON(result as! [String : AnyObject]) {
                    messages.append(message)
                }
            }

            completionHandler(messages: messages)
        }
    }

    func disconnectHistoryChatMessage(){
        socket.off("getHistoryUser")
        
    }
    
    func getHistoryChatMessage(completionHandler: (messages: [BQMessage]) -> Void) {
        
        
        socket.on("getHistoryUser") { (dataArray, socketAck) -> Void in
            
            guard let datas = dataArray as? [AnyObject],
                let jsons = datas[0] as? [AnyObject] else {
                print("Invalid response data")
                return
            }
            
//            print("Result: \(jsons)")
            print("Send history request here")

            let messages = BQMessage.messagesFromJSON(jsons)
            
            completionHandler(messages: messages)
        }
    }

    
    func notifyGetHistoryChatMessage(user: String) {
        let page = BQDataManager.sharedInstance.messagePage
        print("Load message from: \(pageNumber * page) to \(pageNumber - 1 + pageNumber * page)")

        socket.emit("getMessagesUser", user, pageNumber * page, pageNumber - 1 + pageNumber * page)
        
    }
    
    private func listenForOtherMessages() {
        return;
        
        socket.on("userConnectUpdate") { (dataArray, socketAck) -> Void in
            NSNotificationCenter.defaultCenter().postNotificationName("userWasConnectedNotification", object: dataArray[0] as! [String: AnyObject])
        }
        
        socket.on("userExitUpdate") { (dataArray, socketAck) -> Void in
            NSNotificationCenter.defaultCenter().postNotificationName("userWasDisconnectedNotification", object: dataArray[0] as! String)
        }
        
        socket.on("userTypingUpdate") { (dataArray, socketAck) -> Void in
            NSNotificationCenter.defaultCenter().postNotificationName("userTypingNotification", object: dataArray[0] as? [String: AnyObject])
        }
    }
    
    
    func sendStartTypingMessage(nickname: String) {
        socket.emit("startType", nickname)
    }
    
    
    func sendStopTypingMessage(nickname: String) {
        socket.emit("stopType", nickname)
    }
}
