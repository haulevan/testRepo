//
//  DGOrderService.swift
//  DGRestaurant
//
//  Created by Hayward on 6/24/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGOrderService {
    
    var id: Int!
    var name: String?
    var amount: Float?
    var orderId: Int!
    
    class func orderServiceFromJSON(json: [String: AnyObject]) -> DGOrderService {
        
        let orderService = DGOrderService()
        
        orderService.id = json["service_id"] as! Int
        orderService.id = Int(json["service_id"] as! String)
        orderService.amount = json["amount"] as? Float
        orderService.name = json["service_name"] as? String
        orderService.orderId = Int(json["order_id"] as! String)

        return orderService
    }
    
    class func orderServicesFromJSON(json: [String: AnyObject]) -> [DGOrderService] {
        
        var orderServices = [DGOrderService]()
        
        if let results = json["order_service"] as? [AnyObject] {
            for result in results {
                let orderService = DGOrderService.orderServiceFromJSON(result as! [String : AnyObject])
                orderServices.append(orderService)
            }
        }
        
        return orderServices
    }
    
    
    class func orderServiceFromXMPPJSON(json: [String: AnyObject]) -> DGOrderService {
        
        let orderService = DGOrderService()
        
        orderService.id = Int(json["service_id"] as! String)
        orderService.id = Int(json["service_id"] as! String)
        orderService.amount = Float((json["amount"] as? String)!)
        orderService.name = json["service_name"] as? String
        orderService.orderId = Int(json["order_id"] as! String)
        
        return orderService
    }
    
    class func orderServicesFromXMPPJSON(json: [String: AnyObject]) -> [DGOrderService] {
        
        var orderServices = [DGOrderService]()
        
        if let results = json["order_service"] as? [AnyObject] {
            for result in results {
                let orderService = DGOrderService.orderServiceFromXMPPJSON(result as! [String : AnyObject])
                orderServices.append(orderService)
            }
        }
        
        return orderServices
    }
    
    class func orderServiceFromResultSet(rs: FMResultSet) -> DGOrderService {
        
        let orderService = DGOrderService()
        
        orderService.id = Int(rs.intForColumn("service_id"))
        orderService.name = rs.stringForColumn("service_name")
        orderService.amount = Float(rs.intForColumn("amount"))
        orderService.orderId = Int(rs.intForColumn("order_id"))
        
        return orderService
    }
}
