//
//  DGPromotionCode.swift
//  DGRestaurant
//
//  Created by Hayward on 11/19/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGPromotionCode {
    
    var amount: Int?
    var atmType: Int? // 0: fixed value, 1: percent
    var code: String?
    var name: String?
    
    class func promotionCodeFromJSON(json: [String: AnyObject]) -> DGPromotionCode {
        
        let promotion = DGPromotionCode()
        
        promotion.amount = json["amount"] as? Int
        promotion.atmType = json["amt_type"] as? Int
        promotion.code = json["code"] as? String
        promotion.name = json["promotion_name"] as? String
        
        return promotion
    }
    
    class func promotionCodeFromResultSet(rs: FMResultSet) -> DGPromotionCode {
        
        let promotion = DGPromotionCode()
        
        promotion.amount = Int(rs.intForColumn("amount"))
        promotion.atmType = Int(rs.intForColumn("amt_type"))
        promotion.code = rs.stringForColumn("code")
        promotion.name = rs.stringForColumn("promotion_name")
        
        return promotion
    }
}
