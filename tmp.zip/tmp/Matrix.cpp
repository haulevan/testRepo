//
//  Matrix.cpp
//  CalcLib
//
//  Created by HauLe on 12/2/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "Matrix.hpp"

namespace DT {

    //! Template instantiation of Mat<double>
    template class Mat<double>;
    //! Template instantiation of Mat<complex<double>>
    template class Mat<complex<double>>;
    //! Template instantiation of Mat<int>
    template class Mat<int>;
    //! Template instantiation of Mat<short int>
    template class Mat<short int>;
    
    //! Template instantiation of operator+
    template mat operator+(const mat &m1, const mat &m2);
    //! Template instantiation of operator+
    template cmat operator+(const cmat &m1, const cmat &m2);
    //! Template instantiation of operator+
    template imat operator+(const imat &m1, const imat &m2);
    //! Template instantiation of operator+
    template smat operator+(const smat &m1, const smat &m2);
    
    //! Template instantiation of operator+
    template mat operator+(const mat &m, double t);
    //! Template instantiation of operator+
    template cmat operator+(const cmat &m, complex<double> t);
    //! Template instantiation of operator+
    template imat operator+(const imat &m, int t);
    //! Template instantiation of operator+
    template smat operator+(const smat &m, short t);
    
    //! Template instantiation of operator+
    template mat operator+(double t, const mat &m);
    //! Template instantiation of operator+
    template cmat operator+(complex<double> t, const cmat &m);
    //! Template instantiation of operator+
    template imat operator+(int t, const imat &m);
    //! Template instantiation of operator+
    template smat operator+(short t, const smat &m);
    
    //-------- Subraction operators ---------------
    //! Template instantiation of operator-
    template mat operator-(const mat &m1, const mat &m2);
    //! Template instantiation of operator-
    template cmat operator-(const cmat &m1, const cmat &m2);
    //! Template instantiation of operator-
    template imat operator-(const imat &m1, const imat &m2);
    //! Template instantiation of operator-
    template smat operator-(const smat &m1, const smat &m2);
    
    //! Template instantiation of operator-
    template mat operator-(const mat &m, double t);
    //! Template instantiation of operator-
    template cmat operator-(const cmat &m, complex<double> t);
    //! Template instantiation of operator-
    template imat operator-(const imat &m, int t);
    //! Template instantiation of operator-
    template smat operator-(const smat &m, short t);
    
    //! Template instantiation of operator-
    template mat operator-(double t, const mat &m);
    //! Template instantiation of operator-
    template cmat operator-(complex<double> t, const cmat &m);
    //! Template instantiation of operator-
    template imat operator-(int t, const imat &m);
    //! Template instantiation of operator-
    template smat operator-(short t, const smat &m);
    
    //--------- Unary minus ---------------
    //! Template instantiation of operator-
    template mat operator-(const mat &m);
    //! Template instantiation of operator-
    template cmat operator-(const cmat &m);
    //! Template instantiation of operator-
    template imat operator-(const imat &m);
    //! Template instantiation of operator-
    template smat operator-(const smat &m);
    
    //-------- Multiplication operators ---------------
    //! Template instantiation of operator*
    template imat operator*(const imat &m1, const imat &m2);
    //! Template instantiation of operator*
    template smat operator*(const smat &m1, const smat &m2);
    
    //! Template instantiation of operator*
    template ivec operator*(const imat &m, const ivec &v);
    //! Template instantiation of operator*
    template svec operator*(const smat &m, const svec &v);
    
    //! Template instantiation of operator*
    template ivec operator*(const ivec &v, const imat &m);
    //! Template instantiation of operator*
    template svec operator*(const svec &v, const smat &m);
    
    //! Template instantiation of operator*
    template mat operator*(const mat &m, double t);
    //! Template instantiation of operator*
    template cmat operator*(const cmat &m, complex<double> t);
    //! Template instantiation of operator*
    template imat operator*(const imat &m, int t);
    //! Template instantiation of operator*
    template smat operator*(const smat &m, short t);
    
    //! Template instantiation of operator*
    template mat operator*(double t, const mat &m);
    //! Template instantiation of operator*
    template cmat operator*(complex<double> t, const cmat &m);
    //! Template instantiation of operator*
    template imat operator*(int t, const imat &m);
    //! Template instantiation of operator*
    template smat operator*(short t, const smat &m);
    
    // ------------ Elementwise multiplication -----------
    //! Template instantiation of elem_mult
    template mat elem_mult(const mat &m1, const mat &m2);
    //! Template instantiation of elem_mult
    template cmat elem_mult(const cmat &m1, const cmat &m2);
    //! Template instantiation of elem_mult
    template imat elem_mult(const imat &m1, const imat &m2);
    //! Template instantiation of elem_mult
    template smat elem_mult(const smat &m1, const smat &m2);
    
    // ------------ Division operator -----------
    //! Template instantiation of operator/
    template mat operator/(const mat &m, double t);
    //! Template instantiation of operator/
    template cmat operator/(const cmat &m, complex<double> t);
    //! Template instantiation of operator/
    template imat operator/(const imat &m, int t);
    //! Template instantiation of operator/
    template smat operator/(const smat &m, short t);
    
    // ------------ Elementwise division -----------
    //! Template instantiation of elem_div
    template mat elem_div(const mat &m1, const mat &m2);
    //! Template instantiation of elem_div
    template cmat elem_div(const cmat &m1, const cmat &m2);
    //! Template instantiation of elem_div
    template imat elem_div(const imat &m1, const imat &m2);
    //! Template instantiation of elem_div
    template smat elem_div(const smat &m1, const smat &m2);
    
    // ------------- Concatenations -----------------
    //! Template instantiation of concat_horizontal
    template mat concat_horizontal(const mat &m1, const mat &m2);
    //! Template instantiation of concat_horizontal
    template cmat concat_horizontal(const cmat &m1, const cmat &m2);
    //! Template instantiation of concat_horizontal
    template imat concat_horizontal(const imat &m1, const imat &m2);
    //! Template instantiation of concat_horizontal
    template smat concat_horizontal(const smat &m1, const smat &m2);
    
    //! Template instantiation of concat_vertical
    template mat concat_vertical(const mat &m1, const mat &m2);
    //! Template instantiation of concat_vertical
    template cmat concat_vertical(const cmat &m1, const cmat &m2);
    //! Template instantiation of concat_vertical
    template imat concat_vertical(const imat &m1, const imat &m2);
    //! Template instantiation of concat_vertical
    template smat concat_vertical(const smat &m1, const smat &m2);

    /*
     Return the mean value of the elements in the vector
     */
    double mean(const vec &v)
    {
        return sum(v)/v.length();
    }
    
    /*
     Return the mean value of the elements in the vector
     */
    double mean(const svec &v)
    {
        return (double)sum(v)/v.length();
    }
    
    /*
     Return the mean value of the elements in the vector
     */
    double mean(const ivec &v)
    {
        return (double)sum(v)/v.length();
    }
    
    /*
     Return the mean value of the elements in the matrix
     */
    double mean(const mat &m)
    {
        return sum(m)/(m.rows()*m.cols());
    }
    
    /*
     Return the mean value of the elements in the matrix
     */
    complex<double> mean(const cmat &m)
    {
        //    return sum(m)/static_cast<complex<double>>(m.rows()*m.cols());
        return ((double)(1/(m.rows()*m.cols()))*sum(m));
    }
    
    /*
     Return the mean value of the elements in the matrix
     */
    double mean(const smat &m)
    {
        return static_cast<double>(sum(m))/(m.rows()*m.cols());
    }
    
    /*
     Return the mean value of the elements in the matrix
     */
    double mean(const imat &m)
    {
        return static_cast<double>(sum(m))/(m.rows()*m.cols());
    }
}
