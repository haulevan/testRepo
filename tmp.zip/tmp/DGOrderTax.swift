//
//  DGOrderTax.swift
//  DGRestaurant
//
//  Created by Hayward on 6/24/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGOrderTax {
    
    var id: Int!
    var name: String?
    var amount: Float?
    var orderId: Int!
    
    class func orderTaxFromJSON(json: [String: AnyObject]) -> DGOrderTax {
        
        let orderTax = DGOrderTax()

        orderTax.id = json["tax_id"] as! Int
        orderTax.id = Int(json["tax_id"] as! String)
        orderTax.amount = json["amount"] as? Float
        orderTax.name = json["tax_name"] as? String
        orderTax.orderId = json["order_id"] as! Int

//        orderTax.orderId = Int(json["order_id"] as! String)
        
        return orderTax
    }
    
    class func orderTaxesFromJSON(json: [String: AnyObject]) -> [DGOrderTax] {
        
        var orderTaxes = [DGOrderTax]()
        
        if let results = json["order_tax"] as? [AnyObject] {
            for result in results {
                let orderTax = DGOrderTax.orderTaxFromJSON(result as! [String : AnyObject])
                orderTaxes.append(orderTax)
            }
        }
        
        return orderTaxes
    }
    
    class func orderTaxFromXMPPJSON(json: [String: AnyObject]) -> DGOrderTax {
        
        let orderTax = DGOrderTax()
        
        orderTax.id = Int(json["tax_id"] as! String)
        orderTax.id = Int(json["tax_id"] as! String)
        orderTax.amount = Float((json["amount"] as? String)!)
        orderTax.name = json["tax_name"] as? String
        orderTax.orderId = Int(json["order_id"] as! String)
        
        return orderTax
    }
    
    class func orderTaxesFromXMPPJSON(json: [String: AnyObject]) -> [DGOrderTax] {
        
        var orderTaxes = [DGOrderTax]()
        
        if let results = json["order_tax"] as? [AnyObject] {
            for result in results {
                let orderTax = DGOrderTax.orderTaxFromXMPPJSON(result as! [String : AnyObject])
                orderTaxes.append(orderTax)
            }
        }
        
        return orderTaxes
    }
    

    class func orderTaxFromResultSet(rs: FMResultSet) -> DGOrderTax {
        
        let orderTax = DGOrderTax()
        
        orderTax.id = Int(rs.intForColumn("tax_id"))
        orderTax.name = rs.stringForColumn("tax_name")
        orderTax.amount = Float(rs.intForColumn("amount"))
        orderTax.orderId = Int(rs.intForColumn("order_id"))
        
        return orderTax
    }
}
