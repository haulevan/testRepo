//
//  DT4.cpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "DT4.hpp"

namespace DT
{
    DT4::DT4(const char *fileName)
    {
        
    }
    
    DT4::DT4(Mat<double> &m)
    {
        this->m = new Mat<double>(m);
    }
    
    void DT4::calculate()
    {
        Vec<double> t4 = m->get_col(0);  // time in  milliseconds
        t4 /= 1000; // time is now in seconds
        
        Vec<double> gyrox4 = m->get_col(4);
        Vec<double> gyroy4 = m->get_col(5);
        Vec<double> gyroz4 = m->get_col(6);
        
        Vec<double> accx4 = m->get_col(1);
        Vec<double> accy4 = m->get_col(2);
        Vec<double> accz4 = m->get_col(3);
        
        Vec<double> qw4 = m->get_col(7);
        Vec<double> qx4 = m->get_col(8);
        Vec<double> qy4 = m->get_col(9);
        Vec<double> qz4 = m->get_col(10);
        
        Mat<double> quaternion4 = m->get_cols(7, 10);
        Mat<complex<double>> euler4 = quatern2euler(quaternion4);
        euler4 *= (180/M_PI);
        Vec<double> eux4 = euler4.get_col(0).realComplex();
        Vec<double> euy4 = euler4.get_col(1).realComplex();
        Vec<double> euz4 = euler4.get_col(2).realComplex();
        
        Vec<double> gx4 = 2.0 * (elem_mult(qx4, qz4) - elem_mult(qw4, qy4));
        Vec<double> gy4 = 2.0 * (elem_mult(qw4, qx4) + elem_mult(qy4, qz4));
        Vec<double> gz4 = elem_mult(qw4, qw4) - elem_mult(qx4, qx4) - elem_mult(qy4, qy4) + elem_mult(qz4, qz4);
    }
}
