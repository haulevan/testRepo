//
//  DGDatabaseQueries.swift
//  DGRestaurant
//
//  Created by Hayward on 6/28/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

let kDGDataFileName = "restaurant.sqlite"

// MARK: - User queries
/**
 *  Get user by ID
 */
let kDGQueryUserByID = "SELECT * from user WHERE id = ?;"

/**
 *  Get all users
 */
let kDGQueryAllUsers = "SELECT * from user ORDER BY id DESC;"

/**
 *  Create new user
 */
let kDGQueryAddUser = "INSERT or REPLACE INTO user (id, firstname, lastname, email, pwd, address1, address2, city, country, is_restaurant_owner, job, notes, phone_number, photo_url, user_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"

/**
 *  Update existing user
 */
let kDGQueryUpdateUser = "UPDATE user SET firstname = ?, lastname = ?, email = ?, pwd = ?, address1 = ?, address2 = ?, city = ?, country = ?, is_restaurant_owner = ?, job = ?, notes = ?, phone_number = ?, photo_url = ?, user_type = ? WHERE id = ?;"



// MARK: - Restaurant queries
/**
 *  Create new restaurant
 */
let kDGQueryAddRestaurant = "INSERT or REPLACE INTO restaurant (restaurant_id, restaurant_name, address1, address2, chain_id, city, country, lat, lng, owner, phone, photo_url, status, tags, wifi, zip) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"

/**
 *  Get restaurant by ID
 */
let kDGQueryRestaurantByID = "SELECT * from restaurant WHERE restaurant_id = ?;"

/**
 *  Get all restaurants
 */
let kDGQueryAllRestaurants = "SELECT * from restaurant ORDER BY restaurant_id DESC;"

/**
 *  Delete restaurant by ID
 */
let kDGQueryDeleteRestaurantByID = "DELETE from restaurant WHERE restaurant_id = ?;"

/**
 *  Delete all restaurants
 */
let kDGQueryDeleteAllRestaurants = "DELETE from restaurant;"



// MARK: - Table queries
/**
 *  Create new table
 */
let kDGQueryAddTable = "INSERT or REPLACE INTO dgTable (table_id, table_name, seats, status, restaurant_id) VALUES (?, ?, ?, ?, ?);"

/**
 *  Get all tables
 */
let kDGQueryAllTables = "SELECT * from dgTable ORDER BY table_id DESC;"

/**
 *  Delete all tables
 */
let kDGQueryDeleteAllTables = "DELETE from dgTable;"



// MARK: - Category queries
/**
 *  Create new category
 */
let kDGQueryAddCategory = "INSERT or REPLACE INTO category (category_id, category_name, food_count) VALUES (?, ?, ?);"

/**
 *  Get all categories
 */
let kDGQueryAllCategories = "SELECT * from category ORDER BY category_id DESC;"

/**
 *  Delete all categories
 */
let kDGQueryDeleteAllCategories = "DELETE from category;"



// MARK: - Food queries
/**
 *  Create new food
 */
let kDGQueryAddFood = "INSERT or REPLACE INTO food (food_id, food_name, food_description, comment_count, liked, rated, food_category, food_category_name, photo_name, photo_url_index, photo_proccessed, isLiked, isFavorited, type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"

/**
 *  Update existing food
 */
let kDGQueryUpdateFood = "UPDATE food SET food_name = ?, food_description = ?, comment_count = ?, liked = ?, rated = ?, food_category = ?, food_category_name = ?, photo_name = ?, photo_url_index = ?, photo_proccessed = ?, isLiked = ?, isFavorited = ?, type = ? WHERE food_id = ?;"

/**
 *  Get food by ID
 */
let kDGQueryFoodByID = "SELECT * from food WHERE food_id = ?;"

/**
 *  Get food by type
 */
let kDGQueryFoodByType = "SELECT * from food WHERE type & ?;"

/**
 *  Get food by categoryID
 */
let kDGQueryFoodByCategoryID = "SELECT * from food WHERE food_category = ?;"

/**
 *  Update liked food
 */
let kDGQueryUpdateLikedFood = "UPDATE food SET isLiked = ? WHERE food_id = ?;"

/**
 *  Update favorited food
 */
let kDGQueryUpdateFavoritedFood = "UPDATE food SET isFavorited = ? WHERE food_id = ?;"

/**
 *  Get liked foods
 */
let kDGQueryLikedFoods = "SELECT * from food WHERE isLiked = 1 ORDER BY food_id DESC;"

/**
 *  Get favorited foods
 */
let kDGQueryFavoritedFoods = "SELECT * from food WHERE isFavorited = 1 ORDER BY food_id DESC;"

/**
 *  Get all foods
 */
let kDGQueryAllFoods = "SELECT * from food ORDER BY food_id DESC;"

/**
 *  Delete all foods
 */
let kDGQueryDeleteAllFoods = "DELETE from food;"

/**
 *  Search foods
 */
let kDGQuerySearchFoods = "SELECT * from food WHERE food_name LIKE ? ORDER BY food_id DESC;"



// MARK: - Price queries
/**
 *  Create new price
 */
let kDGQueryAddPrice = "INSERT or REPLACE INTO price (id, price, size, food_id) VALUES (?, ?, ?, ?);"

/**
 *  Get prices by foodId
 */
let kDGQueryPricesByFoodId = "SELECT * from price WHERE food_id = ? ORDER BY id DESC;"

/**
 *  Delete all prices
 */
let kDGQueryDeleteAllPrices = "DELETE from price;"



// MARK: - Comment queries
/**
 *  Create new comment
 */
let kDGQueryAddComment = "INSERT or REPLACE INTO comment (comment_id, user, content, status, created_at, updated_at, user_display_name, food_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?);"

/**
 *  Update existing comment
 */
let kDGQueryUpdateComment = "UPDATE comment SET user = ?, content = ?, status = ?, created_at = ?, updated_at = ?, user_display_name = ?, food_id = ? WHERE comment_id = ?;"

/**
 *  Get comments by foodId
 */
let kDGQueryCommentsByFoodId = "SELECT * from comment WHERE food_id = ? ORDER BY comment_id DESC;"

/**
 *  Delete comment by ID
 */
let kDGQueryDeleteCommentByID = "DELETE from comment WHERE comment_id = ?;"

/**
 *  Delete all comments
 */
let kDGQueryDeleteAllComments = "DELETE from comment;"



// MARK: - Order queries
/**
 *  Create new order
 */
let kDGQueryAddOrder = "INSERT or REPLACE INTO dgOrder (order_id, table_id, amount, total_amount, service_amount, tax_amount, time, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);"

/**
 *  Get order by ID
 */
let kDGQueryOrderByID = "SELECT * from dgOrder WHERE order_id = ?;"

/**
 *  Get all orders
 */
let kDGQueryAllOrders = "SELECT * from dgOrder ORDER BY order_id DESC;"

/**
 *  Delete all orders
 */
let kDGQueryDeleteAllOrders = "DELETE from dgOrder;"



// MARK: - OrderItem queries
/**
 *  Create new order item
 */
let kDGQueryAddOrderItem = "INSERT or REPLACE INTO orderItem (id, order_id, food_id, food_name, cost, qty, size, notes, last_update, status, canceled_note, rejected_note, return_note, tv_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);"

/**
 *  Get order items by order ID
 */
let kDGQueryOrderItemsByOrderID = "SELECT * from orderItem WHERE order_id = ?;"

/**
 *  Delete all order items
 */
let kDGQueryDeleteAllOrderItems = "DELETE from orderItem;"



// MARK: - OrderService queries
/**
 *  Create new order service
 */
let kDGQueryAddOrderService = "INSERT or REPLACE INTO orderService (service_id, amount, service_name, order_id) VALUES (?, ?, ?, ?);"

/**
 *  Get order services by order ID
 */
let kDGQueryOrderServicesByOrderID = "SELECT * from orderService WHERE order_id = ?;"

/**
 *  Delete all order services
 */
let kDGQueryDeleteAllOrderServices = "DELETE from orderService;"



// MARK: - OrderTax queries
/**
 *  Create new order tax
 */
let kDGQueryAddOrderTax = "INSERT or REPLACE INTO orderTax (tax_id, amount, tax_name, order_id) VALUES (?, ?, ?, ?);"

/**
 *  Get order taxes by order ID
 */
let kDGQueryOrderTaxesByOrderID = "SELECT * from orderTax WHERE order_id = ?;"

/**
 *  Delete all order taxes
 */
let kDGQueryDeleteAllOrderTaxes = "DELETE from orderTax;"
