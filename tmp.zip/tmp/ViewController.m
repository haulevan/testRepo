//
//  ViewController.m
//  TestLib
//
//  Created by Hayward on 11/29/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#import "ViewController.h"
#import "TestClass.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    TestClass *test = [[TestClass alloc] init];
    [test run];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
