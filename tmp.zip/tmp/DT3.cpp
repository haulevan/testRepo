//
//  DT3.cpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "DT3.hpp"

namespace DT
{
    DT3::DT3(const char *fileName)
    {
        
    }
    
    DT3::DT3(Mat<double> &m)
    {
        this->m = new Mat<double>(m);
    }
    
    void DT3::calculate()
    {
        Vec<double> t3 = m->get_col(0);  // time in  milliseconds
        t3 /= 1000; // time is now in seconds
        
        Vec<double> gyrox3 = m->get_col(4);
        Vec<double> gyroy3 = m->get_col(5);
        Vec<double> gyroz3 = m->get_col(6);
        
        Vec<double> accx3 = m->get_col(1);
        Vec<double> accy3 = m->get_col(2);
        Vec<double> accz3 = m->get_col(3);
        
        Vec<double> qw3 = m->get_col(7);
        Vec<double> qx3 = m->get_col(8);
        Vec<double> qy3 = m->get_col(9);
        Vec<double> qz3 = m->get_col(10);
        
//        print(*m);
//        qz3.print();
        
        Mat<double> quaternion3 = m->get_cols(7, 10);
        Mat<complex<double>> euler3 = quatern2euler(quaternion3);
        euler3 *= (180/M_PI);
        Vec<double> eux3 = euler3.get_col(0).realComplex();
        Vec<double> euy3 = euler3.get_col(1).realComplex();
        Vec<double> euz3 = euler3.get_col(2).realComplex();
        
        Vec<double> gx3 = 2.0 * (elem_mult(qx3, qz3) - elem_mult(qw3, qy3));
        Vec<double> gy3 = 2.0 * (elem_mult(qw3, qx3) + elem_mult(qy3, qz3));
        Vec<double> gz3 = elem_mult(qw3, qw3) - elem_mult(qx3, qx3) - elem_mult(qy3, qy3) + elem_mult(qz3, qz3);
    }
}
