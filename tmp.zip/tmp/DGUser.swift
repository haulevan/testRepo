//
//  DGUser.swift
//  DGRestaurant
//
//  Created by Hayward on 6/17/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGUser {
    
    var id: Int!
    var firstName: String?
    var lastName: String?
    var email: String!
    var password: String!
    var address1: String?
    var address2: String?
    var city: String?
    var country: String?
    var isRestaurantOwner: Bool?
    var job: String?
    var notes: String?
    var phoneNumber: String?
    var messageKey: String?

    var photo: DGPhoto?
    var userType: DGUserType?
    
    var restaurantId: Int!
    
    class func userFromJSON(json: [String: AnyObject]) -> DGUser {
        
        let user = DGUser()
        
        user.id = Int(json["id"] as! String)
        user.firstName = json["firstname"] as? String
        user.lastName = json["lastname"] as? String
        user.email = json["email"] as! String
        user.password = json["pwd"] as! String
        user.address1 = json["address1"] as? String
        user.address2 = json["address2"] as? String
        user.city = json["city"] as? String
        user.country = json["country"] as? String
        user.isRestaurantOwner = json["is_restaurant_owner"] as? Bool
        user.job = json["job"] as? String
        user.notes = json["notes"] as? String
        user.phoneNumber = json["phone_number"] as? String
        user.messageKey = json["message_key"] as? String

        user.userType = json["user_type"] as? DGUserType
        
        if let photoJSON = json["photo"] as? [String : AnyObject] {
            user.photo = DGPhoto.photoFromJSON(photoJSON)
        }
        
        user.restaurantId = Int(json["restaurant_id"] as! String)
        
        return user
    }
    
    class func userFromResultSet(rs: FMResultSet) -> DGUser {
        
        let user = DGUser()
        
        user.id = Int(rs.intForColumn("id"))
        user.firstName = rs.stringForColumn("firstname")
        user.lastName = rs.stringForColumn("lastname")
        user.email = rs.stringForColumn("email")
        user.password = rs.stringForColumn("pwd")
        user.address1 = rs.stringForColumn("address1")
        user.address2 = rs.stringForColumn("address2")
        user.city = rs.stringForColumn("city")
        user.country = rs.stringForColumn("country")
        user.isRestaurantOwner = rs.boolForColumn("is_restaurant_owner")
        user.job = rs.stringForColumn("job")
        user.notes = rs.stringForColumn("notes")
        user.phoneNumber = rs.stringForColumn("phone_number")
        user.userType = DGUserType(rawValue: Int(rs.intForColumn("user_type")))
        
        if let photoUrl = rs.stringForColumn("photo_url") {
            let photo = DGPhoto()
            photo.url = photoUrl
            user.photo = photo
        }
        
        return user
    }

}
