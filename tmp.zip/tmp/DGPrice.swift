//
//  DGPrice.swift
//  DGRestaurant
//
//  Created by Hayward on 6/19/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGPrice {
    
    var id: Int?
    var value: Float?
    var size: String?
    var foodId: Int?
    
    class func priceFromJSON(json: [String: AnyObject]) -> DGPrice {
        
        let price = DGPrice()
        
        price.id = json["id"] as? Int
        price.value = json["price"] as? Float
        price.size = json["size"] as? String
        price.foodId = json["food_id"] as? Int
        
        return price
    }
    
    class func pricesFromJSON(json: [String: AnyObject]) -> [DGPrice] {
        
        var prices = [DGPrice]()
        
        if let results = json["prices"] as? [AnyObject] {
            for result in results {
                let price = DGPrice.priceFromJSON(result as! [String : AnyObject])
                prices.append(price)
            }
        }
        
        return prices.sort({ $0.value < $1.value })
    }
    
    class func priceFromResultSet(rs: FMResultSet) -> DGPrice {
        
        let price = DGPrice()
        
        price.id = Int(rs.intForColumn("id"))
        price.value = Float(rs.stringForColumn("price"))
        price.size = rs.stringForColumn("size")
        price.foodId = Int(rs.intForColumn("food_id"))
        
        return price
    }
    
    func fullTextSize() -> String {
        if self.size == "S" {
            return "Small"
        }
        if self.size == "M" {
            return "Medium"
        }
        if self.size == "L" {
            return "Large"
        }
        return self.size!
    }
}
