//
//  DGConfig.swift
//  DGRestaurant
//
//  Created by Hayward on 6/17/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGConfig: NSObject, NSCoding {
    
    var serviceEndPoint: String!
    var photoUrls: [String: String]!
    
    override init() {}
    
    // MARK: NSCoding
    @objc required init(coder aDecoder: NSCoder) {
        serviceEndPoint = aDecoder.decodeObjectForKey("serviceEndPoint") as! String
        photoUrls = aDecoder.decodeObjectForKey("photoUrls") as! [String: String]
    }
    
    @objc func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(serviceEndPoint, forKey: "serviceEndPoint")
        aCoder.encodeObject(photoUrls, forKey: "photoUrls")
    }
    
    // MARK: Parse JSON
    class func configFromJSON(json: [String: AnyObject]) -> DGConfig {
        
        let config = DGConfig()
        
        config.serviceEndPoint = json["service_end_point"] as! String
        config.photoUrls = [:]
        let urlDict = json["photo_urls"] as! [String: String]
        
        config.photoUrls = urlDict
        
        return config
    }
    
    // MARK: Cache data
    func cache() {
        let ud = NSUserDefaults.standardUserDefaults()
        ud.setObject(NSKeyedArchiver.archivedDataWithRootObject(self), forKey: kDGConfiguration)
        ud.synchronize()
    }
    
    class func getCache() -> DGConfig? {
        let ud = NSUserDefaults.standardUserDefaults()
        if let data = ud.objectForKey(kDGConfiguration) as? NSData {
            return NSKeyedUnarchiver.unarchiveObjectWithData(data) as? DGConfig
        }
        return nil
    }
}
