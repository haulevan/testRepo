//
//  DGComment.swift
//  DGRestaurant
//
//  Created by Hayward on 6/19/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGComment {
    
    var id: Int!
    var user: String!
    var content: String?
    var status: Int?
    var created: NSTimeInterval!
    var updated: NSTimeInterval?
    var username: String?
    var foodId: Int!
    
    class func commentFromJSON(json: [String: AnyObject]) -> DGComment {
        
        let comment = DGComment()
        
        comment.id = json["comment_id"] as! Int
        comment.user = json["user"] as! String
        comment.content = json["content"] as? String
        comment.status = json["status"] as? Int
        comment.created = json["created_at"] as! NSTimeInterval
        comment.updated = json["updated_at"] as? NSTimeInterval
        comment.username = json["user_display_name"] as? String
        comment.foodId = json["food_id"] as! Int
        
        return comment
    }
    
    class func commentsFromJSON(json: [String: AnyObject]) -> [DGComment] {
        
        var comments = [DGComment]()
        
        if let results = json["data"] as? [AnyObject] {
            for result in results {
                let comment = DGComment.commentFromJSON(result as! [String : AnyObject])
                comments.append(comment)
            }
        }
        
        return comments
    }
    
    class func commentFromResultSet(rs: FMResultSet) -> DGComment {
        
        let comment = DGComment()
        
        comment.id = Int(rs.intForColumn("comment_id"))
        comment.user = rs.stringForColumn("user")
        comment.content = rs.stringForColumn("content")
        comment.status = Int(rs.intForColumn("status"))
        comment.created = Double(rs.doubleForColumn("created_at"))
        comment.updated = Double(rs.doubleForColumn("updated_at"))
        comment.username = rs.stringForColumn("user_display_name")
        comment.foodId = Int(rs.intForColumn("food_id"))
        
        return comment
    }
}