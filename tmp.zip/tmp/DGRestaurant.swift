//
//  DGRestaurant.swift
//  DGRestaurant
//
//  Created by Hayward on 6/18/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGRestaurant: NSObject, NSCoding {
    
    var id: Int!
    var name: String!
    var address1: String?
    var address2: String?
    var chainId: Int?
    var city: String?
    var country: String?
    var lat: Float?
    var lng: Float?
    var owner: String?
    var phone: String?
    var photo: DGPhoto?
    var status: Int?
    var tags: String?
    var wifi: String?
    var zip: String?
    
    override init() {}
    
    // MARK: NSCoding
    @objc required init(coder aDecoder: NSCoder) {
        
        id = aDecoder.decodeObjectForKey("id") as! Int
        name = aDecoder.decodeObjectForKey("name") as? String
        address1 = aDecoder.decodeObjectForKey("address1") as? String
        address2 = aDecoder.decodeObjectForKey("address2") as? String
        chainId = aDecoder.decodeObjectForKey("chainId") as? Int
        city = aDecoder.decodeObjectForKey("city") as? String
        country = aDecoder.decodeObjectForKey("country") as? String
        lat = aDecoder.decodeObjectForKey("lat") as? Float
        lng = aDecoder.decodeObjectForKey("lng") as? Float
        owner = aDecoder.decodeObjectForKey("owner") as? String
        phone = aDecoder.decodeObjectForKey("phone") as? String
        status = aDecoder.decodeObjectForKey("status") as? Int
        tags = aDecoder.decodeObjectForKey("tags") as? String
        wifi = aDecoder.decodeObjectForKey("wifi") as? String
        zip = aDecoder.decodeObjectForKey("zip") as? String
    }
    
    @objc func encodeWithCoder(aCoder: NSCoder) {
        
        aCoder.encodeObject(id, forKey: "id")
        aCoder.encodeObject(name, forKey: "name")
        aCoder.encodeObject(address1, forKey: "address1")
        aCoder.encodeObject(address2, forKey: "address2")
        aCoder.encodeObject(chainId, forKey: "chainId")
        aCoder.encodeObject(city, forKey: "city")
        aCoder.encodeObject(country, forKey: "country")
        aCoder.encodeObject(lat, forKey: "lat")
        aCoder.encodeObject(lng, forKey: "lng")
        aCoder.encodeObject(owner, forKey: "owner")
        aCoder.encodeObject(phone, forKey: "phone")
        aCoder.encodeObject(status, forKey: "status")
        aCoder.encodeObject(tags, forKey: "owner")
        aCoder.encodeObject(wifi, forKey: "phone")
        aCoder.encodeObject(status, forKey: "zip")
    }
    
    class func restaurantFromJSON(json: [String: AnyObject]) -> DGRestaurant {
        
        let restaurant = DGRestaurant()
        
        restaurant.id = json["restaurant_id"] as! Int
        restaurant.name = json["restaurant_name"] as! String
        restaurant.address1 = json["address_1"] as? String
        restaurant.address2 = json["address_2"] as? String
        restaurant.chainId = json["chain_id"] as? Int
        restaurant.city = json["city"] as? String
        restaurant.country = json["country"] as? String
        restaurant.lat = json["lat"] as? Float
        restaurant.lng = json["lng"] as? Float
        restaurant.owner = json["owner"] as? String
        restaurant.phone = json["phone"] as? String
        
        if let photoJSON = json["photos"] as? [String : AnyObject] {
            restaurant.photo = DGPhoto.photoFromJSON(photoJSON)
        }
        
        restaurant.status = json["status"] as? Int
        restaurant.tags = json["tags"] as? String
        restaurant.wifi = json["wifi"] as? String
        restaurant.zip = json["zip"] as? String
        
        return restaurant
    }
    
    class func restaurantsFromJSON(json: [String: AnyObject]) -> [DGRestaurant] {
        
        var restaurants = [DGRestaurant]()
        
        if let results = json["data"] as? [AnyObject] {
            for result in results {
                let restaurant = DGRestaurant.restaurantFromJSON(result as! [String : AnyObject])
                restaurants.append(restaurant)
            }
        }
        
        return restaurants
    }
    
    class func restaurantFromResultSet(rs: FMResultSet) -> DGRestaurant {
        
        let restaurant = DGRestaurant()
        
        restaurant.id = Int(rs.intForColumn("restaurant_id"))
        restaurant.name = rs.stringForColumn("restaurant_name")
        restaurant.address1 = rs.stringForColumn("address_1")
        restaurant.address2 = rs.stringForColumn("address_2")
        restaurant.chainId = Int(rs.intForColumn("chain_id"))
        restaurant.city = rs.stringForColumn("city")
        restaurant.country = rs.stringForColumn("country")
        restaurant.lat = Float(rs.doubleForColumn("lat"))
        restaurant.lng = Float(rs.doubleForColumn("lng"))
        restaurant.owner = rs.stringForColumn("owner")
        restaurant.phone = rs.stringForColumn("phone")
        restaurant.status = Int(rs.intForColumn("status"))
        restaurant.tags = rs.stringForColumn("tags")
        restaurant.wifi = rs.stringForColumn("wifi")
        restaurant.zip = rs.stringForColumn("zip")
        
        if let photoUrl = rs.stringForColumn("photo_url") {
            let photo = DGPhoto()
            photo.url = photoUrl
            restaurant.photo = photo
        }
        
        return restaurant
    }
}
