//
//  DGTax.swift
//  DGRestaurant
//
//  Created by Hayward on 6/25/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGTax: NSObject, NSCoding {
    
    var id: Int!
    var name: String?
    var type: Int?
    var value: Float?
    var isActive: Bool?
    
    override init() {}
    
    // MARK: NSCoding
    @objc required init(coder aDecoder: NSCoder) {
        
        id = aDecoder.decodeObjectForKey("id") as! Int
        name = aDecoder.decodeObjectForKey("name") as? String
        type = aDecoder.decodeObjectForKey("type") as? Int
        value = aDecoder.decodeObjectForKey("value") as? Float
        isActive = aDecoder.decodeObjectForKey("isActive") as? Bool
    }
    
    @objc func encodeWithCoder(aCoder: NSCoder) {
        
        aCoder.encodeObject(id, forKey: "id")
        aCoder.encodeObject(name, forKey: "name")
        aCoder.encodeObject(type, forKey: "type")
        aCoder.encodeObject(value, forKey: "value")
        aCoder.encodeObject(isActive, forKey: "isActive")
    }
    
    // MARK: Parse JSON
    class func taxFromJSON(json: [String: AnyObject]) -> DGTax {
        
        let tax = DGTax()
        
        tax.id = json["id"] as! Int
        tax.name = json["tax_name"] as? String
        tax.type = json["tax_type"] as? Int
        tax.value = json["tax_value"] as? Float
        tax.isActive = json["is_active"] as? Bool

        return tax
    }
    
    class func taxesFromJSON(json: [String: AnyObject]) -> [DGTax] {
        
        var taxes = [DGTax]()
        
        if let results = json["tax"] as? [AnyObject] {
            for result in results {
                let tax = DGTax.taxFromJSON(result as! [String : AnyObject])
                taxes.append(tax)
            }
        }
        
        return taxes
    }
}
