//
//  DGOrderItem.swift
//  DGRestaurant
//
//  Created by Hayward on 7/5/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGOrderItem {
    
    var id: Int!
    var orderId: Int!
    var foodId: Int!
    var foodName: String?
    var cost: Float?
    var quantity: Int?
    var size: String?
    var notes: String?
    var lastUpdate: NSTimeInterval?
    var status = DGFoodOrderStatus.Served
    var canceledNote: String?
    var rejectedNote: String?
    var returnNote: String?
    var tvStatus: Bool?
    var foodPhoto: DGPhoto?
    
    class func orderItemFromJSON(json: [String: AnyObject]) -> DGOrderItem {
        
        let orderItem = DGOrderItem()
        
        orderItem.id = json["id"] as! Int
        orderItem.orderId = json["order_id"] as! Int
        orderItem.foodId = json["food_id"] as! Int
        orderItem.foodName = json["food_name"] as? String
        orderItem.cost = json["cost"] as? Float
        orderItem.quantity = json["qty"] as? Int
        orderItem.size = json["size"] as? String
        orderItem.notes = json["notes"] as? String
        orderItem.lastUpdate = json["last_update"] as? NSTimeInterval
        
        if let status = json["status"] as? Int {
            orderItem.status = DGFoodOrderStatus(rawValue: status)!
        }

        orderItem.canceledNote = json["canceled_note"] as? String
        orderItem.rejectedNote = json["rejected_note"] as? String
        orderItem.returnNote = json["return_note"] as? String
        orderItem.tvStatus = json["tv_status"] as? Bool
        
        let photoJSON = [kPhotoNameKey: json["food_photo"],
                         kPhotoUrlKey: json["food_photo_url"],
                         kPhotoProcessedKey: false]
        orderItem.foodPhoto = DGPhoto.photoFromJSON(photoJSON as! [String: AnyObject])
        
        return orderItem
    }
    
    class func orderItemsFromJSON(json: [String: AnyObject]) -> [DGOrderItem] {
        
        var orderItems = [DGOrderItem]()
        
        if let results = json["order_items"] as? [AnyObject] {
            for result in results {
                let orderItem = DGOrderItem.orderItemFromJSON(result as! [String : AnyObject])
                orderItems.append(orderItem)
            }
        }
        
        return orderItems
    }
    
    class func orderItemFromXMPPJSON(json: [String: AnyObject]) -> DGOrderItem {
        
        let orderItem = DGOrderItem()
        
        orderItem.id = Int(json["id"] as! String)
        orderItem.orderId = Int(json["order_id"] as! String)
        orderItem.foodId = Int(json["food_id"] as! String)
        orderItem.foodName = json["food_name"] as? String
        orderItem.cost = Float((json["cost"] as? String)!)
        orderItem.quantity = Int((json["qty"] as? String)!)
        orderItem.size = json["size"] as? String
        orderItem.notes = json["notes"] as? String
        orderItem.lastUpdate = json["last_update"] as? NSTimeInterval
        
        if let status = Int((json["status"] as? String)!) {
            orderItem.status = DGFoodOrderStatus(rawValue: status)!
        }
        
        orderItem.canceledNote = json["canceled_note"] as? String
        orderItem.rejectedNote = json["rejected_note"] as? String
        orderItem.returnNote = json["return_note"] as? String
        orderItem.tvStatus = json["tv_status"] as? Bool
        
        let photoJSON = [kPhotoNameKey: json["food_photo"],
                         kPhotoUrlKey: json["food_photo_url"],
                         kPhotoProcessedKey: false]
        orderItem.foodPhoto = DGPhoto.photoFromJSON(photoJSON as! [String: AnyObject])
        
        return orderItem
    }
    

    
    class func orderItemsFromXMPPJSON(json: [String: AnyObject]) -> [DGOrderItem] {
        
        var orderItems = [DGOrderItem]()
        
        if let results = json["order_items"] as? [AnyObject] {
            for result in results {
                let orderItem = DGOrderItem.orderItemFromXMPPJSON(result as! [String : AnyObject])
                orderItems.append(orderItem)
            }
        }
        
        return orderItems
    }

    class func orderItemFromResultSet(rs: FMResultSet) -> DGOrderItem {
        
        let orderItem = DGOrderItem()
        
        orderItem.id = Int(rs.intForColumn("id"))
        orderItem.orderId = Int(rs.intForColumn("order_id"))
        orderItem.foodId = Int(rs.intForColumn("food_id"))
        orderItem.foodName = rs.stringForColumn("food_name")
        orderItem.cost = Float(rs.intForColumn("cost"))
        orderItem.quantity = Int(rs.intForColumn("qty"))
        orderItem.size = rs.stringForColumn("size")
        orderItem.notes = rs.stringForColumn("notes")
        orderItem.lastUpdate = Double(rs.doubleForColumn("last_update"))
        
        let status = Int(rs.intForColumn("status")) as Int
        orderItem.status = DGFoodOrderStatus(rawValue: status)!
        
        
        orderItem.canceledNote = rs.stringForColumn("canceled_note")
        orderItem.rejectedNote = rs.stringForColumn("rejected_note")
        orderItem.returnNote = rs.stringForColumn("return_note")
        orderItem.tvStatus = Bool(rs.boolForColumn("tv_status"))
        
        return orderItem
    }
    
    func isActiveOrderItem() -> Bool {
        switch status {
        case .New, .Accepted, .Ready, .Served:
            return true
        default:
            return false
        }
    }
    
    func orderStatusString() -> String {
        switch status {
        case .New:
            return "New"
        case .Accepted:
            return "Accepted"
        case .Ready:
            return "Ready"
        case .Served:
            return "Served"
        case .Canceled:
            return "Cancel"
        case .Rejected:
            return "Rejected"
        default:
            return "Returned"
        }
    }
}
