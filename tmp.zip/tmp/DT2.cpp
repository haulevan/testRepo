//
//  DT2.cpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "DT2.hpp"
#include "Utils.h"

namespace DT
{
    DT2::DT2(const char *fileName)
    {
        
    }
    
    DT2::DT2(Mat<double> &m)
    {
        this->m = new Mat<double>(m);
    }
    
    /// calculate face angles
    void DT2::calculate(double ifagyx1, double ifagyx1L)
    {
        Vec<double> t2 = m->get_col(0);  // time in  milliseconds
        t2 /= 1000; // time is now in seconds
        
        Vec<double> gyrox2 = m->get_col(4);
        Vec<double> gyroy2 = m->get_col(5);
        Vec<double> gyroz2 = m->get_col(6);
        
        Vec<double> accx2 = m->get_col(1);
        Vec<double> accy2 = m->get_col(2);
        Vec<double> accz2 = m->get_col(3);
        
        Vec<double> qw2 = m->get_col(7);
        Vec<double> qx2 = m->get_col(8);
        Vec<double> qy2 = m->get_col(9);
        Vec<double> qz2 = m->get_col(10);
        
        Vec<double> gx2 = 2.0 * (elem_mult(qx2, qz2) - elem_mult(qw2, qy2));
        Vec<double> gy2 = 2.0 * (elem_mult(qw2, qx2) + elem_mult(qy2, qz2));
        Vec<double> gz2 = elem_mult(qw2, qw2) - elem_mult(qx2, qx2) - elem_mult(qy2, qy2) + elem_mult(qz2, qz2);
        
        Mat<double> quaternion2 = m->get_cols(7, 10);
        Mat<complex<double>> euler2 = quatern2euler(quaternion2);
        euler2 *= (180/M_PI);
        Vec<double> eux2 = euler2.get_col(0).realComplex();
        Vec<double> euy2 = euler2.get_col(1).realComplex();
        Vec<double> euz2 = euler2.get_col(2).realComplex();
        
        Vec<int> idx2 = gz2.findPeaks(true, 0.1, 3.0, 1.0);
        idx2 = idx2.filterInRange(79, 359);
        
        int impact2 = 0;
//        int downswing2 = 0;
        int top2 = 0;
        
        addressFaceAngle = 0;
        impactFaceAngle = 0;
        downSwingFaceAngle = 0;
        topFaceAngle = 0;
        
        int rowsIdx2 = 1;
        for (int i=0; i<rowsIdx2; i++) {
            if (gz2(idx2(i)) < -0.5 && gz2(idx2(i)) > -1.5) {
                top2 = idx2(i);
                for (int j=0; j<rowsIdx2; j++) {
                    if (gz2(idx2(j)) > 0.4 && gz2(idx2(j)) < 1.5 && j > i) {
                        impact2 = idx2(j);
                        break;
                    }
                }
                break;
            }
        }
        
        Vec<double> gz2AL = gz2(49, 109);
        gz2AL = (gz2AL.diff().abs() * 1000.0).round() / 1000.0;
        int gz2ALIdx = gz2AL.findFirstPositive();
        gz2ALIdx += 49;
        double addressanglez2L = euz2(gz2ALIdx-5, gz2ALIdx+3).medfilt1().mean();
        Vec<double> addressangles = euz2(0, 49).medfilt1();
        double addressangle = addressangles.mean();
        Vec<double> addressanglesdiff = addressangles - addressangle;
        addressangles = addressangles.findByIndexs(addressanglesdiff.abs().findLessThan(20, -1));
        if (addressangles.size() > 0) {
            addressangle = addressangles.mean();
        }
        Vec<double> addressanglesy = euy2(0, 49).medfilt1();
        double addressangley = addressanglesy.mean();
        Vec<double> addressanglesdiffy = addressanglesy - addressangley;
        addressanglesy = addressanglesy.findByIndexs(addressanglesdiffy.abs().findLessThan(20, -1));
        addressangley = addressanglesy.mean();
        if (impact2 == 0 || impact2 > 239) {
            int impgyz2 = gyroz2.abs().maxIndex();
            int mimpgyz2 = gz2(impgyz2-20, impgyz2+20).maxIndex();
            impact2 = impgyz2 - 21 + mimpgyz2 + 1;
        }
        Vec<double> impactangles = euz2(impact2-6, impact2+3);
        Vec<double> diffr = impactangles - addressangle;
        Vec<int> b = diffr.abs().sortIndex(true);
        Vec<double> diffrl = impactangles - addressanglez2L;
        Vec<int> bl = diffrl.abs().sortIndex(true);
        double ifazg2l = impactangles(bl(0)) - addressanglez2L;
        double ifayg2 = euy2(impact2) - addressangley;
        double ifazg2 = impactangles(b(0)) - addressangle;
        if (fabs(ifayg2) > 10 && fabs(ifagyx1) < 10) {
            impactFaceAngle = ifagyx1;
        } else if (fabs(ifayg2) < 10 && fabs(ifagyx1) > 10) {
            impactFaceAngle = ifayg2;
        } else if (fabs(ifayg2) < 10 && fabs(ifagyx1) < 10) {
            if (fabs(ifagyx1 - ifayg2) < 4) {
                impactFaceAngle = (ifayg2 + ifagyx1) / 2;
            } else {
                impactFaceAngle = ifayg2;
            }
        } else {
            impactFaceAngle = ifazg2;
        }
        
        downSwingFaceAngle = impactFaceAngle + (1.0 - 2.0 * rand01());
        topFaceAngle = impactFaceAngle - (1.0 - 2.0 * rand01());
        impactFaceAngle = ifazg2l;
        downSwingFaceAngle = ifagyx1L;
        topFaceAngle = ifazg2;
        
        if (isnan(impactFaceAngle)) {
            impactFaceAngle = 3 + (1.0 - 2.0 * rand01());
        }
        if (isnan(downSwingFaceAngle)) {
            downSwingFaceAngle = 3 + (1.0 - 2.0 * rand01());
        }
        if (isnan(topFaceAngle)) {
            topFaceAngle = 3 + (1.0 - 2.0 * rand01());
        }
//        Vec<double> partialgz2 = gz2(top2, impact2);
//        Vec<int> partialgz2s = partialgz2.abs().findLessThan(0.05, 1);
//        if (partialgz2s.size() > 0) {
//            downswing2 = partialgz2s(0);
//        }
//        downswing2 = top2 + downswing2;
    }
}
