//
//  DGFood.swift
//  DGRestaurant
//
//  Created by Hayward on 6/18/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGFood: NSCopying {
    
    var id: Int!
    var name: String!
    var description: String?
    var commentCount: Int?
    var likedCount: Int?
    var rated: Int?
    var active: Bool?
    var featured: Bool?
    var promotioned: Bool?
    var categoryId: Int?
    var categoryName: String?
    var photo: DGPhoto?
    var prices: [DGPrice]?
    var isLiked: Bool?
    var isFavorited: Bool?
    var type: Int?
    
    required init() {}
    
    @objc func copyWithZone(zone: NSZone = nil) -> AnyObject {
        let food = self.dynamicType.init()
        food.id = self.id
        food.name = self.name
        food.description = self.description
        food.commentCount = self.commentCount
        food.likedCount = self.likedCount
        food.rated = self.rated
        food.categoryId = self.categoryId
        food.categoryName = self.categoryName
        food.photo = self.photo
        return food
    }
    
    class func foodFromJSON(json: [String: AnyObject]) -> DGFood {
        
        let food = DGFood()
        food.id = json["food_id"] as! Int
        food.name = json["food_name"] is NSNull ? "" : json["food_name"] as! String
        food.description = json["food_description"] as? String
        food.commentCount = json["comment_count"] as? Int
        food.likedCount = json["liked"] as? Int
        food.rated = json["rated"] as? Int
        food.categoryId = json["food_category"] as? Int
        food.categoryName = json["food_category_name"] as? String
        
        let photoJSON = [kPhotoNameKey: json["food_photo"],
                         kPhotoUrlKey: json["food_photo_url"],
                         kPhotoProcessedKey: json["photo_proccessed"]]
        food.photo = DGPhoto.photoFromJSON(photoJSON as! [String: AnyObject])
        
        food.prices = []
        
        return food
    }
    
    class func foodsBehalfOfCategoryFromJSON(json: [String: AnyObject]) -> [DGFood] {
        
        var foods = [DGFood]()
        
        if let results = json["foods"] as? [AnyObject] {
            for result in results {
                let food = DGFood.foodFromJSON(result as! [String : AnyObject])
                foods.append(food)
            }
        }
        
        if let results = json["prices"] as? [AnyObject] {
            for result in results {
                let price = DGPrice.priceFromJSON(result as! [String : AnyObject])
                let filterFoods = foods.filter {
                    $0.id == price.foodId
                }
                if filterFoods[0].prices?.count == 0 {
                    filterFoods[0].prices?.append(price)
                }
                filterFoods[0].prices?.sortInPlace({ $0.value < $1.value })
            }
        }
        
        return foods
    }

    class func foodsFromJSON(json: [String: AnyObject]) -> [DGFood] {
        
        var foods = [DGFood]()
        
        if let results = json["foods"] as? [AnyObject] {
            for result in results {
                let food = DGFood.foodFromJSON(result as! [String : AnyObject])
                foods.append(food)
            }
        }
        
        if let results = json["prices"] as? [AnyObject] {
            for result in results {
                let price = DGPrice.priceFromJSON(result as! [String : AnyObject])
                let filterFoods = foods.filter {
                    $0.id == price.foodId
                }
                filterFoods[0].prices?.append(price)
                filterFoods[0].prices?.sortInPlace({ $0.value < $1.value })
            }
        }
        
        return foods
    }
    
    class func foodsFromSyncDataJSON(json: [String: AnyObject]) -> [DGFood] {
        
        var foods = [DGFood]()
        
        if let results = json["foods"] as? [AnyObject] {
            for result in results {
                let food = DGFood.foodFromJSON(result as! [String : AnyObject])
                
                if let priceJSONs = result["price"] as? [AnyObject] {
                    for priceJSON in priceJSONs {
                        let price = DGPrice.priceFromJSON(priceJSON as! [String : AnyObject])
                        food.prices?.append(price)
                        food.prices?.sortInPlace({ $0.value < $1.value })
                    }
                }
                
                foods.append(food)
            }
        }
        
        return foods
    }
    
    class func foodDetailFromJSON(json: [String: AnyObject]) -> DGFood {
        
        var food = DGFood()
        
        if let foodJSON = json["0"] as? [String : AnyObject] {
            food = DGFood.foodFromJSON(foodJSON)
            if let results = json["prices"] as? [AnyObject] {
                for result in results {
                    let price = DGPrice.priceFromJSON(result as! [String : AnyObject])
                    food.prices?.append(price)
                }
                food.prices?.sortInPlace({ $0.value < $1.value })
            }
        }
        
        return food
    }
    
    class func foodFromResultSet(rs: FMResultSet) -> DGFood {
        
        let food = DGFood()
        
        food.id = Int(rs.intForColumn("food_id"))
        food.name = rs.stringForColumn("food_name")
        food.description = rs.stringForColumn("food_description")
        food.commentCount = Int(rs.intForColumn("comment_count"))
        food.likedCount = Int(rs.intForColumn("liked"))
        food.rated = Int(rs.intForColumn("rated"))
        food.categoryId = Int(rs.intForColumn("food_category"))
        food.categoryName = rs.stringForColumn("food_category_name")
        food.isLiked = rs.boolForColumn("isLiked")
        food.isFavorited = rs.boolForColumn("isFavorited")
        food.type = Int(rs.intForColumn("type"))
        
        if let photoName = rs.stringForColumn("photo_name") {
            
            let photoUrlIndex = Int(rs.intForColumn("photo_url_index"))
            let isProccessed = rs.boolForColumn("photo_proccessed")
            let photoJSON = [kPhotoNameKey: photoName,
                             kPhotoUrlKey: photoUrlIndex,
                             kPhotoProcessedKey: isProccessed]
            food.photo = DGPhoto.photoFromJSON(photoJSON as! [String: AnyObject])
        }
        
        return food
    }
    
    func priceBySize(size: String) -> DGPrice? {
        let prices = self.prices?.filter { $0.size == size }
        return prices != nil && prices!.count > 0 ? prices![0] : nil
    }
    
    static func foodPricesFromFoods(foods: [DGFood]) -> [DGFood] {
        var foodPrices = [DGFood]()
        foods.forEach() { food in
            if let prices = food.prices {
                prices.forEach() { price in
                    let foodPrice = food.copyWithZone() as! DGFood
                    foodPrice.prices = [price]
                    foodPrices.append(foodPrice)
                }
            }
        }
        return foodPrices
    }
}
