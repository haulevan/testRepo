//
//  TestClass.mm
//  TestLib
//
//  Created by HauLe on 11/29/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#define kDTAPISwingKeyGolfSwings @"golf_swings"
#define kDTAPISwingKeyGolfSwing @"golf_swing"
#define kDTAPISwingKeySwing @"swing"
#define kDTAPISwingKeySwingNumber @"swing_number"
#define kDTAPISwingKeyAddress @"address"
#define kDTAPISwingKeyImpact @"impact"
#define kDTAPISwingKeyDownswing @"downswing"
#define kDTAPISwingKeyTop @"top"
#define kDTAPISwingKeyClub @"club"
#define kDTAPISwingKeyHip @"hip"
#define kDTAPISwingKeyScore @"score"

#import "TestClass.h"
#import "CalcEngine.hpp"
#import "Converter.hpp"

using namespace DT;

@interface TestClass ()
{
    CalcEngine *calcEngine;
    Converter *converter;
}

@end

@implementation TestClass

- (instancetype)init
{
    self = [super init];
    if (self) {
        
//        Mat<double> m1 = Mat<double>(280, 11);
//        Mat<double> m2 = Mat<double>(280, 11);
//        Mat<double> m3 = Mat<double>(280, 11);
//        Mat<double> m4 = Mat<double>(280, 11);
//        for (int i=0; i<280; i++) {
//            for (int j=0; j<11; j++) {
//                m1(i,j) = std::rand() % 100;
//                m2(i,j) = std::rand() % 100;
//                m3(i,j) = std::rand() % 100;
//                m4(i,j) = std::rand() % 100;
//            }
//        }
        
        converter = new Converter();
        NSString *path = [[NSBundle mainBundle] pathForResource:@"DT1" ofType: @"dat"];
        NSData *data = [[NSData alloc] initWithContentsOfFile:path];
        uint64_t length = [data length];
        uint8_t bytes1[length];
        [data getBytes:&bytes1 length:length];
//        Mat<double> m1 = converter->convert(0, path.UTF8String);
        Mat<double> m1 = converter->convert(bytes1, length);
//        NSLog(@"m1:");
//        print(m1);
        
        path = [[NSBundle mainBundle] pathForResource:@"DT2" ofType: @"dat"];
        data = [[NSData alloc] initWithContentsOfFile:path];
        length = [data length];
        uint8_t bytes2[length];
        [data getBytes:&bytes2 length:length];
//        Mat<double> m2 = converter->convert(0, path.UTF8String);
        Mat<double> m2 = converter->convert(bytes2, length);
//        NSLog(@"m2:");
//        print(m2);
        
        path = [[NSBundle mainBundle] pathForResource:@"DT3" ofType: @"dat"];
        data = [[NSData alloc] initWithContentsOfFile:path];
        length = [data length];
        uint8_t bytes3[length];
        [data getBytes:&bytes3 length:length];
//        Mat<double> m3 = converter->convert(0, path.UTF8String);
        Mat<double> m3 = converter->convert(bytes3, length);
//        NSLog(@"m3:");
//        print(m3);
        
        path = [[NSBundle mainBundle] pathForResource:@"DT4" ofType: @"dat"];
        data = [[NSData alloc] initWithContentsOfFile:path];
        length = [data length];
        uint8_t bytes4[length];
        [data getBytes:&bytes4 length:length];
//        Mat<double> m4 = converter->convert(0, path.UTF8String);
        Mat<double> m4 = converter->convert(bytes4, length);
//        NSLog(@"m4:");
//        print(m4);
        
        calcEngine = new CalcEngine(m1, m2, m3, m4);
    }
    return self;
}

- (void)run
{
    calcEngine->calculate();
    NSDictionary *swingJSON = @{
                                kDTAPISwingKeyAddress    : @{kDTAPISwingKeyClub: @(calcEngine->addressFaceAngle),
                                                             kDTAPISwingKeyHip: @0},
                                kDTAPISwingKeyImpact     : @{kDTAPISwingKeyClub: @(calcEngine->impactFaceAngle),
                                                             kDTAPISwingKeyHip: @(calcEngine->hipDown)},
                                kDTAPISwingKeyDownswing  : @{kDTAPISwingKeyClub: @(calcEngine->downSwingFaceAngle),
                                                             kDTAPISwingKeyHip: @(calcEngine->hipSide)},
                                kDTAPISwingKeyTop        : @{kDTAPISwingKeyClub: @(calcEngine->topFaceAngle),
                                                             kDTAPISwingKeyHip: @(calcEngine->hipForward)}
                                };
    NSLog(@"%@", swingJSON);
}

@end
