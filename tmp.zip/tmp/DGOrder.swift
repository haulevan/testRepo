//
//  DGOrder.swift
//  DGRestaurant
//
//  Created by Hayward on 6/21/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGOrder {
    
    var id: Int!
    var tableId: Int?
    var amount: Int?
    var totalAmount: Int?
    var serviceAmount: Float?
    var taxAmount: Float?
    var time: NSTimeInterval?
    var status: Bool?
    var notes: String?
    var items: [DGOrderItem]?
    var services: [DGOrderService]?
    var taxes: [DGOrderTax]?
    
    class func orderFromJSON(json: [String: AnyObject]) -> DGOrder {
        
        let order = DGOrder()
        
        order.id = json["order_id"] as! Int
        order.tableId = json["table"] as? Int
        order.amount = json["amount"] as? Int
        order.totalAmount = json["total_amount"] as? Int
        order.serviceAmount = json["service_amount"] as? Float
        order.taxAmount = json["tax_amount"] as? Float
        order.time = json["time"] as? NSTimeInterval
        order.status = json["status"] as? Bool
        order.notes = json["notes"] as? String
        order.items = DGOrderItem.orderItemsFromJSON(json)
        order.services = DGOrderService .orderServicesFromJSON(json)
        order.taxes = DGOrderTax.orderTaxesFromJSON(json)
        
        return order
    }
    
    class func ordersFromJSON(json: [String: AnyObject]) -> [DGOrder] {
        
        var orders = [DGOrder]()
        
        if let results = json["data"] as? [AnyObject] {
            for result in results {
                let order = DGOrder.orderFromJSON(result as! [String : AnyObject])
                orders.append(order)
            }
        }
        
        return orders
    }

    class func orderFromXMPPJSON(json: [String: AnyObject]) -> DGOrder {
        
        let order = DGOrder()
        
        order.id = Int(json["order_id"] as! String)
        order.tableId = Int((json["table"] as? String)!)
        order.amount = Int((json["amount"] as? String)!)
        order.totalAmount = Int((json["total_amount"] as? String)!)
        order.serviceAmount = Float((json["service_amount"] as? String)!)
        order.taxAmount = Float((json["tax_amount"] as? String)!)
        order.time = NSTimeInterval((json["time"] as? String)!)
        order.notes = json["notes"] as? String

        if let str = json["status"] as? String {
            order.status = NSString(string: str).boolValue
        }

        order.items = DGOrderItem.orderItemsFromXMPPJSON(json)
        order.services = DGOrderService.orderServicesFromXMPPJSON(json)
        order.taxes = DGOrderTax.orderTaxesFromXMPPJSON(json)
        
        return order
    }

    class func orderFromResultSet(rs: FMResultSet) -> DGOrder {
        
        let order = DGOrder()
        
        order.id = Int(rs.intForColumn("order_id"))
        order.tableId = Int(rs.intForColumn("table_id"))
        order.amount = Int(rs.intForColumn("amount"))
        order.totalAmount = Int(rs.intForColumn("total_amount"))
        order.serviceAmount = Float(rs.intForColumn("service_amount"))
        order.taxAmount = Float(rs.intForColumn("tax_amount"))
        order.time = Double(rs.doubleForColumn("time"))
        order.status = Bool(rs.boolForColumn("status"))
        order.notes = rs.stringForColumn("notes")
        
        return order
    }
    
    class func activeOrder(order: DGOrder!) -> DGOrder! {
        order.items = order.activeOrderItems()
        return order
    }
    
    func removeOrderItemsByFoodId(foodId:Int) {
        self.items = self.items?.filter { $0.foodId != foodId }
    }
    
    func removeOrderItemByFoodId(foodId: Int, size: String) {
         self.items = self.items?.filter { $0.foodId != foodId || $0.size != size }
    }
    
    func removeOrderItemById(orderItemId: Int) {
        self.items = self.items?.filter { $0.id != orderItemId }
    }
    
    func orderItemsByFoodId(foodId: Int) -> [DGOrderItem]? {
        return self.items?.filter { $0.foodId == foodId}
    }
    
    func orderItemByFoodId(foodId: Int, size: String) -> DGOrderItem? {
        let orderItems = self.orderItemsByFoodId(foodId)?.filter { $0.size == size }
        return orderItems?.count > 0 ? orderItems![0] : nil
    }
    
    func activeOrderItems() -> [DGOrderItem]? {
        return self.items?.filter { $0.status != .Rejected && $0.status != .Canceled && $0.status != .Returned }
    }
    
    func inactiveOrderItems() -> [DGOrderItem]? {
        return self.items?.filter {
            let cond = $0.status == .Rejected || $0.status == .Canceled
            return cond || $0.status == .Returned
        }
    }
    
    func totalNoTax() -> Float {
        var total: Float = 0.0
        self.items?.forEach { item in
            total += Float(item.quantity!) * item.cost!
        }
        return total
    }
    
    func totalServiceFee() -> Float {
        var totalServiceFee: Float = 0.0
        let totalNoTax = self.totalNoTax()
        DGDataManager.sharedInstance.settings.services?.filter {
            $0.type == 0
            }.forEach { service in
                if let _ = service.value {
                    totalServiceFee += service.value!
                }
        }
        DGDataManager.sharedInstance.settings.services?.filter {
            $0.type == 1
            }.forEach { service in
                if let _ = service.value {
                    totalServiceFee += (service.value! * Float(totalNoTax)) / 100.0
                }

        }
        return totalServiceFee
    }
    
    func taxServiceFee() -> Float {
        var taxServiceFee: Float = 0.0
        let totalNoTax = self.totalNoTax()
        DGDataManager.sharedInstance.settings.services?.filter {
            $0.type == 0 && $0.isTaxed == true
            }.forEach { service in
                if let _ = service.value {
                    taxServiceFee += service.value!
                }
        }
        DGDataManager.sharedInstance.settings.services?.filter {
            $0.type == 1 && $0.isTaxed == true
            }.forEach { service in
                if let _ = service.value {
                    taxServiceFee += (service.value! * Float(totalNoTax)) / 100.0
                }
        }
        return taxServiceFee
    }
    
    func totalTax() -> Float {
        var totalTax: Float = 0.0
        let totalHaveTax = self.totalNoTax() + self.taxServiceFee()
        DGDataManager.sharedInstance.settings.taxes?.forEach { tax in
            if tax.type == 0 {
                if let _ = tax.value {
                    totalTax += tax.value!
                }
            } else if tax.value > 0 {
                totalTax += (totalHaveTax * tax.value!) / 100.0
            }
        }
        return totalTax
    }
    
    func orderFoods() -> [DGFood] {
        var foods: [DGFood] = []
        items?.forEach { (item) in
            let filterFoods = foods.filter { $0.id == item.foodId }
            if filterFoods.count == 0 {
                let food = DGFood()
                food.id = item.foodId
                food.name = item.foodName
                food.photo = item.foodPhoto
                foods.append(food)
            }
        }
        return foods
    }
    
    func foodsJSONData() -> [[String: AnyObject]] {
        var foods = [[String: AnyObject]]()
        items?.forEach { (item) in
            foods.append(["food_id": item.foodId, "food_name": item.foodName!, "size": item.size!, "quantity": item.quantity!, "notes": item.notes!])
        }
        return foods
    }
}
