//
//  DGPhoto.swift
//  DGRestaurant
//
//  Created by Hayward on 6/18/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGPhoto {
    
    var url: String?
    var url_50x50: String?
    var url_100x100: String?
    var url_200x200: String?
    var url_400x400: String?
    var url_640x640: String?
    var url_800x800: String?
    
    var name: String?
    var urlIndex: Int?
    var isProccessed: Bool?
    
    class func photoFromJSON(json: [String: AnyObject]) -> DGPhoto {
        
        let photo = DGPhoto()
        photo.name = json[kPhotoNameKey] as? String
        photo.urlIndex = json[kPhotoUrlKey] as? Int
        photo.isProccessed = json[kPhotoProcessedKey] as? Bool
        
        if let name = photo.name,
            let urlIndex = photo.urlIndex {
            
            var photoUrl = ""
            for key in DGDataManager.sharedInstance.config.photoUrls.keys {
                if Int(key) == urlIndex {
                    photoUrl = DGDataManager.sharedInstance.config.photoUrls[key]! 
                    break
                }
            }
            
            photo.url = "\(photoUrl)" + name
            
            if photo.isProccessed == true {
                let components = name.componentsSeparatedByString(".")
                photo.url_50x50 = "\(photoUrl)" + components[0] + "_50x50.\(components[1])"
                photo.url_100x100 = "\(photoUrl)" + components[0] + "_100x100.\(components[1])"
                photo.url_200x200 = "\(photoUrl)" + components[0] + "_200x200.\(components[1])"
                photo.url_400x400 = "\(photoUrl)" + components[0] + "_400x400.\(components[1])"
                photo.url_640x640 = "\(photoUrl)" + components[0] + "_640x640.\(components[1])"
                photo.url_800x800 = "\(photoUrl)" + components[0] + "_800x800.\(components[1])"
            }
        }
        
        return photo
    }
}
