//
//  DGDataManager.swift
//  DGRestaurant
//
//  Created by Hayward on 6/15/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation
import Alamofire

class DGDataManager {
    
    // MARK: - Singleton
    static let sharedInstance = DGDataManager()
    
    // MARK: - Properties
    var config: DGConfig!
    var settings: DGSettings!
    var tokenID: String!
    var user: DGUser!
    
    var tables = [DGTable]()
    var activeOrder = [DGOrder]()
    var categories = [DGFood]()

    var currentTable: DGTable?

    var homeFood: [String: AnyObject] = [:]
    var appkey = "APP-KEY-002"
    
    /*
    APP-KEY-000 http://113.160.225.76:8894/mRestaurantAPI/
    
    APP-KEY-001 http://apis.order-com.com/
    
    APP-KEY-002 http://apis.mcafeteria.com/
    */

    // TODO: Fix later
    var isOfflineMode: Bool = false
    
    let manager: Alamofire.Manager = {
        let serverTrustPolicies: [String: ServerTrustPolicy] = [
            "apis.mcafeteria.com": .DisableEvaluation
        ]
        
        let configuration = NSURLSessionConfiguration.defaultSessionConfiguration()
        configuration.HTTPAdditionalHeaders = Alamofire.Manager.defaultHTTPHeaders
        
        return Alamofire.Manager(
            configuration: configuration,
            serverTrustPolicyManager: ServerTrustPolicyManager(policies: serverTrustPolicies)
        )
    }()

    var allowCheckout: Bool {
        
        let checkoutPermission = DGDataManager.sharedInstance.settings.allowStaffCheckout;
        let userRole = DGDataManager.sharedInstance.user.userType
        
        if userRole == DGUserType.Staff && checkoutPermission == false {
            return false
        }
        
        return true
    }
    
    var selectedRestaurant: DGRestaurant? {
        
        didSet {
            
            if oldValue?.id != selectedRestaurant?.id {
                
                // Delete all restaurants
                DGDatabaseManager.sharedInstance.deleteAllRestaurants()
                
                // Add new restaurant on local database
                DGDatabaseManager.sharedInstance.createRestaurant(selectedRestaurant!)
            }
        }
    }
    
    var currentOrder: DGOrder?

    func errorFromJSON(json: [String: AnyObject]) -> NSError {
        
        var userInfo: [String: AnyObject]?
        
        if let _ = json["non_field_errors"] {
            userInfo = [NSLocalizedDescriptionKey:  json["non_field_errors"]![0]]
        }
        else if let _ = json["message"] {
            userInfo = [NSLocalizedDescriptionKey:  json["message"]!]
        }
        
        let error = NSError(domain: "DGHttpResponseErrorDomain", code: 401, userInfo: userInfo)
        return error
    }
    
    func loadConfig() -> Void {
        if let config = DGConfig.getCache() {
            self.config = config
        }
        else {
            self.getConfig(appKey: self.appkey, countryCode: 1) { (result, error) in
            }
        }
    }
    
    func loadSettings() -> Void {
        if let settings = DGSettings.getCache() {
            self.settings = settings
        }
        else {
            self.getSettingRestaurant(restaurantId: self.user!.restaurantId, completion: { (result, error) in
            })
        }
    }
    
    func addFoodsToLocalDatabase(foods: [DGFood], type: Int) -> Void {
        for food in foods {
            food.type = 1 << type
            DGDatabaseManager.sharedInstance.createFood(food)
            if let prices = food.prices {
                for price in prices {
                    DGDatabaseManager.sharedInstance.createPrice(price)
                }
            }
        }
    }
    
    func addOrdersToLocalDatabase(orders: [DGOrder]) -> Void {
        for order in orders {
            DGDatabaseManager.sharedInstance.createOrder(order)
            if let items = order.items {
                for item in items {
                    DGDatabaseManager.sharedInstance.createOrderItem(item)
                }
            }
            if let services = order.services {
                for service in services {
                    DGDatabaseManager.sharedInstance.createOrderService(service)
                }
            }
            if let taxes = order.taxes {
                for tax in taxes {
                    DGDatabaseManager.sharedInstance.createOrderTax(tax)
                }
            }
        }
    }
    
    // MARK: - Configuration API
    func getConfig(appKey appKey: String, countryCode: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        self.appkey = appKey
        
        manager.request(DGRouter.Config(appKey, countryCode)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error getConfig: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let config = DGConfig.configFromJSON(data)
            self.config = config
            
            // Cache data
            config.cache()
            
            completion(result: config, error: nil)
        }
    }
    
    // MARK: - synchronize data API
    func synchronizeData(completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        let ud = NSUserDefaults.standardUserDefaults()
        let version = 0//ud.objectForKey(kDGVersionSyncData) ?? 0
        
        manager.request(DGRouter.SyncData(user.restaurantId, version)).responseJSON { (response) -> Void in
            print(response)
            guard response.result.isSuccess else {
                print("Error register: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                newVersion = json["version"] as? Int else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            if newVersion == -1 {
                completion(result: nil, error: nil)
                return
            }
            
            let data = json["data"] as! [String: AnyObject]
            let menuJSON = data["menu"] as! [[String: AnyObject]]
            let photosJSON = data["photos"] as! [[String: AnyObject]]
            //            let foods = DGFood.foodsFromJSON(foodsJSON)
            
            menuJSON.forEach { menu in
                let category = DGCategory.categoryFromJSON(menu)
                let foods = DGFood.foodsFromSyncDataJSON(menu)
            }
            
            // Cache data
            let ud = NSUserDefaults.standardUserDefaults()
            ud.setObject(newVersion, forKey: kDGVersionSyncData)
            ud.synchronize()
            
            completion(result: data, error: nil)
            
        }
    }
    
    // MARK: - Authentication API
    func register(email email: String, password: String, firstName: String, lastName: String, appKey: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.Register(email, password, firstName, lastName, appKey)).responseJSON { (response) -> Void in
            print(response)
            guard response.result.isSuccess else {
                print("Error register: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                datas = json["data"] as? [AnyObject],
                data = datas[0] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let user = DGUser.userFromJSON(data)
            self.user = user
            
            // Cache data
            let ud = NSUserDefaults.standardUserDefaults()
            ud.setObject(email, forKey: kDGUserEmail)
            ud.setObject(password, forKey: kDGUserPassword)
            ud.synchronize()
            
            // Create user on local database
            DGDatabaseManager.sharedInstance.createUser(user)
            
            completion(result: user, error: nil)
        }
    }
    
    func login(email email: String, password: String, appKey: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.Login(email, password, appKey)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error login: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                tokenID = json["tokenID"] as? String,
                datas = json["data"] as? [AnyObject],
                userJSON = datas[0] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            print(response)

            // Update token
            self.tokenID = tokenID
            
            // Update user
            let user = DGUser.userFromJSON(userJSON)
            self.user = user
            
            // Cache data
            let ud = NSUserDefaults.standardUserDefaults()
            ud.setObject(email, forKey: kDGUserEmail)
            ud.setObject(password, forKey: kDGUserPassword)
            
            if let xmppPassword = self.user.messageKey {
                ud.setObject(xmppPassword, forKey: kDGXMPPPassword)
            }

            ud.synchronize()
            
            // Create user if not exist on local database
            if DGDatabaseManager.sharedInstance.userByID(user.id) == nil {
                DGDatabaseManager.sharedInstance.createUser(user)
            }
            
            // Load settings data
            self.loadSettings()
            
            completion(result: user, error: nil)
        }
    }
    
    
    func changePassword(currentPassword: String, newPassword: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.ChangePassword(currentPassword, newPassword)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error change password: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                
                result = json["result"] as? Int,
                message = json["message"] as? String else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            print(response)
            
            if result != 0{
                // Show the error.
                let userInfo = [NSLocalizedDescriptionKey:  message] as [String: AnyObject]!
                let error = NSError(domain: "DGHttpResponseErrorDomain", code: 401, userInfo: userInfo)
                completion(result: nil, error: error)
            }
            else {
                
                // Cache data
                let ud = NSUserDefaults.standardUserDefaults()
                ud.setObject(newPassword, forKey: kDGUserPassword)
                ud.synchronize()
                
                completion(result: message, error: nil)
            }
        }
    }

    
    // MARK: - Search Restaurants API
    func searchRestaurants(query query: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.Restaurants(query)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error searchRestaurants: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            // Get restaurants list
            let restaurants = DGRestaurant.restaurantsFromJSON(json)
            completion(result: restaurants, error: nil)
        }
    }
    
    func searchRestaurantsIndexes(query query: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.RestaurantsIndexes(query)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error searchRestaurantsIndexes: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                data = json["data"] as? [String] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            // Return search result list
            completion(result: data, error: nil)
        }
    }
    
    // MARK: - Restaurant Wifi API
    func getRestaurantsWifi(wifiName wifiName: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.RestaurantWifi(wifiName)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error getRestaurantsWifi: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            // Get restaurants list
            let restaurants = DGRestaurant.restaurantsFromJSON(json)
            
            completion(result: restaurants, error: nil)
        }
    }
    
    // MARK: - Tables API
    func getTables(restaurantId restaurantId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.Tables(restaurantId)).responseJSON { (response) -> Void in
//            print(response)
            guard response.result.isSuccess else {
                print("Error getTables: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            // Get table list
            var tables = DGTable.tablesFromJSON(json)
            
            tables.sortInPlace({ (table1: DGTable, table2: DGTable) -> Bool in
                return Int(table1.name) < Int(table2.name)
            })
            
            // Save the table list in data manager.
            self.tables = tables
            
            for table in tables {
                DGDatabaseManager.sharedInstance.createTable(table)
            }
            
            completion(result: tables, error: nil)
        }
    }
    
    // MARK: - Categories API
    func getCategories(restaurantId restaurantId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.Categories(restaurantId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error getCategories: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            // Get category list
            let categories = DGCategory.categoriesFromJSON(json)
            for category in categories {
                DGDatabaseManager.sharedInstance.createCategory(category)
            }
            
            completion(result: categories, error: nil)
        }
    }
    
    func getCategoriesHome(restaurantId restaurantId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.CategoriesHome(restaurantId)).responseJSON { (response) -> Void in
            print(response)
            guard response.result.isSuccess else {
                print("Error getCategories: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            // Get food list
            let foods = DGFood.foodsBehalfOfCategoryFromJSON(data)
            self.categories = foods
            self.addFoodsToLocalDatabase(foods, type: DGFoodOptionType.Category.rawValue)
            
            completion(result: foods, error: nil)
        }
    }
    
    // MARK: - Foods API
    func getFoods(restaurantId restaurantId: Int, option: DGFoodOptionType, categoryId: Int, page: Int, completion:(result: AnyObject?, pageNumber: Int?,error: NSError?) -> Void) {
        
        if self.isOfflineMode {
            
            if option == .Home {
                
                let categoryValue = DGFoodOptionType.Category.rawValue
                
                let featuredFoods = DGDatabaseManager.sharedInstance.foodsByType(categoryValue + 1)
                self.homeFood[DGHomeOptionType.Featured.rawValue] = featuredFoods
                let newFoods = DGDatabaseManager.sharedInstance.foodsByType(categoryValue + 2)
                self.homeFood[DGHomeOptionType.New.rawValue] = newFoods
                let promotionFoods = DGDatabaseManager.sharedInstance.foodsByType(categoryValue + 3)
                self.homeFood[DGHomeOptionType.Promotion.rawValue] = promotionFoods
                let topRatedFoods = DGDatabaseManager.sharedInstance.foodsByType(categoryValue + 4)
                self.homeFood[DGHomeOptionType.TopRated.rawValue] = topRatedFoods
                
                // TODO: change the page total numbers here
                completion(result: self.homeFood, pageNumber: 1, error: nil)
            }
            else {
                if (option == .Category) {
                    let foods = DGDatabaseManager.sharedInstance.foodsByCategoryId(categoryId)
                    // TODO: change the page total numbers here

                    completion(result: foods, pageNumber: 1, error: nil)
                }
                else {
                    let foods = DGDatabaseManager.sharedInstance.foodsByType(option.rawValue)
                    // TODO: change the page total numbers here
                    completion(result: foods, pageNumber: 1, error: nil)
                }
            }
        }
        else {
            var optionString = ""
            switch option {
            case .Home:
                optionString = "home"
            case .Rated:
                optionString = "rated"
            case .Feature:
                optionString = "feature"
            case .Promotion:
                optionString = "promotion"
            case .Category:
                optionString = "\(categoryId)"
            }
            
            manager.request(DGRouter.Foods(restaurantId, optionString, page)).responseJSON { (response) -> Void in
                
                guard response.result.isSuccess else {
                    print("Error getFoods: \(response.result.error)")
                    completion(result: nil, pageNumber: 0,error: response.result.error)
                    return
                }
                
                guard let json = response.result.value as? [String: AnyObject],
                    let data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, pageNumber: 0, error: error)
                    return
                }
                
                print("response: \(response)")

                if option == .Home {
                    
                    let categoryValue = DGFoodOptionType.Category.rawValue
                    
                    if let featuredFoodJSON = data["featured"] as? [String: AnyObject] {
                        let featuredFoods = DGFood.foodsFromJSON(featuredFoodJSON)
                        self.homeFood[DGHomeOptionType.Featured.rawValue] = featuredFoods
                        self.addFoodsToLocalDatabase(featuredFoods, type:categoryValue + 1)
                    }
                    if let newFoodsJSON = data["new_foods"] as? [String: AnyObject] {
                        let newFoods = DGFood.foodsFromJSON(newFoodsJSON)
                        self.homeFood[DGHomeOptionType.New.rawValue] = newFoods
                        self.addFoodsToLocalDatabase(newFoods, type:categoryValue + 2)
                    }
                    if let promotionFoodsJSON = data["promotion"] as? [String: AnyObject] {
                        let promotionFoods = DGFood.foodsFromJSON(promotionFoodsJSON)
                        self.homeFood[DGHomeOptionType.Promotion.rawValue] = promotionFoods
                        self.addFoodsToLocalDatabase(promotionFoods, type:categoryValue + 3)
                    }
                    if let topRatedFoodsJSON = data["top_rated"] as? [String: AnyObject] {
                        let topRatedFoods = DGFood.foodsFromJSON(topRatedFoodsJSON)
                        self.homeFood[DGHomeOptionType.TopRated.rawValue] = topRatedFoods
                        self.addFoodsToLocalDatabase(topRatedFoods, type:categoryValue + 4)
                    }
                    
                    completion(result: self.homeFood, pageNumber: 1,error: nil)
                }
                else {
                    var foodsJSON : [String: AnyObject]?
                    
                    switch option {
                    case .Feature:
                        foodsJSON = data["featured"] as? [String: AnyObject]
                    case .Promotion:
                        foodsJSON = data["promotion"] as? [String: AnyObject]
                    case .Rated:
                        foodsJSON = data["top_rated"] as? [String: AnyObject]
                    default: // Category
                        foodsJSON = data["food_items"] as? [String: AnyObject]
                    }
                    
                    let foods = DGFood.foodsFromJSON(foodsJSON!)
                    
                    var pageNumber: Int = 0
                    if let _ = foodsJSON!["num_of_page"] {
                        pageNumber = foodsJSON!["num_of_page"] as! Int
                    }
                    
                    if categoryId > 0 {
                        for food in foods {
                            food.categoryId = categoryId
                        }
                    }
                    self.addFoodsToLocalDatabase(foods, type: option.rawValue)
                    
                    completion(result: foods, pageNumber: pageNumber, error: nil)
                }            
            }
        }
    }
    
    func getFoodDetail(foodId foodId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.FoodDetail(foodId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error getFoodDetail: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let food = DGFood.foodDetailFromJSON(data)
            DGDatabaseManager.sharedInstance.updateFood(food)
            
            completion(result: food, error: nil)
        }
    }
    
    func searchFoods(query query: String, restaurantId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.SearchFoods(query, restaurantId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error searchFoods: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            // Get food list
            let foods = DGFood.foodsFromJSON(data)
            completion(result: foods, error: nil)
        }
    }
    
    // MARK: - Like Food API
    func likeFood(foodId foodId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.LikeFood(foodId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error likeFood: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            DGDatabaseManager.sharedInstance.updateLikedFoodById(foodId, isLiked: true)
            completion(result: json, error: nil)
        }
    }
    
    func unlikeFood(foodId foodId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.UnlikeFood(foodId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error unlikeFood: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            DGDatabaseManager.sharedInstance.updateLikedFoodById(foodId, isLiked: false)
            completion(result: json, error: nil)
        }
    }
    
    // MARK: - Favorite Food API
    func favoriteFood(foodId foodId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.FavoriteFood(foodId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error favoriteFood: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            DGDatabaseManager.sharedInstance.updateFavoritedFoodById(foodId, isFavorited: true)
            completion(result: json, error: nil)
        }
    }
    
    func unfavoriteFood(foodId foodId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.UnfavoriteFood(foodId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error unfavoriteFood: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            DGDatabaseManager.sharedInstance.updateFavoritedFoodById(foodId, isFavorited: false)
            completion(result: json, error: nil)
        }
    }
    
    func getFavoritedFoods(page page: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.FavoritedFoods(page)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error getFavoritedFoods: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let foods = DGFood.foodsFromJSON(data)
            self.addFoodsToLocalDatabase(foods, type: DGFoodOptionType.Category.rawValue)
            
            completion(result: foods, error: nil)
        }
    }
    

    // MARK: - Rate Food API
    func rateFood(foodId foodId: Int, points: Float, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.RateFood(foodId, points)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error rateFood: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            completion(result: json, error: nil)
        }
    }
    
    
    // MARK: - Order API
    func getActiveOrders(completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.ActiveOrders()).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error orders: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            let orders = DGOrder.ordersFromJSON(json)
            self.activeOrder = orders
            
            self.addOrdersToLocalDatabase(orders)
            
            completion(result: orders, error: nil)
        }
    }
    
    
    func getOrders(completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.Orders(self.user.id)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error orders: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let orders = DGOrder.ordersFromJSON(json)
            self.addOrdersToLocalDatabase(orders)
            
            completion(result: orders, error: nil)
        }
    }
    
    func order(orderId orderId: Int, tableId: Int, tableName: String, notes: String, isPreOrder: Bool, restaurantId: Int, foods: [AnyObject], completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.Order(orderId, tableId, tableName, notes, isPreOrder, restaurantId, foods)).responseJSON { (response) -> Void in
            guard response.result.isSuccess else {
                print("Error order: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                jsonData = json["data"] as? [AnyObject],
                data = jsonData[0] as? [String: AnyObject] else {
                    
                    let json = response.result.value as? [String: AnyObject]
                    if let message = json!["message"] {
                        let error = self.errorFromJSON(["non_field_errors":[message]])
                        completion(result: nil, error: error)
                        return
                    }
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let order = DGOrder.orderFromJSON(data)
            self.addOrdersToLocalDatabase([order])
            self.currentOrder = nil
            
            completion(result: order, error: nil)
        }
    }
    
    func getOrderDetailById(orderId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.OrderDetail(orderId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error orders: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let jsonData = json["data"] as? [String : AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            let items = DGOrderItem.orderItemsFromJSON(jsonData)
            for item in items {
                DGDatabaseManager.sharedInstance.createOrderItem(item)
            }
            
            completion(result: items, error: nil)
        }
    }
    
    func checkoutOrderById(orderId: Int, status: Int, taxOptions: [String: Int]?, serviceOptions: [String: Int]?, promotion: String?, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.OrderCheckout(orderId, status, taxOptions, serviceOptions, promotion)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error order: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            completion(result: json, error: nil)
        }
    }
    
    func cancelOrderItem(orderItemId: Int, notes: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        manager.request(DGRouter.UpdateOrderItem(orderItemId, 4, notes)).responseJSON { (response) -> Void in
            guard response.result.isSuccess else {
                print("Error order: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            completion(result: json, error: nil)
        }
    }
    
    
    func changeTableOfOrderItem(orderItemId: Int, fromTableId: Int, toTableId: Int, restaurantId: Int,completion:(result: AnyObject?, error: NSError?) -> Void) {
        manager.request(DGRouter.ChangeTableOfOrderItem(orderItemId, fromTableId, toTableId, restaurantId)).responseJSON { (response) -> Void in
            guard response.result.isSuccess else {
                print("Error order: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject] else {
                
                print("Invalid response data")
                let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                completion(result: nil, error: error)
                return
            }
            
            completion(result: json, error: nil)
        }
    }

    func getPromotionCode(restaurantId restaurantId: Int, code: String, completion:(result: AnyObject?, error: NSError?) -> Void) {
        manager.request(DGRouter.PromotionCode(code, restaurantId)).responseJSON { (response) -> Void in
            guard response.result.isSuccess else {
                print("Error: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            print(response)
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let jsonError = ["non_field_errors": [response.result.value!["message"]]]
                    let error = self.errorFromJSON(jsonError)
                    completion(result: nil, error: error)
                    return
            }
            
            let promotionCode = DGPromotionCode.promotionCodeFromJSON(data)
            completion(result: promotionCode, error: nil)
        }
    }
    
    // MARK: - Setting Restaurant API
    func getSettingRestaurant(restaurantId restaurantId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        manager.request(DGRouter.SettingRestaurant(restaurantId)).responseJSON { (response) -> Void in
            print(response)
            guard response.result.isSuccess else {
                print("Error settingRestaurant: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let settings = DGSettings.settingsFromJSON(data)
            self.settings = settings
            
            // Cache data
            settings.cache()
            
            completion(result: settings, error: nil)
        }
    }
    
    // MARK: - TV API
    func getTVToken(restaurantId restaurantId: Int, completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.TVToken(restaurantId)).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error getTVToken: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            let tokenID = data["tokenID"]
            completion(result: tokenID, error: nil)
        }
    }
    
    func getTV(completion:(result: AnyObject?, error: NSError?) -> Void) {
        
        manager.request(DGRouter.GetTV).responseJSON { (response) -> Void in
            
            guard response.result.isSuccess else {
                print("Error getTV: \(response.result.error)")
                completion(result: nil, error: response.result.error)
                return
            }
            
            guard let json = response.result.value as? [String: AnyObject],
                let data = json["data"] as? [String: AnyObject] else {
                    
                    print("Invalid response data")
                    let error = self.errorFromJSON((response.result.value as? [String: AnyObject])!)
                    completion(result: nil, error: error)
                    return
            }
            
            completion(result: data, error: nil)
        }
    }
}

//============================================================
// Sample request
//============================================================

//DGDataManager.sharedInstance.getConfig(appKey: "a", countryCode: 1) { (result, error) in
//}
//DGDataManager.sharedInstance.login(email: "ballard@enclave.vn", password: "123456", completion: { (result, error) -> Void in
//})
//DGDataManager.sharedInstance.searchRestaurants(query: "A la cart", completion: { (result, error) in
//})
//DGDataManager.sharedInstance.searchRestaurantsIndexes(query: "A", completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getRestaurantsWifi(wifiName: "restaurant_01", completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getCategories(restaurantId: self.user.restaurantId, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getTables(restaurantId: self.user.restaurantId, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getFoods(restaurantId: self.user.restaurantId, option: DGFoodOptionType.Home, categoryId: 0, page: 0, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getFoods(restaurantId: self.user.restaurantId, option: DGFoodOptionType.Category, categoryId: 1, page: 0, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getFoodDetail(foodId: 1, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.likeFood(foodId: 1, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.unlikeFood(foodId: 1, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.favoriteFood(foodId: 3, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.unfavoriteFood(foodId: 3, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getFavoritedFoods(page: 0, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.postCommentFood(foodId: 1, content: "This is my comment 2 for this food", completion: { (result, error) in
//})
//DGDataManager.sharedInstance.updateCommentFood(commentId: 5, content: "Good Smell 1", completion: { (result, error) in
//})
//DGDataManager.sharedInstance.deleteCommentFood(commentId: 12, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getCommentsFood(foodId: 1, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.rateFood(foodId: 1, points: 3.5, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getOrders({ (result, error) in
//})
//let foods = [["food_id": 1, "food_name": "Saag Paneer", "size": "L", "quantity": 5, "notes": "This is my order for this food"]]
//DGDataManager.sharedInstance.order(orderId: -1, tableId: 1, tableName: "Table 1", notes: "This is my comment for this food", isPreOrder: true, restaurantId: 1, foods: foods, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.checkoutOrderById(259, status: 0, completion: { (result, error) in
//})
//self.getPromotionCode(restaurantId: self.user.restaurantId, code: "tk00001", completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getSettingRestaurant(restaurantId: 1, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getTVToken(restaurantId: 1, completion: { (result, error) in
//})
//DGDataManager.sharedInstance.getTV({ (result, error) in
//})
//DGDataManager.sharedInstance.searchFoods(query: "a", restaurantId: 1, completion: { (result, error) in
//})
