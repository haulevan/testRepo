//
//  DGRouter.swift
//  DGRestaurant
//
//  Created by Hayward on 6/15/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation
import Alamofire

//#if RELEASE_VERSION
let baseURLPath = "https://apis.mcafeteria.com"
//#else
//let baseURLPath = "http://113.160.225.76:8894/mRestaurantAPI"
//#endif

public enum DGRouter: URLRequestConvertible {
    
    // Get App Config
    case Config(String, Int)
    
    // Get App Data
    case SyncData(Int, Int)
    
    // Register
    case Register(String, String, String, String, String)
    
    // Login
    case Login(String, String, String)

    // Change password
    case ChangePassword(String, String)

    // Restaurants
    case Restaurants(String)
    
    // Restaurants Indexes
    case RestaurantsIndexes(String)

    // Restaurant wifi
    case RestaurantWifi(String)
    
    // Tables
    case Tables(Int)
    
    // Categories
    case Categories(Int)
    
    // CategoriesHome
    case CategoriesHome(Int)
    
    // Foods
    case Foods(Int, String, Int)
    
    // Food Detail
    case FoodDetail(Int)
    
    // Search Foods
    case SearchFoods(String, Int)
    
    // Like Food
    case LikeFood(Int)
    
    // UnLike Food
    case UnlikeFood(Int)
    
    // Favorite Food
    case FavoriteFood(Int)
    
    // Unfavorite Food
    case UnfavoriteFood(Int)
    
    // Get Favorited Foods
    case FavoritedFoods(Int)
    
    // Post Comment Food
    case PostCommentFood(Int, String)
    
    // Update Comment Food
    case UpdateCommentFood(Int, String)
    
    // Delete Comment Food
    case DeleteCommentFood(Int)
    
    // Get Comment Food
    case CommentsFood(Int)
    
    // Rate Food
    case RateFood(Int, Float)

    // Get ActiveOrders
    case ActiveOrders()

    // Get Orders
    case Orders(Int)
    
    // Order
    case Order(Int, Int, String, String, Bool, Int, [AnyObject])
    
    // Order Detail
    case OrderDetail(Int)
    
    // Order Checkout
    case OrderCheckout(Int, Int, [String: Int]?, [String: Int]?, String?)
    
    // Update Order Item
    case UpdateOrderItem(Int, Int, String)

    // Change Table Of Order Item
    case ChangeTableOfOrderItem(Int, Int, Int, Int)

    // Promotion Code
    case PromotionCode(String, Int)
    
    // Setting Restaurant
    case SettingRestaurant(Int)
    
    // TVToken
    case TVToken(Int)
    
    // Get TV
    case GetTV
    
    public var URLRequest: NSMutableURLRequest {
        
        let result: (path: String, method: Alamofire.Method, parameters: [String: AnyObject], encoding: Alamofire.ParameterEncoding) = {
            
            let urlEncoding = Alamofire.ParameterEncoding.URL
            let jsonEncoding = Alamofire.ParameterEncoding.JSON
            let customEncoding = Alamofire.ParameterEncoding.Custom({ (URLRequest, parameters) -> (NSMutableURLRequest, NSError?) in
                var components: [String] = []
                for value in parameters!["key"] as! [AnyObject] {
                    components.append(urlEncoding.escape("\(value)"))
                }
                let mutableURLRequest = URLRequest.URLRequest
                let urlString = mutableURLRequest.URLString + "/" + components.joinWithSeparator("/")
                mutableURLRequest.URL = NSURL(string: urlString)!
                return (mutableURLRequest, nil)
            })
            
            switch self {
            // Config
            case .Config(let appKey, let countryCode):
                let params = ["key": [appKey, countryCode]]
                return ("/app", .GET, params, customEncoding)
            
            // Sync Data
            case .SyncData(let restaurantId, let version):
                let params = ["key": [restaurantId, version, DGDataManager.sharedInstance.tokenID]]
                return ("/app-get-data", .GET, params, customEncoding)
                
            // Register
            case .Register(let email, let password, let firstName, let lastName, let appKey):
                let params = ["email": email, "password": password, "retyped_password": password,
                              "firstname": firstName, "lastname": lastName, "appKey": appKey]
                return ("/user", .POST, params, jsonEncoding)
            
            // Login
            case .Login(let email, let password, let appKey):
                let params = ["email": email, "password": password, "appKey": appKey]
                return ("/user/login", .POST, params, jsonEncoding)
                
            case .ChangePassword(let password, let newPassword):
                let params = ["current_password": password, "new_password": newPassword, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/user/password", .PUT, params, jsonEncoding)

            // Restaurants
            case .Restaurants(let query):
                let params = ["key": [query, DGDataManager.sharedInstance.tokenID]]
                return ("/restaurants", .GET, params, customEncoding)
            
            // Restaurants Indexes
            case .RestaurantsIndexes(let query):
                let params = ["key": [query, DGDataManager.sharedInstance.tokenID]]
                return ("/restaurants/indexes", .GET, params, customEncoding)

            // Restaurant wifi
            case .RestaurantWifi(let wifiName):
                let params = ["key": [wifiName, DGDataManager.sharedInstance.tokenID]]
                return ("/restaurant/wifi", .GET, params, customEncoding)
                
            // Tables
            case .Tables(let restaurantId):
                let params = ["key": [restaurantId, DGDataManager.sharedInstance.tokenID]]
                return ("/tables", .GET, params, customEncoding)
                
            // Categories
            case .Categories(let restaurantId):
                let params = ["key": [restaurantId, DGDataManager.sharedInstance.tokenID]]
                return ("/category", .GET, params, customEncoding)
                
            // CategoriesHome
            case .CategoriesHome(let restaurantId):
                let params = ["key": [restaurantId, DGDataManager.sharedInstance.tokenID]]
                return ("/category/home", .GET, params, customEncoding)
                
            // Foods
            case .Foods(let restaurantId, let option, let page):
                let params = ["key": [restaurantId, option, page, DGDataManager.sharedInstance.tokenID]]
                return ("/foods", .GET, params, customEncoding)
                
            // Food Detail
            case .FoodDetail(let foodId):
                let params = ["key": [foodId, DGDataManager.sharedInstance.tokenID]]
                return ("/food-detail", .GET, params, customEncoding)
                
            // Search Foods
            case .SearchFoods(let query, let restaurantId):
                let params = ["key": [query, restaurantId, DGDataManager.sharedInstance.tokenID]]
                return ("/search", .GET, params, customEncoding)
                
            // Like Food
            case .LikeFood(let foodId):
                let params = ["food_id": foodId, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/foods/like", .POST, params as! [String : AnyObject], jsonEncoding)
                
            // UnLike Food
            case .UnlikeFood(let foodId):
                let params = ["food_id": foodId, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/foods/like", .DELETE, params as! [String : AnyObject], jsonEncoding)
                
            // Favorite Food
            case .FavoriteFood(let foodId):
                let params = ["food_id": foodId, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/food/favorite", .POST, params as! [String : AnyObject], jsonEncoding)
                
            // Unfavorite Food
            case .UnfavoriteFood(let foodId):
                let params = ["food_id": foodId, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/food/favorite", .DELETE, params as! [String : AnyObject], jsonEncoding)
                
            // Get Favorited Foods
            case .FavoritedFoods(let page):
                let params = ["key": [page, DGDataManager.sharedInstance.tokenID]]
                return ("/food/favorite", .GET, params, customEncoding)
                
            // Post Comment Food
            case .PostCommentFood(let foodId, let content):
                let params = ["food_id": foodId, "content": content, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/food/comment", .POST, params as! [String : AnyObject], jsonEncoding)
                
            // Update Comment Food
            case .UpdateCommentFood(let commentId, let content):
                let params = ["comment_id": commentId, "content": content, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/food/comment", .PUT, params as! [String : AnyObject], jsonEncoding)
                
            // Delete Comment Food
            case .DeleteCommentFood(let commentId):
                let params = ["comment_id": commentId, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/food/comment", .DELETE, params as! [String : AnyObject], jsonEncoding)
                
            // Get Comments Food
            case .CommentsFood(let foodId):
                let params = ["key": [foodId, DGDataManager.sharedInstance.tokenID]]
                return ("/food/comment", .GET, params, customEncoding)
                
            // Rate Food
            case .RateFood(let foodId, let points):
                let params = ["food": foodId, "points": points, "tokenID": DGDataManager.sharedInstance.tokenID]
                return ("/food/rate", .POST, params as! [String : AnyObject], jsonEncoding)

            // Get active orders
            case .ActiveOrders():
                let params = ["key": [DGDataManager.sharedInstance.tokenID]]
                return ("/refresh", .GET, params, customEncoding)

            // Get orders
            case .Orders(let userId):
                let params = ["key": [userId, DGDataManager.sharedInstance.tokenID]]
                return ("/orders", .GET, params, customEncoding)


            // Order
            case .Order(let orderId, let tableId, let tableName, let notes, let isPreOrder, let restaurantId, let foods):
                var foodsDict: [String: AnyObject] = [:]
                for i in 0..<foods.count {
                    foodsDict["\(i)"] = foods[i]
                }
                var params: [String: AnyObject] = ["table_id": tableId, "table_name": tableName, "notes": notes, "is_pre_order": isPreOrder, "restaurant_id": restaurantId, "tokenID": DGDataManager.sharedInstance.tokenID, "foods": foodsDict]
                if orderId >= 0 {
                    params["id"] = orderId
                }
                return ("/order", .POST, params, jsonEncoding)
                
            case .OrderDetail(let orderId):
                let params = ["key": [orderId, DGDataManager.sharedInstance.tokenID]]
                return ("/order", .GET, params, customEncoding)
                
            case .OrderCheckout(let orderId, let status, let taxOptions, let serviceOptions, let promotionCode):
                var params: [String: AnyObject] = ["order_id": orderId, "status": status, "tokenID": DGDataManager.sharedInstance.tokenID]
                if taxOptions != nil {
                    params["tax_options"] = taxOptions
                }
                if serviceOptions != nil {
                    params["service_options"] = serviceOptions
                }
                if promotionCode != nil {
                    params["promotion"] = promotionCode
                }
                return ("/order/checkout", .POST, params, jsonEncoding)
                
            case .UpdateOrderItem(let orderItemId, let status, let notes):
                let params = ["tokenID": DGDataManager.sharedInstance.tokenID, "order_item_id": orderItemId, "status": status, "note": notes]
                return ("/order/food-status", .PUT, params as! [String : AnyObject], jsonEncoding)
               
            case .ChangeTableOfOrderItem(let orderItemId, let fromTableId, let toTableId, let restaurantId):
                let params = ["tokenID": DGDataManager.sharedInstance.tokenID,
                              "restaurant_id": restaurantId,
                              "order_id": orderItemId,
                              "from_table_name": fromTableId,
                              "to_table_name": toTableId]
                
                return ("/table/change", .POST, params as! [String : AnyObject], jsonEncoding)

            case .PromotionCode(let code, let restaurantId):
                let params = ["key": [code, restaurantId, DGDataManager.sharedInstance.tokenID]]
                return ("/promotion", .GET, params, customEncoding)
                
            // Setting Restaurant
            case .SettingRestaurant(let restaurantId):
                let params = ["key": [restaurantId, DGDataManager.sharedInstance.tokenID]]
                return ("/setting/restaurant", .GET, params, customEncoding)
                
            // TV Token
            case .TVToken(let restaurantId):
                let params = ["key": [restaurantId, DGDataManager.sharedInstance.tokenID]]
                return ("/tv/token", .GET, params, customEncoding)
                
            // Get TV
            case .GetTV:
                let params = ["key": [DGDataManager.sharedInstance.tokenID]]
                return ("/tv", .GET, params, customEncoding)
            }
        }()
        
//        do {
//            let jsonData = try NSJSONSerialization.dataWithJSONObject(result.parameters, options: .PrettyPrinted)
//            let jsonString = NSString(data: jsonData, encoding: NSUTF8StringEncoding)! as String
//            print(jsonString)
//        }
//        catch {
//            print(error)
//        }
        
        let URL = NSURL(string: baseURLPath)!
        let URLRequest = NSMutableURLRequest(URL: URL.URLByAppendingPathComponent(result.path)!)
        URLRequest.HTTPMethod = result.method.rawValue
        URLRequest.timeoutInterval = NSTimeInterval(10 * 1000)
        
//        if let tokenID = DGDataManager.sharedInstance.tokenID {
//            switch result.encoding {
//            case .JSON:
//                URLRequest.setValue(tokenID, forHTTPHeaderField: "tokenID")
//            default: break
//            }
//        }
        
        let encoding = result.encoding
        return encoding.encode(URLRequest, parameters: result.parameters).0
    }
    
}
