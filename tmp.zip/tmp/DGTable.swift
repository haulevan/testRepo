//
//  DGTable.swift
//  DGRestaurant
//
//  Created by Hayward on 6/18/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGTable {
    
    var id: Int!
    var name: String!
    var restaurantId: Int!
    var seats: Int?
    var status: DGTableStatus?
    
    class func tableFromJSON(json: [String: AnyObject]) -> DGTable {
        print(json)
        let table = DGTable()
        
        table.id = Int(json["table_name"] as! String)
        table.name = json["table_name"] as! String
        table.restaurantId = Int(json["restaurant_id"] as! String)
        table.seats = json["seats"] as? Int
        table.status = json["status"] as? DGTableStatus
        
        return table
    }
    
    class func tablesFromJSON(json: [String: AnyObject]) -> [DGTable] {
        
        var tables = [DGTable]()
        
        if let results = json["data"] as? [AnyObject] {
            for result in results {
                let table = DGTable.tableFromJSON(result as! [String : AnyObject])
                tables.append(table)
            }
        }
        
        return tables
    }
    
    class func tableFromResultSet(rs: FMResultSet) -> DGTable {
        
        let table = DGTable()
        
        table.id = Int(rs.intForColumn("table_id"))
        table.name = rs.stringForColumn("table_name")
        table.restaurantId = Int(rs.intForColumn("restaurant_id"))
        table.seats = Int(rs.intForColumn("seats"))
        table.status = DGTableStatus(rawValue: Int(rs.intForColumn("status")))!
        
        return table
    }
}
