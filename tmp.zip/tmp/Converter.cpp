//
//  Converter.cpp
//  CalcLib
//
//  Created by PhuongNguyen on 12/6/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "Converter.hpp"

#define  SYNC1 0x40
#define  SYNC2 0x28
#define  SYNC3 0x6B
#define  SYNC4 0xFE

#define TICKS_TO_MS_MULT 1000
#define TICKS_TO_MS_DIV 32768

typedef enum  {
    State_LookingForSync1,
    State_LookingForSync2,
    State_LookingForSync3,
    State_LookingForSync4
} state_t;


state_t state = State_LookingForSync1;
uint8_t buffer[128];

typedef struct  {
    uint8_t acc_x_l;
    uint8_t acc_x_h;
    uint8_t acc_y_l;
    uint8_t acc_y_h;
    uint8_t acc_z_l;
    uint8_t acc_z_h;
    
    uint16_t timer_ticks;
    
    uint8_t gyro_x_l;
    uint8_t gyro_x_h;
    uint8_t gyro_y_l;
    uint8_t gyro_y_h;
    uint8_t gyro_z_l;
    uint8_t gyro_z_h;
    
}MPU_DataTypeDef;

typedef struct  {
    //uint16_t status1; //extra info register
    int16_t hx;
    int16_t hy;
    int16_t hz;
    //uint16_t status2; //extra control register
} AK_DataTypeDef;


typedef struct  {
    //uint16_t status1; //extra info register
    //	char a[4];
    uint8_t a1;
    uint8_t a2;
    uint8_t a3;
    uint8_t a4;
    uint16_t b;
    uint16_t bb;
    uint16_t c;
    uint16_t cc;
    uint16_t d;
    uint16_t dd;
    
    //uint16_t status2; //extra control register
} QT_DataTypeDef;


struct rx_data {
    //uint32_t time;
    MPU_DataTypeDef mpu_data;
    // AK_DataTypeDef ak_data;
    QT_DataTypeDef qt_data;
    
} rx_data;


#define NORMAL 1
#define AMAG 2
#define ACCEL 3

namespace DT {
    
    Mat<double> Converter::convert(int argc, const char *cfilename)
    {
        size_t result;
        int outputType;
        uint32_t timer_ticks_MSH, current_ticks;
        uint16_t prev_timer_ticks;
        Mat<double> mat(280, 11);
        
        timer_ticks_MSH = 0;
        prev_timer_ticks = 0;
        outputType = NORMAL;
        
        FILE *pBinFile;
        pBinFile = fopen(cfilename, "rb");
        
        int count = 0;
        state = State_LookingForSync1;
        while ((result = fread( buffer, 1, 1, pBinFile)) ){
            switch (state){
                    
                case State_LookingForSync1:
                    if (SYNC1 == buffer[0]){
                        state = State_LookingForSync2;
                    }
                    break;
                    
                case State_LookingForSync2:
                    if (SYNC2 == buffer[0]){
                        state = State_LookingForSync3;
                    } else {
                        state = State_LookingForSync1;
                    }
                    break;
                    
                case State_LookingForSync3:
                    if (SYNC3 == buffer[0]){
                        state = State_LookingForSync4;
                    }else {
                        state = State_LookingForSync1;
                    }
                    break;
                case State_LookingForSync4:
                    if (SYNC4 == buffer[0]){
                        
                        memset(&rx_data, 0, sizeof(rx_data));
                        result = fread((void *)&rx_data, sizeof(rx_data), 1, pBinFile);
                        state = State_LookingForSync1;
                        
                        if( 0 == strncmp(( char *)&rx_data,"end",3)){
                            return mat;
                        }
                        
                        if( 0 == strncmp(( char *)&rx_data,"data",4)){
                            return mat;
                        }
                        
                        if (prev_timer_ticks > rx_data.mpu_data.timer_ticks){
                            timer_ticks_MSH += 0x10000;
                        }
                        prev_timer_ticks = rx_data.mpu_data.timer_ticks;
                        current_ticks = timer_ticks_MSH | rx_data.mpu_data.timer_ticks;
                        
                        if (1 == result ){
                            if(NORMAL == outputType){
                                
                                mat(count, 0) = double((current_ticks * TICKS_TO_MS_MULT) / TICKS_TO_MS_DIV);
                                
                                mat(count, 1) = (rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l );
                                mat(count, 2) = (rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l );
                                mat(count, 3) = (rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l );
                                
                                mat(count, 4) = (rx_data.mpu_data.gyro_x_h<< 8 | rx_data.mpu_data.gyro_x_l );
                                mat(count, 5) = (rx_data.mpu_data.gyro_y_h << 8 | rx_data.mpu_data.gyro_y_l );
                                mat(count, 6) = (rx_data.mpu_data.gyro_z_h << 8 | rx_data.mpu_data.gyro_z_l );
                                
                                uint16_t a12 = (uint16_t)(rx_data.qt_data.a2<< 8 | rx_data.qt_data.a1 );
                                uint16_t a34 = (uint16_t)(rx_data.qt_data.a4<< 8 | rx_data.qt_data.a3 );
                                uint32_t a = (uint32_t)(a34<< 16 | a12 );
                                uint32_t bbb = (uint32_t)(rx_data.qt_data.bb<<16|rx_data.qt_data.b);
                                uint32_t ccc = (uint32_t)(rx_data.qt_data.cc<<16|rx_data.qt_data.c);
                                uint32_t ddd = (uint32_t)(rx_data.qt_data.dd<<16|rx_data.qt_data.d );
                                
                                mat(count, 7) = *((float*)&a);
                                mat(count, 8) = *((float*)&bbb);
                                mat(count, 9) = *((float*)&ccc);
                                mat(count, 10) = *((float*)&ddd);
                                
                                count++;
                                if (count == 280) {
                                    return mat;
                                }
                                /*
                                 printf("%d,", (current_ticks * TICKS_TO_MS_MULT) / TICKS_TO_MS_DIV);
                                 
                                 printf("%d,", (int16_t)(rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l ));
                                 
                                 printf("%d,", (int16_t)(rx_data.mpu_data.gyro_x_h<< 8 | rx_data.mpu_data.gyro_x_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.gyro_y_h << 8 | rx_data.mpu_data.gyro_y_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.gyro_z_h << 8 | rx_data.mpu_data.gyro_z_l ));
                                 
                                 uint16_t a12=(uint16_t)(rx_data.qt_data.a2<< 8 | rx_data.qt_data.a1 );
                                 uint16_t a34=(uint16_t)(rx_data.qt_data.a4<< 8 | rx_data.qt_data.a3 );
                                 uint32_t a = (uint32_t)(a34<< 16 | a12 );
                                 uint32_t bbb = (uint32_t)(rx_data.qt_data.bb<<16|rx_data.qt_data.b);
                                 uint32_t ccc = (uint32_t)(rx_data.qt_data.cc<<16|rx_data.qt_data.c);
                                 uint32_t ddd = (uint32_t)(rx_data.qt_data.dd<<16|rx_data.qt_data.d );
                                 
                                 printf("%f,%f,%f,%f,", *((float*)&a),*((float*)&bbb),*((float*)&ccc),*((float*)&ddd));
                                 
                                 printf("\n");
                                 */
                                
                            }else if(AMAG ==outputType){
//                                printf("%d\t%d\t%d\n", rx_data.ak_data.hx, rx_data.ak_data.hy, rx_data.ak_data.hz);
                            } else if(ACCEL ==outputType){
                                
                                mat(count, 0) = (rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l );
                                mat(count, 1) = (rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l );
                                mat(count, 2) = (rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l );
                                
                                count++;
                                if (count == 280) {
                                    return mat;
                                }
                                
//                            printf("%d\t", (int16_t)(rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l ));
//                            printf("%d\t", (int16_t)(rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l ));
//                            printf("%d\n", (int16_t)(rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l ));
                            }
                            
                        }else{
                            fprintf(stderr,"Reached end of file \n");
                            return mat;
                        }
                    }else {
                        state = State_LookingForSync1;
                    }
                    break;
                    
                default:
                    state = State_LookingForSync1;
                    break;
            }
        }
        
        return mat;
    }
    
    Mat<double> Converter::convert(uint8_t *data, uint64_t size)
    {
        int outputType;
        uint32_t timer_ticks_MSH, current_ticks;
        uint16_t prev_timer_ticks;
        Mat<double> mat(280, 11);
        
        timer_ticks_MSH = 0;
        prev_timer_ticks = 0;
        outputType = NORMAL;
        
        int count = 0;
        uint64_t length = 0;
        state = State_LookingForSync1;
        while (length < size) {
            
            switch (state) {
                    
                case State_LookingForSync1:
                    if (SYNC1 == data[0]) {
                        state = State_LookingForSync2;
                    }
                    break;
                    
                case State_LookingForSync2:
                    if (SYNC2 == data[0]) {
                        state = State_LookingForSync3;
                    } else {
                        state = State_LookingForSync1;
                    }
                    break;
                    
                case State_LookingForSync3:
                    if (SYNC3 == data[0]) {
                        state = State_LookingForSync4;
                    } else {
                        state = State_LookingForSync1;
                    }
                    break;
                    
                case State_LookingForSync4:
                    if (SYNC4 == data[0]) {
                        
                        memset(&rx_data, 0, sizeof(rx_data));
                        memcpy((void *)&rx_data, data+1, sizeof(rx_data));
                        state = State_LookingForSync1;
                        
                        if (0 == strncmp(( char *)&rx_data,"end",3)) {
                            return mat;
                        }
                        
                        if (0 == strncmp(( char *)&rx_data,"data",4)) {
                            return mat;
                        }
                        
                        if (prev_timer_ticks > rx_data.mpu_data.timer_ticks) {
                            timer_ticks_MSH += 0x10000;
                        }
                        prev_timer_ticks = rx_data.mpu_data.timer_ticks;
                        current_ticks = timer_ticks_MSH | rx_data.mpu_data.timer_ticks;
                        
                        if (length + sizeof(rx_data) < size) {
                            
                            data += sizeof(rx_data);
                            length += sizeof(rx_data);
                            
                            if (NORMAL == outputType) {
                                
                                mat(count, 0) = double((current_ticks * TICKS_TO_MS_MULT) / TICKS_TO_MS_DIV);
                                
                                mat(count, 1) = (rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l );
                                mat(count, 2) = (rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l );
                                mat(count, 3) = (rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l );
                                
                                mat(count, 4) = (rx_data.mpu_data.gyro_x_h<< 8 | rx_data.mpu_data.gyro_x_l );
                                mat(count, 5) = (rx_data.mpu_data.gyro_y_h << 8 | rx_data.mpu_data.gyro_y_l );
                                mat(count, 6) = (rx_data.mpu_data.gyro_z_h << 8 | rx_data.mpu_data.gyro_z_l );
                                
                                uint16_t a12 = (uint16_t)(rx_data.qt_data.a2<< 8 | rx_data.qt_data.a1 );
                                uint16_t a34 = (uint16_t)(rx_data.qt_data.a4<< 8 | rx_data.qt_data.a3 );
                                uint32_t a = (uint32_t)(a34<< 16 | a12 );
                                uint32_t bbb = (uint32_t)(rx_data.qt_data.bb<<16|rx_data.qt_data.b);
                                uint32_t ccc = (uint32_t)(rx_data.qt_data.cc<<16|rx_data.qt_data.c);
                                uint32_t ddd = (uint32_t)(rx_data.qt_data.dd<<16|rx_data.qt_data.d );
                                
                                mat(count, 7) = *((float*)&a);
                                mat(count, 8) = *((float*)&bbb);
                                mat(count, 9) = *((float*)&ccc);
                                mat(count, 10) = *((float*)&ddd);
                                
                                count++;
                                if (count == 280) {
                                    return mat;
                                }
                                /*
                                 printf("%d,", (current_ticks * TICKS_TO_MS_MULT) / TICKS_TO_MS_DIV);
                                 
                                 printf("%d,", (int16_t)(rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l ));
                                 
                                 printf("%d,", (int16_t)(rx_data.mpu_data.gyro_x_h<< 8 | rx_data.mpu_data.gyro_x_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.gyro_y_h << 8 | rx_data.mpu_data.gyro_y_l ));
                                 printf("%d,", (int16_t)(rx_data.mpu_data.gyro_z_h << 8 | rx_data.mpu_data.gyro_z_l ));
                                 
                                 uint16_t a12=(uint16_t)(rx_data.qt_data.a2<< 8 | rx_data.qt_data.a1 );
                                 uint16_t a34=(uint16_t)(rx_data.qt_data.a4<< 8 | rx_data.qt_data.a3 );
                                 uint32_t a = (uint32_t)(a34<< 16 | a12 );
                                 uint32_t bbb = (uint32_t)(rx_data.qt_data.bb<<16|rx_data.qt_data.b);
                                 uint32_t ccc = (uint32_t)(rx_data.qt_data.cc<<16|rx_data.qt_data.c);
                                 uint32_t ddd = (uint32_t)(rx_data.qt_data.dd<<16|rx_data.qt_data.d );
                                 
                                 printf("%f,%f,%f,%f,", *((float*)&a),*((float*)&bbb),*((float*)&ccc),*((float*)&ddd));
                                 
                                 printf("\n");
                                 */
                                
                            } else if (AMAG ==outputType) {
//                                printf("%d\t%d\t%d\n", rx_data.ak_data.hx, rx_data.ak_data.hy, rx_data.ak_data.hz);
                            } else if (ACCEL ==outputType) {
                                
                                mat(count, 0) = (rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l );
                                mat(count, 1) = (rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l );
                                mat(count, 2) = (rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l );
                                
                                count++;
                                if (count == 280) {
                                    return mat;
                                }
                                
//                            printf("%d\t", (int16_t)(rx_data.mpu_data.acc_x_h << 8 | rx_data.mpu_data.acc_x_l ));
//                            printf("%d\t", (int16_t)(rx_data.mpu_data.acc_y_h << 8 | rx_data.mpu_data.acc_y_l ));
//                            printf("%d\n", (int16_t)(rx_data.mpu_data.acc_z_h << 8 | rx_data.mpu_data.acc_z_l ));
                            }
                            
                        } else {
                            fprintf(stderr,"Reached end of data \n");
                            return mat;
                        }
                    } else {
                        state = State_LookingForSync1;
                    }
                    break;
                    
                default:
                    state = State_LookingForSync1;
                    break;
            }
            data++;
            length++;
        }
        
        return mat;
    }
}
