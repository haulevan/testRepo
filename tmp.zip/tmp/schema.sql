-- -----------------------------------------------------
-- Table `user`
-- -----------------------------------------------------
DROP TABLE IF EXISTS user;

CREATE TABLE user (
`id` INT NOT NULL,
`firstname` NVARCHAR(255) NULL,
`lastname` VARCHAR(255) NULL,
`email` VARCHAR(255) NULL,
`pwd` VARCHAR(255) NULL,
`address_1` VARCHAR(255) NULL,
`address_2` VARCHAR(255) NULL,
`city` VARCHAR(255) NULL,
`country` VARCHAR(255) NULL,
`is_restaurant_owner` TINYINT(1) NULL,
`job` VARCHAR(255) NULL,
`notes` LONGTEXT NULL,
`phone_number` VARCHAR(45) NULL,
`photo_url` VARCHAR(255) NULL,
`user_type` INT NULL,
PRIMARY KEY (`id`));


-- -----------------------------------------------------
-- Table `restaurant`
-- -----------------------------------------------------
DROP TABLE IF EXISTS restaurant;

CREATE TABLE IF NOT EXISTS restaurant (
`restaurant_id` INT NOT NULL,
`restaurant_name` VARCHAR(255) NULL,
`address_1` VARCHAR(255) NULL,
`address_2` VARCHAR(255) NULL,
`chain_id` VARCHAR(45) NULL,
`city` VARCHAR(45) NULL,
`country` VARCHAR(45) NULL,
`lat` FLOAT NULL,
`lng` FLOAT NULL,
`owner` VARCHAR(45) NULL,
`phone` VARCHAR(45) NULL,
`photo_url` VARCHAR(255) NULL,
`status` INT NULL,
`tags` VARCHAR(255) NULL,
`wifi` VARCHAR(255) NULL,
`zip` VARCHAR(255) NULL,
PRIMARY KEY (`restaurant_id`));


-- -----------------------------------------------------
-- Table `table`
-- -----------------------------------------------------
DROP TABLE IF EXISTS dgtable;

CREATE TABLE IF NOT EXISTS dgTable (
`table_id` INT NOT NULL,
`table_name` VARCHAR(255) NULL,
`seats` INT NULL,
`status` INT NULL,
`restaurant_id` INT NULL,
PRIMARY KEY (`table_id`));


-- -----------------------------------------------------
-- Table `category`
-- -----------------------------------------------------
DROP TABLE IF EXISTS category;

CREATE TABLE IF NOT EXISTS category (
`category_id` INT NOT NULL,
`category_name` VARCHAR(255) NULL,
`food_count` INT NULL,
PRIMARY KEY (`category_id`));


-- -----------------------------------------------------
-- Table `food`
-- -----------------------------------------------------
DROP TABLE IF EXISTS food;

CREATE TABLE IF NOT EXISTS food (
`food_id` INT NOT NULL,
`food_name` VARCHAR(45) NULL,
`food_description` VARCHAR(255) NULL,
`comment_count` INT NULL,
`liked` INT NULL,
`rated` INT NULL,
`food_category` INT NULL,
`food_category_name` VARCHAR(255) NULL,
`photo_name` VARCHAR(255) NULL,
`photo_url_index` INT NULL,
`photo_proccessed` TINYINT(1) NULL,
`isLiked` TINYINT(1) NULL,
`isFavorited` TINYINT(1) NULL,
`type` INT NULL,
PRIMARY KEY (`food_id`));


-- -----------------------------------------------------
-- Table `price`
-- -----------------------------------------------------
DROP TABLE IF EXISTS price;

CREATE TABLE IF NOT EXISTS price (
`id` INT NOT NULL,
`price` FLOAT NULL,
`size` VARCHAR(5) NULL,
`food_id` INT NULL,
PRIMARY KEY (`id`));


-- -----------------------------------------------------
-- Table `comment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS comment;

CREATE TABLE IF NOT EXISTS comment (
`comment_id` INT NOT NULL,
`user` VARCHAR(45) NULL,
`content` LONGTEXT NULL,
`status` INT(11) NULL,
`created_at` DOUBLE NULL,
`updated_at` DOUBLE NULL,
`user_display_name` VARCHAR(255) NULL,
`food_id` INT NULL,
PRIMARY KEY (`comment_id`));


-- -----------------------------------------------------
-- Table `dgOrder`
-- -----------------------------------------------------
DROP TABLE IF EXISTS dgOrder;

CREATE TABLE IF NOT EXISTS dgOrder (
`order_id` INT NOT NULL,
`table_id` INT NULL,
`amount` INT NULL,
`total_amount` INT NULL,
`service_amount` FLOAT NULL,
`tax_amount` FLOAT NULL,
`time` DOUBLE NULL,
`status` TINYINT(1) NULL,
`notes` MEDIUMTEXT NULL,
PRIMARY KEY (`order_id`));


-- -----------------------------------------------------
-- Table `orderItem`
-- -----------------------------------------------------
DROP TABLE IF EXISTS orderItem;

CREATE TABLE IF NOT EXISTS orderItem (
`id` INT NOT NULL,
`order_id` INT NOT NULL,
`food_id` INT NOT NULL,
`food_name` VARCHAR(255) NULL,
`cost` FLOAT NULL,
`qty` FLOAT NULL,
`size` VARCHAR(5) NULL,
`notes` MEDIUMTEXT NULL,
`last_update` DOUBLE NULL,
`status` TINYINT(1) NULL,
`canceled_note` MEDIUMTEXT NULL,
`rejected_note` MEDIUMTEXT NULL,
`return_note` MEDIUMTEXT NULL,
`tv_status` TINYINT(1) NULL,
PRIMARY KEY (`id`));


-- -----------------------------------------------------
-- Table `orderService`
-- -----------------------------------------------------
DROP TABLE IF EXISTS orderService;

CREATE TABLE IF NOT EXISTS orderService (
`service_id` INT NOT NULL,
`amount` FLOAT NULL,
`service_name` VARCHAR(255) NULL,
`order_id` INT NULL,
PRIMARY KEY (`service_id`));


-- -----------------------------------------------------
-- Table `orderTax`
-- -----------------------------------------------------
DROP TABLE IF EXISTS orderTax;

CREATE TABLE IF NOT EXISTS orderTax (
`tax_id` INT NOT NULL,
`amount` FLOAT NULL,
`tax_name` VARCHAR(255) NULL,
`order_id` INT NULL,
PRIMARY KEY (`tax_id`));
