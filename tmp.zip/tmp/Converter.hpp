//
//  Converter.hpp
//  CalcLib
//
//  Created by PhuongNguyen on 12/6/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef Converter_hpp
#define Converter_hpp

#include "Matrix.hpp"

namespace DT
{
    class Converter
    {
    public:
        Converter() {};
        ~Converter() {};
        Mat<double> convert(int argc, const char *cfilename);
        Mat<double> convert(uint8_t *data, uint64_t size);
    };
}

#endif /* Converter_hpp */
