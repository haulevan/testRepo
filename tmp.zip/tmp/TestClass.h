//
//  TestClass.h
//  TestLib
//
//  Created by HauLe on 11/29/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestClass : NSObject
{
    
}

- (instancetype)init;
- (void)run;

@end
