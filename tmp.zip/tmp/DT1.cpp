//
//  DT1.cpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "DT1.hpp"

namespace DT
{
    DT1::DT1(const char *fileName)
    {
        
    }
    
    DT1::DT1(Mat<double> &m)
    {
        this->m = new Mat<double>(m);
    }
    
    /// calculate clubhead speed
    void DT1::calculate()
    {   
        clubheadSpeed = 0.0;
        Vec<double> t1 = m->get_col(0); // time in  milliseconds
        t1 /= 1000; // time is now in seconds
        
        Vec<double> gyrox1 = m->get_col(4);
        Vec<double> gyroy1 = m->get_col(5);
        Vec<double> gyroz1 = m->get_col(6);
        
        Vec<double> accx1 = m->get_col(1);
        Vec<double> accy1 = m->get_col(2);
        Vec<double> accz1 = m->get_col(3);
        
        Vec<double> qw1 = m->get_col(7);
        Vec<double> qx1 = m->get_col(8);
        Vec<double> qy1 = m->get_col(9);
        Vec<double> qz1 = m->get_col(10);
        
        Mat<double> quaternion1 = m->get_cols(7, 10);
        Mat<complex<double>> euler1 = quatern2euler(quaternion1);
        euler1 *= (180/M_PI);
        Vec<double> eux1 = euler1.get_col(0).realComplex();
        Vec<double> euy1 = euler1.get_col(1).realComplex();
        Vec<double> euz1 = euler1.get_col(2).realComplex();
        
        Vec<double> gx1 = 2.0 * (elem_mult(qx1, qz1) - elem_mult(qw1, qy1));
        Vec<double> gy1 = 2.0 * (elem_mult(qw1, qx1) + elem_mult(qy1, qz1));
        Vec<double> gz1 = elem_mult(qw1, qw1) - elem_mult(qx1, qx1) - elem_mult(qy1, qy1) + elem_mult(qz1, qz1);
        
        int impgyx1 = 0;
        int impgyy1 = 0;
        int impgyz1 = 0;
        
//        int impgz1 = 0;
//        int ofact1 = 0;
//        int cfact1 = 0;
        
//        int impactangles1MF = 0;
        double addressangley1L = 70.0;
        
        impgyx1 = gyrox1.abs().maxIndex();
        impgyy1 = gyroy1.abs().maxIndex();
        impgyz1 = gyroz1.abs().maxIndex();
        
        Vec<int> idx1 = gz1.findPeaks(true, 0.1, 3.0, 1.0);
        idx1 = idx1.filterInRange(80, 360);
        
        Vec<double> gy1AL = gy1(49, 109);
        gy1AL = ((gy1AL.diff() * 1000.0).round()) / 1000.0;
        int firstPositiveIdx = gy1AL.findFirstPositive();
        firstPositiveIdx += 49;
        
        addressangley1L = euy1(firstPositiveIdx-5, firstPositiveIdx+3).mean();
        Vec<double> addressanglesy1 = euy1(0, 49);
        addressanglesy1 = addressanglesy1.medfilt1();
        double addressangley1 = addressanglesy1.mean();
        
        Vec<double> addressanglesdiffy1 = addressanglesy1 - addressangley1;
        Vec<int> indexs = addressanglesdiffy1.abs().findLessThan(20.0, -1);
        addressanglesy1 = addressanglesy1.findByIndexs(indexs);
        addressangley1 = addressanglesy1.mean();
        
        Vec<double> impactangles1 = euy1(impgyx1 - 4, impgyx1 + 4);
        Vec<double> diffr1L = impactangles1 - addressangley1L;
        Vec<int> b1l = diffr1L.abs().sortIndex(true);
        ifagyx1L = impactangles1(b1l(0)) - addressangley1L;
        
        impactangles1 = euy1(impgyx1 - 4, impgyx1 + 4);
        diffr1L = impactangles1 - addressangley1;
        Vec<int> b1 = diffr1L.abs().sortIndex(true);
        ifagyx1 = impactangles1(b1(0)) - addressangley1;
        
        Vec<double> gtot = (elem_mult(gyrox1, gyrox1) + elem_mult(gyroy1, gyroy1) + elem_mult(gyroz1, gyroz1)).sqrt();
        double gtot_max = gtot.maxValue();
        
        double clubSwingRadius = 0.85; // in meters
        clubheadSpeed = clubSwingRadius * gtot_max * (2000.0/32768.0) * 3.1415926 / 180.0; // m/s
        clubheadSpeed = clubheadSpeed * 3600.0 / 1609.34; // in mph
    }
}
