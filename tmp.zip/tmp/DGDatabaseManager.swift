//
//  DGDatabaseManager.swift
//  DGRestaurant
//
//  Created by Hayward on 6/27/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGDatabaseManager {
    
    // MARK: - Singleton
    static let sharedInstance = DGDatabaseManager()
    
    // MARK: - Properties
    var database: FMDatabase?
    
    init() {
        
        let documentsURL = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
        let fileURL = documentsURL.URLByAppendingPathComponent(kDGDataFileName)
        print("Data file path: \(fileURL)")
        
        self.database = FMDatabase(path: fileURL!.path!)
    }
    
    func nullifiedObject(obj: AnyObject?) -> AnyObject {
        if obj != nil {
            return obj!
        }
        return NSNull()
    }
    
    // MARK: - Migrate Database
    func migrateDatabase() -> Void {
        
        let ud = NSUserDefaults.standardUserDefaults()
        let oldVersion = ud.floatForKey(kDGSchemaVersionKey)
        
        let dbConfig = DGDatabaseConfig()
        let newVersion = dbConfig.schemaVersion()
        
        if !self.database!.open() {
            print("Migration: Opening database failed")
            return
        }
        
        if newVersion != oldVersion {
        
            guard let schemaSQL = dbConfig.schema() else {
                return
            }
            
            if self.database!.executeStatements(schemaSQL) {
                ud.setObject(newVersion, forKey: kDGSchemaVersionKey)
                print("Completed data migration")
            }
            else {
                print("Migration: Executing schema SQL failed \(self.database!.lastErrorMessage)")
                self.database!.close()
            }
        }
    }
    
    // MARK: - User API
    func createUser(user: DGUser) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryAddUser,
                                             user.id,
                                             self.nullifiedObject(user.firstName),
                                             self.nullifiedObject(user.lastName),
                                             self.nullifiedObject(user.email),
                                             self.nullifiedObject(user.password),
                                             self.nullifiedObject(user.address1),
                                             self.nullifiedObject(user.address2),
                                             self.nullifiedObject(user.city),
                                             self.nullifiedObject(user.country),
                                             self.nullifiedObject(user.isRestaurantOwner),
                                             self.nullifiedObject(user.job),
                                             self.nullifiedObject(user.notes),
                                             self.nullifiedObject(user.phoneNumber),
                                             self.nullifiedObject(user.photo?.url),
                                             self.nullifiedObject(user.userType?.rawValue))
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func updateUser(user: DGUser) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryUpdateUser,
                                             self.nullifiedObject(user.firstName),
                                             self.nullifiedObject(user.lastName),
                                             self.nullifiedObject(user.email),
                                             self.nullifiedObject(user.password),
                                             self.nullifiedObject(user.address1),
                                             self.nullifiedObject(user.address2),
                                             self.nullifiedObject(user.city),
                                             self.nullifiedObject(user.country),
                                             self.nullifiedObject(user.isRestaurantOwner),
                                             self.nullifiedObject(user.job),
                                             self.nullifiedObject(user.notes),
                                             self.nullifiedObject(user.phoneNumber),
                                             self.nullifiedObject(user.photo?.url),
                                             self.nullifiedObject(user.userType?.rawValue),
                                             user.id)
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func userByID(userID: Int) -> DGUser? {
        
        do {
            let rs = try self.database!.executeQuery(kDGQueryUserByID, userID)
            while (rs.next()) {
                return DGUser.userFromResultSet(rs)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return nil
    }
    
    func allUsers() -> [DGUser] {
        
        var users = [DGUser]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryAllUsers)
            while (rs.next()) {
                let user = DGUser.userFromResultSet(rs)
                users.append(user)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return users
    }
    
    // MARK: - Restaurant API
    func createRestaurant(restaurant: DGRestaurant) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryAddRestaurant,
                                             restaurant.id,
                                             restaurant.name,
                                             self.nullifiedObject(restaurant.address1),
                                             self.nullifiedObject(restaurant.address2),
                                             self.nullifiedObject(restaurant.chainId),
                                             self.nullifiedObject(restaurant.city),
                                             self.nullifiedObject(restaurant.country),
                                             self.nullifiedObject(restaurant.lat),
                                             self.nullifiedObject(restaurant.lng),
                                             self.nullifiedObject(restaurant.owner),
                                             self.nullifiedObject(restaurant.phone),
                                             self.nullifiedObject(restaurant.photo?.url),
                                             self.nullifiedObject(restaurant.status),
                                             self.nullifiedObject(restaurant.tags),
                                             self.nullifiedObject(restaurant.wifi),
                                             self.nullifiedObject(restaurant.zip))
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func restaurantByID(restaurantId: Int) -> DGRestaurant? {
        
        do {
            let rs = try self.database!.executeQuery(kDGQueryRestaurantByID, restaurantId)
            while (rs.next()) {
                return DGRestaurant.restaurantFromResultSet(rs)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return nil
    }
    
    func allRestaurants() -> [DGRestaurant] {
        
        var restaurants = [DGRestaurant]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryAllRestaurants)
            while (rs.next()) {
                let restaurant = DGRestaurant.restaurantFromResultSet(rs)
                restaurants.append(restaurant)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return restaurants
    }
    
    func deleteRestaurantByID(restaurantId: Int) -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteRestaurantByID, restaurantId)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    func deleteAllRestaurants() -> Void {
        
        var result = true
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllRestaurants)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            result = false
        }
        
        if result {
            self.deleteAllTables()
            self.deleteAllCategories()
            self.deleteAllFoods()
            self.deleteAllPrices()
            self.deleteAllComments()
            self.deleteAllOrders()
            self.deleteAllOrderItems()
            self.deleteAllOrderServices()
            self.deleteAllOrderTaxes()
        }
    }
    
    // MARK: - Table API
    func createTable(table: DGTable) -> Bool {
        do {
            try self.database!.executeUpdate(kDGQueryAddTable,
                                             table.id,
                                             table.name,
                                             table.restaurantId,
                                             self.nullifiedObject(table.seats),
                                             self.nullifiedObject(table.status?.rawValue))
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func allTables() -> [DGTable] {
        
        var tables = [DGTable]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryAllTables)
            while (rs.next()) {
                let table = DGTable.tableFromResultSet(rs)
                tables.append(table)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return tables
    }
    
    func deleteAllTables() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllTables)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Category API
    func createCategory(category: DGCategory) -> Bool {
        do {
            try self.database!.executeUpdate(kDGQueryAddCategory,
                                             category.id,
                                             category.name,
                                             self.nullifiedObject(category.foodCount))
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func allCategories() -> [DGCategory] {
        
        var categories = [DGCategory]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryAllCategories)
            while (rs.next()) {
                let category = DGCategory.categoryFromResultSet(rs)
                categories.append(category)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return categories
    }
    
    func deleteAllCategories() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllCategories)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Food API
    func createFood(food: DGFood) -> Bool {
        
        if let oldFood = self.foodById(food.id) {
            food.type! |= oldFood.type!
            return self.updateFood(food)
        }
        else {
            do {
                try self.database!.executeUpdate(kDGQueryAddFood,
                                                 food.id,
                                                 food.name,
                                                 self.nullifiedObject(food.description),
                                                 self.nullifiedObject(food.commentCount),
                                                 self.nullifiedObject(food.likedCount),
                                                 self.nullifiedObject(food.rated),
                                                 self.nullifiedObject(food.categoryId),
                                                 self.nullifiedObject(food.categoryName),
                                                 self.nullifiedObject(food.photo?.name),
                                                 self.nullifiedObject(food.photo?.urlIndex),
                                                 self.nullifiedObject(food.photo?.isProccessed),
                                                 self.nullifiedObject(food.isLiked),
                                                 self.nullifiedObject(food.isFavorited),
                                                 self.nullifiedObject(food.type))
                
                return true
            }
            catch let error as NSError {
                print("failed: \(error.localizedDescription)")
                return false
            }
        }
    }
    
    func updateFood(food: DGFood) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryUpdateFood,
                                             food.name,
                                             self.nullifiedObject(food.description),
                                             self.nullifiedObject(food.commentCount),
                                             self.nullifiedObject(food.likedCount),
                                             self.nullifiedObject(food.rated),
                                             self.nullifiedObject(food.categoryId),
                                             self.nullifiedObject(food.categoryName),
                                             self.nullifiedObject(food.photo?.name),
                                             self.nullifiedObject(food.photo?.urlIndex),
                                             self.nullifiedObject(food.photo?.isProccessed),
                                             self.nullifiedObject(food.isLiked),
                                             self.nullifiedObject(food.isFavorited),
                                             self.nullifiedObject(food.type),
                                             food.id)
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func foodById(foodId: Int) -> DGFood? {
        
        do {
            let rs = try self.database!.executeQuery(kDGQueryFoodByID, foodId)
            while (rs.next()) {
                return DGFood.foodFromResultSet(rs)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return nil
    }
    
    func updateLikedFoodById(foodId: Int, isLiked: Bool) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryUpdateLikedFood,
                                             self.nullifiedObject(isLiked),
                                             foodId)
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func updateFavoritedFoodById(foodId: Int, isFavorited: Bool) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryUpdateFavoritedFood,
                                             self.nullifiedObject(isFavorited),
                                             foodId)
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func likedFoods() -> [DGFood] {
        
        var foods = [DGFood]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryLikedFoods)
            while (rs.next()) {
                let food = DGFood.foodFromResultSet(rs)
                food.prices = self.pricesByFoodId(food.id)
                foods.append(food)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return foods
    }
    
    func favoritedFoods() -> [DGFood] {
        
        var foods = [DGFood]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryFavoritedFoods)
            while (rs.next()) {
                let food = DGFood.foodFromResultSet(rs)
                food.prices = self.pricesByFoodId(food.id)
                foods.append(food)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return foods
    }
    
    func allFoods() -> [DGFood] {
        
        var foods = [DGFood]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryAllFoods)
            while (rs.next()) {
                let food = DGFood.foodFromResultSet(rs)
                food.prices = self.pricesByFoodId(food.id)
                foods.append(food)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return foods
    }
    
    func foodsByType(type: Int) -> [DGFood] {
        
        var foods = [DGFood]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryFoodByType, 1 << type)
            while (rs.next()) {
                let food = DGFood.foodFromResultSet(rs)
                food.prices = self.pricesByFoodId(food.id)
                foods.append(food)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return foods
    }
    
    func foodsByCategoryId(categoryId: Int) -> [DGFood] {
        
        var foods = [DGFood]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryFoodByCategoryID, categoryId)
            while (rs.next()) {
                let food = DGFood.foodFromResultSet(rs)
                food.prices = self.pricesByFoodId(food.id)
                foods.append(food)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return foods
    }
    
    func deleteAllFoods() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllFoods)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    func searchFoods(query: String) -> [DGFood] {
        
        var foods = [DGFood]()
        do {
            let searchPattern = "%%\(query)%%"
            let rs = try self.database!.executeQuery(kDGQuerySearchFoods, searchPattern)
            while (rs.next()) {
                let food = DGFood.foodFromResultSet(rs)
                food.prices = self.pricesByFoodId(food.id)
                foods.append(food)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return foods
    }
    
    // MARK: - Price API
    func createPrice(price: DGPrice) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryAddPrice,
                                             price.id!,
                                             price.value!,
                                             self.nullifiedObject(price.size),
                                             self.nullifiedObject(price.foodId))
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func pricesByFoodId(foodId: Int) -> [DGPrice] {
        
        var prices = [DGPrice]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryPricesByFoodId, foodId)
            while (rs.next()) {
                let price = DGPrice.priceFromResultSet(rs)
                prices.append(price)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return prices.sort({ $0.value < $1.value })
    }
    
    func deleteAllPrices() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllPrices)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Comment API
    func addComment(comment: DGComment) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryAddComment,
                                             comment.id!,
                                             comment.user!,
                                             self.nullifiedObject(comment.content),
                                             self.nullifiedObject(comment.status),
                                             comment.created,
                                             self.nullifiedObject(comment.updated),
                                             self.nullifiedObject(comment.username),
                                             comment.foodId)
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func updateComment(comment: DGComment) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryUpdateComment,
                                             comment.user,
                                             self.nullifiedObject(comment.content),
                                             self.nullifiedObject(comment.status),
                                             comment.created,
                                             self.nullifiedObject(comment.updated),
                                             self.nullifiedObject(comment.username),
                                             comment.foodId,
                                             comment.id)
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func commentsByFoodId(foodId: Int) -> [DGComment] {
        
        var comments = [DGComment]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryCommentsByFoodId, foodId)
            while (rs.next()) {
                let comment = DGComment.commentFromResultSet(rs)
                comments.append(comment)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return comments
    }
    
    func deleteCommentByID(commentId: Int) -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteCommentByID, commentId)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    func deleteAllComments() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllComments)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    // MARK: - Order API
    func createOrder(order: DGOrder) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryAddOrder,
                                             order.id,
                                             self.nullifiedObject(order.tableId),
                                             self.nullifiedObject(order.amount),
                                             self.nullifiedObject(order.totalAmount),
                                             self.nullifiedObject(order.serviceAmount),
                                             self.nullifiedObject(order.taxAmount),
                                             self.nullifiedObject(order.time),
                                             self.nullifiedObject(order.status),
                                             self.nullifiedObject(order.notes))
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func orderByID(orderID: Int) -> DGOrder? {
        
        do {
            let rs = try self.database!.executeQuery(kDGQueryOrderByID, orderID)
            while (rs.next()) {
                let order = DGOrder.orderFromResultSet(rs)
                order.items = self.orderItemsByOrderID(order.id)
                order.services = self.orderServicesByOrderID(order.id)
                order.taxes = self.orderTaxesByOrderID(order.id)
                return order
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return nil
    }
    
    func allOrders() -> [DGOrder] {
        
        var orders = [DGOrder]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryAllOrders)
            while (rs.next()) {
                let order = DGOrder.orderFromResultSet(rs)
                order.items = self.orderItemsByOrderID(order.id)
                order.services = self.orderServicesByOrderID(order.id)
                order.taxes = self.orderTaxesByOrderID(order.id)
                orders.append(order)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return orders
    }
    
    func deleteAllOrders() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllOrders)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    // MARK: - OrderItem API
    func createOrderItem(orderItem: DGOrderItem) -> Bool {
        
        do {
//            try self.database!.executeUpdate(kDGQueryAddOrderItem,
//                                             orderItem.id,
//                                             orderItem.orderId,
//                                             orderItem.foodId,
//                                             self.nullifiedObject(orderItem.foodName),
//                                             self.nullifiedObject(orderItem.cost),
//                                             self.nullifiedObject(orderItem.quantity),
//                                             self.nullifiedObject(orderItem.size),
//                                             self.nullifiedObject(orderItem.notes),
//                                             self.nullifiedObject(orderItem.lastUpdate),
//                                             orderItem.status,
//                                             self.nullifiedObject(orderItem.notes),
//                                             self.nullifiedObject(orderItem.canceledNote),
//                                             self.nullifiedObject(orderItem.rejectedNote),
//                                             self.nullifiedObject(orderItem.returnNote),
//                                             self.nullifiedObject(orderItem.tvStatus))
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func orderItemsByOrderID(orderID: Int) -> [DGOrderItem] {
        
        var orderItems = [DGOrderItem]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryOrderItemsByOrderID, orderID)
            while (rs.next()) {
                let orderItem = DGOrderItem.orderItemFromResultSet(rs)
                orderItems.append(orderItem)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return orderItems
    }
    
    func deleteAllOrderItems() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllOrderItems)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    // MARK: - OrderService API
    func createOrderService(orderService: DGOrderService) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryAddOrderService,
                                             orderService.id,
                                             self.nullifiedObject(orderService.amount),
                                             self.nullifiedObject(orderService.name),
                                             orderService.orderId)
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func orderServicesByOrderID(orderID: Int) -> [DGOrderService] {
        
        var orderServices = [DGOrderService]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryOrderServicesByOrderID, orderID)
            while (rs.next()) {
                let orderService = DGOrderService.orderServiceFromResultSet(rs)
                orderServices.append(orderService)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return orderServices
    }
    
    func deleteAllOrderServices() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllOrderServices)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
    
    // MARK: - OrderTax API
    func createOrderTax(orderTax: DGOrderTax) -> Bool {
        
        do {
            try self.database!.executeUpdate(kDGQueryAddOrderTax,
                                             orderTax.id,
                                             self.nullifiedObject(orderTax.amount),
                                             self.nullifiedObject(orderTax.name),
                                             orderTax.orderId)
            
            return true
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
            return false
        }
    }
    
    func orderTaxesByOrderID(orderID: Int) -> [DGOrderTax] {
        
        var orderTaxes = [DGOrderTax]()
        do {
            let rs = try self.database!.executeQuery(kDGQueryOrderTaxesByOrderID, orderID)
            while (rs.next()) {
                let orderTax = DGOrderTax.orderTaxFromResultSet(rs)
                orderTaxes.append(orderTax)
            }
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
        
        return orderTaxes
    }
    
    func deleteAllOrderTaxes() -> Void {
        
        do {
            try self.database!.executeUpdate(kDGQueryDeleteAllOrderTaxes)
        }
        catch let error as NSError {
            print("failed: \(error.localizedDescription)")
        }
    }
}
