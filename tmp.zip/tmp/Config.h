//
//  Config.h
//  CalcLib
//
//  Created by HauLe on 12/2/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef Config_h
#define Config_h

typedef enum  {
    SensorTypeDT1,
    SensorTypeDT2,
    SensorTypeDT3,
    SensorTypeDT4
} SensorType;

using namespace std;

namespace DT {
    
#define DT_DEFAULT_EXCEPTIONS 0
    
#ifdef _MSC_VER
    
#pragma warning( disable : 4275 )
    
// Disable the warning about debug symbols being longer than 255 characters
#pragma warning( disable : 4786 )
    
#define TEMPLATE_FUN
#define long_long __int64
#ifdef min
#  undef min
#endif
#ifdef max
#  undef max
#endif
    
    namespace std {
        template <class T>
        inline const T& min(const T& a, const T& b) {
            return b < a ? b : a;
        }
        template <class T>
        inline const T& max(const T& a, const T& b) {
            return  a < b ? b : a;
        }
    }
    
#else
    
    //! Define of TEMPLATE_FUN
#define TEMPLATE_FUN <>
    
    //! Define of long_long
#define long_long long long
    
#endif
}

#endif /* Config_h */
