//
//  DGService.swift
//  DGRestaurant
//
//  Created by Hayward on 6/25/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGService: NSObject, NSCoding {
    
    var id: Int!
    var name: String?
    var type: Int?
    var value: Float?
    var isActive: Bool?
    var isTaxed: Bool?
    
    override init() {}
    
    // MARK: NSCoding
    @objc required init(coder aDecoder: NSCoder) {
        
        id = aDecoder.decodeObjectForKey("id") as! Int
        name = aDecoder.decodeObjectForKey("name") as? String
        type = aDecoder.decodeObjectForKey("type") as? Int
        value = aDecoder.decodeObjectForKey("value") as? Float
        isActive = aDecoder.decodeObjectForKey("isActive") as? Bool
        isTaxed = aDecoder.decodeObjectForKey("isTaxed") as? Bool
    }
    
    @objc func encodeWithCoder(aCoder: NSCoder) {
        
        aCoder.encodeObject(id, forKey: "id")
        aCoder.encodeObject(name, forKey: "name")
        aCoder.encodeObject(type, forKey: "type")
        aCoder.encodeObject(value, forKey: "value")
        aCoder.encodeObject(isActive, forKey: "isActive")
        aCoder.encodeObject(isTaxed, forKey: "isTaxed")
    }
    
    // MARK: Parse JSON
    class func serviceFromJSON(json: [String: AnyObject]) -> DGService {
        
        let service = DGService()
        
        service.id = json["id"] as! Int
        service.name = json["service_name"] as? String
        service.type = json["service_type"] as? Int
        service.value = json["service_value"] as? Float
        service.isActive = json["is_active"] as? Bool
        service.isTaxed = json["is_taxed"] as? Bool
        
        return service
    }
    
    class func servicesFromJSON(json: [String: AnyObject]) -> [DGService] {
        
        var services = [DGService]()
        
        if let results = json["service"] as? [AnyObject] {
            for result in results {
                let service = DGService.serviceFromJSON(result as! [String : AnyObject])
                services.append(service)
            }
        }
        
        return services
    }
}
