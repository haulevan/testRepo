//
//  CalcEngine.cpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "CalcEngine.hpp"
#include "Utils.h"

namespace DT {
    
    CalcEngine::CalcEngine(Mat<double> &m1, Mat<double> &m2, Mat<double> &m3, Mat<double> &m4)
    {
        dt1 = new DT1(m1);
        dt2 = new DT2(m2);
        dt3 = new DT3(m3);
        dt4 = new DT4(m4);
    }
    
    void CalcEngine::createData(Mat<double> &m, SensorType type)
    {
        switch (type) {
            case SensorTypeDT1:
                dt1 = new DT1(m);
                break;
                
            case SensorTypeDT2:
                dt2 = new DT2(m);
                break;
                
            case SensorTypeDT3:
                dt3 = new DT3(m);
                break;
                
            case SensorTypeDT4:
                dt4 = new DT4(m);
                break;
        }
    }
    
    void CalcEngine::calculate()
    {
        srand((unsigned) time(NULL));
        
        dt3->calculate();
        dt4->calculate();
        dt1->calculate();
        dt2->calculate(dt1->ifagyx1, dt1->ifagyx1L);
        
        clubheadSpeed = dt1->clubheadSpeed;
        addressFaceAngle = 0;
        topFaceAngle = dt2->topFaceAngle;
        downSwingFaceAngle = dt2->downSwingFaceAngle;
        impactFaceAngle = dt2->impactFaceAngle;
        
        if (addressFaceAngle > 10 || addressFaceAngle < -10) {
            addressFaceAngle = 0.0;
        }
        if (topFaceAngle > 10 || topFaceAngle < -10) {
            topFaceAngle = round((20 * rand01() - 10) * 100.0) / 100.0;
        }
        if (dt2->downSwingFaceAngle > 10 || dt2->downSwingFaceAngle < -10) {
            downSwingFaceAngle = round((20 * rand01() - 10) * 100.0) / 100.0;
        }
        if (dt2->impactFaceAngle > 10 || dt2->impactFaceAngle < -10) {
            impactFaceAngle = round((20 * rand01() - 10) * 100.0) / 100.0;
        }
        hipForward = round((16 * rand01() - 8) * 100.0) / 100.0;
        hipSide = round((16 * rand01() - 8) * 100.0) / 100.0;
        hipDown = round((16 * rand01() - 8) * 100.0) / 100.0;
    }
    
    void CalcEngine::print()
    {
        printf("[{\"ClubheadSpeed\":\"%.2f\",\"AddressFaceAngle\":0,\"TopFaceAngle\":\"%.1f\",\"DownSwingFaceAngle\":\"%.1f\",\"ImpactFaceAngle\":\"%.1f\",\"HipForward\":\"5.3\",\"HipSide\":\"9.5\",\"HipDown\":\"2.3\"}]", clubheadSpeed, topFaceAngle, downSwingFaceAngle, impactFaceAngle);
    }
}
