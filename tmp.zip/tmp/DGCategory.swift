//
//  DGCategory.swift
//  DGRestaurant
//
//  Created by Hayward on 6/18/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGCategory {
    
    var id: Int!
    var name: String!
    var foodCount: Int?
    
    class func categoryFromJSON(json: [String: AnyObject]) -> DGCategory {
        
        let category = DGCategory()
        
        category.id = json["category_id"] as! Int
        category.name = json["category_name"] as! String
        category.foodCount = json["food_count"] as? Int
        
        return category
    }
    
    class func categoriesFromJSON(json: [String: AnyObject]) -> [DGCategory] {
        
        var categories = [DGCategory]()
        
        if let data = json["data"] as? [String: AnyObject],
            let results = data["categories"] as? [AnyObject] {
            
            for result in results {
                let category = DGCategory.categoryFromJSON(result as! [String : AnyObject])
                categories.append(category)
            }
        }
        
        return categories
    }
    
    class func categoryFromResultSet(rs: FMResultSet) -> DGCategory {
        
        let category = DGCategory()
        
        category.id = Int(rs.intForColumn("category_id"))
        category.name = rs.stringForColumn("category_name")
        category.foodCount = Int(rs.intForColumn("food_count"))
        
        return category
    }
}