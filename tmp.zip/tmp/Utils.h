//
//  Utils.h
//  CalcLib
//
//  Created by HauLe on 12/7/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef Utils_h
#define Utils_h

namespace DT {
    
    inline double rand01() {
        double r = 0;
        while (r == 0 || r == 1) {
            r = ((double)rand() / (double)RAND_MAX);
        }
        return r;
    }
    
    inline double round(double val) {
        return (val < 0) ? ceil(val - 0.5) : floor(val + 0.5);
    }
    
    inline Vec<double> findPeaks( Vec<double> data, double minHeight, int minDistance) {

        Vec<double> result;
        
        int distance = minDistance;
        int count = 0;
        
        for (int i = 1; i < data.length() - 2; i++) {
            
            // Get the value
            double previous = data[i - 1];
            double current = data[i];
            double next = data[i + 1];
            
            if (((previous < current && current > next) || (previous > current && current < next)) &&
                (current > minHeight) &&
                (distance >= minDistance)) {
                
                result[count] = current;
                
                count++;
                distance = 0;
            }
            else {
                
                distance++;
            }
        }
        return result;
    }
}

#endif /* Utils_h */
