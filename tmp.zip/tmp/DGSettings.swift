//
//  DGSettings.swift
//  DGRestaurant
//
//  Created by Hayward on 6/25/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGSettings: NSObject, NSCoding {
    var allowStaffCheckout: Bool?
    var allowCodeMenu: Bool?
    var allowPublicMenu: Bool?
    var allowTaxServiceSetting: Bool?
    var allowWifiMenu: Bool?
    var currencyType: String?
    var hasPromotion: Bool?
    var localTime: String?
    var menuAccessCode: String?
    var wifiKey: String?
    var services: [DGService]?
    var taxes: [DGTax]?
    var resInfo: DGRestaurant?
    
    override init() {}
    
    // MARK: NSCoding
    @objc required init(coder aDecoder: NSCoder) {
        allowStaffCheckout = aDecoder.decodeObjectForKey("allowStaffCheckout") as? Bool
        allowCodeMenu = aDecoder.decodeObjectForKey("allowCodeMenu") as? Bool
        allowPublicMenu = aDecoder.decodeObjectForKey("allowPublicMenu") as? Bool
        allowTaxServiceSetting = aDecoder.decodeObjectForKey("allow_tax_service_setting") as? Bool
        allowWifiMenu = aDecoder.decodeObjectForKey("allowWifiMenu") as? Bool
        currencyType = aDecoder.decodeObjectForKey("currencyType") as? String
        hasPromotion = aDecoder.decodeObjectForKey("has_promotion") as? Bool
        localTime = aDecoder.decodeObjectForKey("localTime") as? String
        menuAccessCode = aDecoder.decodeObjectForKey("menuAccessCode") as? String
        wifiKey = aDecoder.decodeObjectForKey("wifiKey") as? String
        services = aDecoder.decodeObjectForKey("services") as? [DGService]
        taxes = aDecoder.decodeObjectForKey("taxes") as? [DGTax]
        resInfo = aDecoder.decodeObjectForKey("resInfo") as? DGRestaurant
    }
    
    @objc func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(allowStaffCheckout, forKey: "allowStaffCheckout")
        aCoder.encodeObject(allowCodeMenu, forKey: "allowCodeMenu")
        aCoder.encodeObject(allowPublicMenu, forKey: "allowPublicMenu")
        aCoder.encodeObject(allowTaxServiceSetting, forKey: "allow_tax_service_setting")
        aCoder.encodeObject(allowWifiMenu, forKey: "allowWifiMenu")
        aCoder.encodeObject(currencyType, forKey: "currencyType")
        aCoder.encodeObject(hasPromotion, forKey: "has_promotion")
        aCoder.encodeObject(localTime, forKey: "localTime")
        aCoder.encodeObject(menuAccessCode, forKey: "menuAccessCode")
        aCoder.encodeObject(wifiKey, forKey: "wifiKey")
        aCoder.encodeObject(services, forKey: "services")
        aCoder.encodeObject(taxes, forKey: "taxes")
        aCoder.encodeObject(resInfo, forKey: "resInfo")
    }
    
    // MARK: Parse JSON
    class func settingsFromJSON(json: [String: AnyObject]) -> DGSettings {
        
        let setting = DGSettings()
        
        if let defaultData = json["defautl"]![0] as? [String: AnyObject] {
            setting.allowStaffCheckout = defaultData["allow_staff_checkout"] as? Bool
            setting.allowCodeMenu = defaultData["allow_code_menu"] as? Bool
            setting.allowPublicMenu = defaultData["allow_public_menu"] as? Bool
            setting.allowTaxServiceSetting = defaultData["allow_tax_service_setting"] as? Bool
            setting.allowWifiMenu = defaultData["allow_wifi_menu"] as? Bool
            setting.currencyType = defaultData["currency_type"] as? String
            setting.hasPromotion = defaultData["has_promotion"] as? Bool
            setting.localTime = defaultData["local_time"] as? String
            setting.menuAccessCode = defaultData["menu_access_code"] as? String
            setting.wifiKey = defaultData["wifi_key"] as? String
        }
        
        if let restaurantInfo = json["restaurant_info"]![0] as? [String: AnyObject] {
            setting.resInfo = DGRestaurant.restaurantFromJSON(restaurantInfo)
        }
        
        setting.services = DGService.servicesFromJSON(json)
        setting.taxes = DGTax.taxesFromJSON(json)
        
        return setting
    }
    
    // MARK: Cache data
    func cache() {
        let ud = NSUserDefaults.standardUserDefaults()
        ud.setObject(NSKeyedArchiver.archivedDataWithRootObject(self), forKey: kDGSettings)
        ud.synchronize()
    }
    
    class func getCache() -> DGSettings? {
        let ud = NSUserDefaults.standardUserDefaults()
        if let data = ud.objectForKey(kDGSettings) as? NSData {
            return NSKeyedUnarchiver.unarchiveObjectWithData(data) as? DGSettings
        }
        return nil
    }
}
