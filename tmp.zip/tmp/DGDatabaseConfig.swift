//
//  DGDatabaseConfig.swift
//  DGRestaurant
//
//  Created by Hayward on 6/27/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

let kDGDatabaseConfigFile = "database"
let kDGDatabaseConfigKeyVersion = "version"
let kDGDatabaseConfigKeySchema = "schema"

class DGDatabaseConfig {
    var dbConfig: NSDictionary?
    
    init() {
        let dbConfigFilePath = NSBundle.mainBundle().pathForResource(kDGDatabaseConfigFile, ofType: "plist")
        dbConfig = NSDictionary(contentsOfFile: dbConfigFilePath!)
    }
    
    func schemaVersion() -> Float? {
         return self.dbConfig![kDGDatabaseConfigKeyVersion]?.floatValue
    }
    
    func schema() -> String? {
        
        let schemaFile = self.dbConfig![kDGDatabaseConfigKeySchema];
        let schemaFilePath = NSBundle.mainBundle().pathForResource(schemaFile as? String, ofType:"sql")
        
        do {
            let query = try NSString(contentsOfFile: schemaFilePath!, encoding: NSUTF8StringEncoding)
            return query as String
        }
        catch {
            print("Reading SQL file failed")
            return nil;
        }
    }
}