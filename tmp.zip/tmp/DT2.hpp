//
//  DT2.hpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef DT2_hpp
#define DT2_hpp

#include "Matrix.hpp"

namespace DT
{
    class DT2
    {
    public:
        DT2(const char *fileName);
        DT2(Mat<double> &m);
        ~DT2() { delete (m); }
        
        void calculate(double ifagyx1, double ifagyx1L);
        
    public:
        Mat<double> *m;
        double addressFaceAngle;
        double topFaceAngle;
        double downSwingFaceAngle;
        double impactFaceAngle;
    };
}

#endif /* DT2_hpp */
