//
//  DGXMPPMessage.swift
//  DGRestaurant
//
//  Created by HoangPhuong on 6/17/16.
//  Copyright © 2016 home. All rights reserved.
//

import Foundation

class DGXMPPMessage{
    
    var messageType = DGMessageXMPPType.NewUser
    var order: DGOrder?
    
    class func messageFromJSON(json: [String: AnyObject]) -> DGXMPPMessage {
        
        let message = DGXMPPMessage()
        
        let messageType = json["TYPE"] as! Int
        message.messageType = DGMessageXMPPType(rawValue: messageType)!
        
        switch message.messageType {
        case .NewUser:
            break;
        case .OrderNew:
            let orderJson = json["msg"] as? [AnyObject]
            message.order = DGOrder.orderFromXMPPJSON(orderJson![0] as! [String : AnyObject])
            break;
        case .OrderUpdate:
            let orderJson = json["msg"] as? [AnyObject]
            message.order = DGOrder.orderFromXMPPJSON(orderJson![0] as! [String : AnyObject])
            break;
        case .OrderCheckourOrCancel:
            break;
        case .ChangeTable:
            break;
        case .ItemNew:
            break;
        case .ItemCanceled:
            break;
        case .TableUpdate:
            break
        }

        return message
    }
    
    class func messagesFromJSON(json: [String: AnyObject]) -> [DGXMPPMessage] {
        
        let messages = [DGXMPPMessage]()
        
//        if let results = json["foods"] as? [AnyObject] {
//            for result in results {
//                let food = DGFood.foodFromJSON(result as! [String : AnyObject])
//                foods.append(food)
//            }
//        }
//        
//        if let results = json["prices"] as? [AnyObject] {
//            for result in results {
//                let price = DGPrice.priceFromJSON(result as! [String : AnyObject])
//                let filterFoods = foods.filter {
//                    $0.id == price.foodId
//                }
//                filterFoods[0].prices?.append(price)
//                filterFoods[0].prices?.sortInPlace({ $0.value < $1.value })
//            }
//        }
        
        return messages
    }
}
