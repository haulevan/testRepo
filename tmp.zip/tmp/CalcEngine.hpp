//
//  CalcEngine.hpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef CalcEngine_hpp
#define CalcEngine_hpp

#include "DT1.hpp"
#include "DT2.hpp"
#include "DT3.hpp"
#include "DT4.hpp"

namespace DT
{
    class CalcEngine
    {
    public:
        CalcEngine(Mat<double> &m1, Mat<double> &m2, Mat<double> &m3, Mat<double> &m4);
        CalcEngine() {};
        ~CalcEngine()
        {
            delete dt1;
            delete dt2;
            delete dt3;
            delete dt4;
        }
        void createData(Mat<double> &m, SensorType type);
        void calculate(void);
        void print();
        
    public:
        DT1 *dt1;
        DT2 *dt2;
        DT3 *dt3;
        DT4 *dt4;
        
        double clubheadSpeed;
        
        double addressFaceAngle;
        double topFaceAngle;
        double downSwingFaceAngle;
        double impactFaceAngle;
        
        double hipForward;
        double hipSide;
        double hipDown;
    };
}

#endif /* CalcEngine_hpp */
