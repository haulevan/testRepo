//
//  DT4.hpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef DT4_hpp
#define DT4_hpp

#include "Matrix.hpp"

namespace DT
{
    class DT4
    {
    public:
        DT4(const char *fileName);
        DT4(Mat<double> &m);
        ~DT4() { delete (m); }
        
        void calculate(void);
        
    public:
        Mat<double> *m;
    };
}

#endif /* DT4_hpp */
