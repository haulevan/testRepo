//
//  DT1.hpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef DT1_hpp
#define DT1_hpp

#include "Matrix.hpp"

namespace DT
{
    class DT1
    {
    public:
        DT1(const char *fileName);
        DT1(Mat<double> &m);
        ~DT1() { delete (m); }
        
        void calculate(void);
        
    public:
        Mat<double> *m;
        double clubheadSpeed;
        double ifagyx1L;
        double ifagyx1;
    };
}

#endif /* DT1_hpp */
