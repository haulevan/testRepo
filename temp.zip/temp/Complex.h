//
//  Complex.h
//  CalcLib
//
//  Created by HauLe on 12/2/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef Complex_h
#define Complex_h

#include <cmath>
#include <math.h>

namespace DT {
    
    template <class T> class Complex
    {
    public:
        T re;
        T im;
        
        Complex()
        {
            re = 0;
            im = 0;
        }
        void*  operator new (size_t)
        {
            T* re = new T;
            T* im = new T;
        }
        Complex(T r, T i) :re(r), im(i) {}
        Complex(T r) : re(r), im(0) {}
        
        inline T real() { return(re);};
        inline T imag() { return(im);};
        
        friend T real( Complex<T> y ) { return(y.re);}
        friend T imag( Complex<T> y ) { return(y.im);}
        
        inline T operator=(T r)
        {
            re = r;
            im = 0;
            return r;
        }
        
        inline Complex  operator =(const Complex<T>& y)
        {
            re = (T)y.re; im = (T)y.im; return *this;
        }
        
        inline Complex  operator *=(const Complex<T>& y)
        {
            T r = re*y.re - im*y.im;
            im  = re*y.im + im*y.re;
            re = r;
            return *this;
        }
        
        inline Complex  operator +=(const Complex<T>& y)
        {
            re += y.re;
            im += y.im;
            return *this;
        }
        
        inline Complex  operator -=(const Complex<T>& y)
        {
            re -= y.re;
            im -= y.im;
            return *this;
        }
        
        operator const Complex<long> () const { return(Complex<long>((long)re,(long)im)); }
    };
    
    template <class T1, class T2> inline Complex<T1> operator *(Complex<T1> r, Complex<T2> l)
    {
        Complex<T1> x;
        x.re = ((r.re*l.re) - (r.im*l.im));
        x.im = (r.re*l.im + r.im*l.re);
        return x;
    };
    
    template <class T1, class T2> inline Complex<T1> operator +(Complex<T1> r, Complex<T2> l)
    {
        Complex<T1> x;
        x.re = r.re + l.re;
        x.im = r.im + l.im;
        return x;
    };
    
    template <class T> inline Complex<T> operator +(Complex<T> r, T l)
    {
        Complex<T> x;
        x.re = r.re + l;
        x.im = r.im;
        return x;
    };
    
    template <class T> inline Complex<T> operator +(T r, Complex<T> l)
    {
        Complex<T> x;
        x.re = r + l.re;
        x.im = l.im;
        return x;
    };
    
    template <class T1, class T2> inline Complex<T1> operator -(Complex<T1> r, Complex<T2> l)
    {
        Complex<T1> x;
        x.re = r.re - l.re;
        x.im = r.im - l.im;
        return x;
    };
    
    template <class T> inline Complex<T> operator -(Complex<T> r, T l)
    {
        Complex<T> x;
        x.re = r.re - l;
        x.im = r.im;
        return x;
    };
    
    template <class T> inline Complex<T> operator -(T r, Complex<T> l)
    {
        Complex<T> x;
        x.re = r - l.re;
        x.im = -l.im;
        return x;
    };
    
    template <class T> inline Complex<T> operator &(Complex<T> r, T l)
    {
        Complex<T> x;
        x.re = r.re & l;
        x.im = r.im & l;
        return x;
    };
    
    template <class T> inline Complex<T> operator &(T r, Complex<T> l)
    {
        Complex<T> x;
        x.re = r & l.re;
        x.im = r & l.im;
        return x;
    };
    template <class T> inline Complex<T> operator %(Complex<T> r, T l)
    {
        Complex<T> x;
        x.re = r.re % l;
        x.im = r.im % l;
        return x;
    };
    
    template <class T> inline Complex<T> operator ^(Complex<T> r, T l)
    {
        Complex<T> x;
        x.re = r.re ^ l;
        x.im = r.im ^ l;
        return x;
    };
    
    template <class T> inline Complex<T> operator ^(T r, Complex<T> l)
    {
        Complex<T> x;
        x.re = r ^ l.re;
        x.im = r ^ l.im;
        return x;
    };
    
    template <class T> inline Complex<T> operator |(Complex<T> r, T l)
    {
        Complex<T> x;
        x.re = r.re | l;
        x.im = r.im | l;
        return x;
    };
    
    template <class T> inline Complex<T> operator |(T r, Complex<T> l)
    {
        Complex<T> x;
        x.re = r | l.re;
        x.im = r | l.im;
        return x;
    };
    
    //! Left shift
    template <class T> inline Complex<T>  operator <<(Complex<T> r, const long shift)
    {
        Complex<long> res = Complex<long>(r.re << shift, r.im << shift);
        return(res);
    }
    
    //! Right shift
    template <class T> inline Complex<T>  operator >>(Complex<T> r, const long shift)
    {
        Complex<long> res = Complex<long>(r.re >> shift, r.im >> shift);
        return(res);
    }
    
    template <class T> inline Complex<T> operator -(Complex<T> r)
    {
        Complex<T> x;
        x.re = -r.re;
        x.im = -r.im;
        return x;
    };
    
    inline Complex<long> operator *( double r, Complex<long> l)
    {
        return(Complex<long>((long)floor((double)(r*l.re+0.5)),
                             (long)floor((double)(r*l.im+0.5))));
        
    };
    
    inline Complex<double> operator *( long r, Complex<double> l)
    {
        Complex<double> x;
        x.re = (r*l.re);
        x.im = (r*l.im);
        return x;
    };
    
    inline Complex<double> operator *( double r, Complex<double> l)
    {
        Complex<double> x;
        x.re = (r*l.re);
        x.im = (r*l.im);
        return x;
    };
    
    template <class T> inline Complex<T> operator *(Complex<T> r, T l)
    {
        Complex<T> x;
        x.re = r.re*l;
        x.im = r.im*l;
        return x;
    };
    
    template <class T> Complex<T> operator /(Complex<T> l, T r)
    {
        Complex<T> x(0,0);
        if (r != 0)
        {
            x.re = l.re/r;
            x.im = l.im/r;
        }
        //! else is an error condition!
        return x;
    };
    
    template <class T1, class T2> Complex<T1> operator /(Complex<T1> r, Complex<T2> l)
    {
        Complex<T1> x;
        T2 den;
        den = magsq(l);
        x = (r * conj(l))/den;
        return x;
    };
    
    template <class T1, class T2> inline bool operator ==(Complex<T1> r, Complex<T2> l)
    {
        return ((r.re == l.re) && (r.im == l.im));
    };
    
    template <class T1, class T2> inline bool operator !=(Complex<T1> r, Complex<T2> l)
    {
        return ((r.re != l.re) || (r.im != l.im));
    };
    
    //! Unit magnitude polar to rectangular conversion
    inline Complex<double> expj(double x)
    {
        Complex<double> y;
        y.re = cos(x);
        y.im = sin(x);
        return y;
    }
    
    //! Polar to rectangular conversion
    inline Complex<double> polar(double amp,double arg)
    {
        Complex<double> y;
        y.re = amp*cos(arg);
        y.im = amp*sin(arg);
        return y;
    }
    
    //! Complex value (0,1)
    template <class T> inline Complex<T> Complexj(void)
    {
        return(Complex<T>(0,1));
    }
    
    template <class T> inline T re(Complex<T> x)
    {
        T y;
        y = x.re;
        return y;
    };
    
    template <class T> inline T im(Complex<T> x)
    {
        T y;
        y = x.im;
        return y;
    };
    
    //! Conjugate
    template <class T> inline Complex<T> conj(Complex<T> x)
    {
        Complex<T> y;
        y.re = x.re;
        y.im = -x.im;
        return y;
    }
    
    //! Magnitude Squared of Complex vector
    template <class T> inline T magsq(Complex<T> x)
    {
        T y;
        y = (x.re*x.re + x.im*x.im);
        return y;
    };
    
    //! Normalized vector (magnitude = 1)
    template <class T> inline Complex<double> norm(Complex<T> x)
    {
        T y;
        y = ::sqrt(x.re*x.re + x.im*x.im);
        return (Complex<double>(x.re/y,x.im/y));
    };
    
    template <class T> inline T approx_mag(Complex<T> x)
    {
        return(MAX(abs(x.re),abs(x.im)) + MIN(abs(x.re),abs(x.im))/4);
    };
    
    template <class T> inline Complex<T> maxvalue(Complex<T> x1)
    {
        return(Complex<T>(MAX(x1.re,x1.im)));
    };
    
    template <class T> inline Complex<T> minimum(Complex<T> x1, Complex<T> x2)
    {
        return(Complex<T>(MIN(x1.re,x2.re),MIN(x1.im,x2.im)));
    }
    template <class T> inline Complex<T> maximum(Complex<T> x1, Complex<T> x2)
    {
        return(Complex<T>(MAX(x1.re,x2.re), MAX(x1.im,x2.im)));
    };
    
    //! Return phase angle (radians) of Complex number
    template <class T> inline double arg(const Complex<T> x)
    {
        double TMPANG;
        if (real(x) == 0) {
            if (imag(x) < 0) return(3.0*M_PI/2.0);
            else return(M_PI/2.0);
        } else {
            TMPANG=atan((double)imag(x)/(double)real(x));
            if (real(x) < 0) TMPANG -= M_PI;
            if (TMPANG < 0) TMPANG += M_PI*2;
        }
        return(TMPANG);
    }
    
    //! Convert to Complex<double>
    template <class T> inline Complex<double> rational(Complex<T> l)
    {
        return(Complex<double>((double)l.re,(double)l.im));
    }
    
    //! Round by bits, to near integer - return(Complex<long>)
    inline Complex<long> round(Complex<long> in, long bits)
    {
        double scale = 1.0/(double)(1 << bits);
        return(Complex<long>((long)floor((double)(scale*in.re)+0.5),
                             (long)floor((double)(scale*in.im)+0.5)));
    }
    
    //! Saturate to specific number of bits (signed)
    inline Complex<long> saturate(Complex<long> in, long bits)
    {
        Complex<long> out;
        long low_mask = ((1<<(bits-1)) - 1);
        if (labs(in.re) > low_mask) out.re = (in.re>0) ? low_mask : ~low_mask;
        else out.re = in.re;
        if (labs(in.im) > low_mask) out.im = (in.im>0) ? low_mask : ~low_mask;
        else out.im = in.im;
        return(out);
    }
    
    template <class T> Complex<T> signbit(Complex<T> in)
    {
        return(Complex<T>(SGN(in.re),SGN(in.im)));
    }
    
    //template <class T> T real(Complex<T>& y) {  return(y.re);}
    //template <class T> T imag(Complex<T>& y) {  return(y.im);}
    
    template <class T> inline Complex<double> reciprocal(Complex<T> x)
    {
        T y;
        y = (x.re*x.re + x.im*x.im);
        return (Complex<double>(x.re/y,-x.im/y));
    };
    
    //! squaring function
    template <class T> inline Complex<T> sqr(Complex<T> x)
    {
        return (x*x);
    };
    
    //! square root function (same as sqrt in spuc_math.h)
    template <class T> inline Complex<double> csqrt(Complex<T> x)
    {
        double mag = sqrt(sqrt(magsq(x)));
        double ang = 0.5*arg(x); // ambiguity
        return(polar(mag,ang));
    };
    
    //! Complex exponential
    inline Complex<double> exp(Complex<double> x)
    { 
        return (::exp(x.real()) * expj(x.imag()));
    }
    
    //! same name as math library
    inline double hypot(Complex<double> z)
    {
        double _hypot(double x, double y);
        return _hypot(z.imag(), z.real());
    }
}

#endif /* Complex_h */
