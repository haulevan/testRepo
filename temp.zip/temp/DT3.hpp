//
//  DT3.hpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef DT3_hpp
#define DT3_hpp

#include "Matrix.hpp"

namespace DT
{
    class DT3
    {
    public:
        DT3(const char *fileName);
        DT3(Mat<double> &m);
        ~DT3() { delete (m); }
        
        void calculate(void);
        
    public:
        Mat<double> *m;
    };
}

#endif /* DT3_hpp */
