//
//  CalcEngine.cpp
//  CalcLib
//
//  Created by HauLe on 12/4/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "CalcEngine.hpp"

namespace DT {
    
    CalcEngine::CalcEngine(Mat<double> &m1, Mat<double> &m2, Mat<double> &m3, Mat<double> &m4)
    {
        dt1 = new DT1(m1);
        dt2 = new DT2(m2);
        dt3 = new DT3(m3);
        dt4 = new DT4(m4);
    }
    
    void CalcEngine::calculate()
    {
        dt3->calculate();
        dt4->calculate();
        dt1->calculate();
        dt2->calculate();
        
        if (dt2->addressFaceAngle > 10 || dt2->addressFaceAngle < -10) {
            addressFaceAngle = 0.0;
        }
        if (dt2->topFaceAngle > 10 || dt2->topFaceAngle < -10) {
            topFaceAngle = 0.0;
        }
        if (dt2->downSwingFaceAngle > 10 || dt2->downSwingFaceAngle < -10) {
            downSwingFaceAngle = 0.0;
        }
        if (dt2->impactFaceAngle > 10 || dt2->impactFaceAngle < -10) {
            impactFaceAngle = 0.0;
        }
        hipForward = 0;
        hipSide = 0;
        hipDown = 0;
    }
}
