//
//  Assert.hpp
//  CalcLib
//
//  Created by HauLe on 12/2/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#ifndef Assert_hpp
#define Assert_hpp

#include <iostream>
#include <string>

namespace DT {
    
    using std::string;
    
    //! Helper function for the \c dt_assert functions
    void dt_assert_f(string ass, string msg, string file, int line);
    //! Helper function for the \c dt_error functions
    void dt_error_f(string msg, string file, int line);
    //! Helper function for the \c dt_warning functions
    void dt_warning_f(string msg, string file, int line);
    
    //! Enable/disable using exceptions for error handling.
    void dt_enable_exceptions(bool on);
    //! Enable warnings
    void dt_enable_warnings();
    //! Disable warnings
    void dt_disable_warnings();
    
#if ASSERT_LEVEL==0 // No tests
#  define dt_assert0(t,s) ((void)0)
#  define dt_assert1(t,s) ((void)0)
#elif ASSERT_LEVEL==1 // Only some tests
#  define dt_assert0(t,s) ((void)0)
#  define dt_assert1(t,s) (void)((t) || (dt_assert_f(#t,s,__FILE__,__LINE__),0))
#else // Full tests
    //! Abort if \c t is not true and IT++ is compiled with \c -DASSERT_LEVEL = 2. The message string \c s is printed on standard output.
#  define dt_assert0(t,s) (void)((t) || (dt_assert_f(#t,s,__FILE__,__LINE__),0))
    //! Abort if \c t is not true and IT++ is compiled with \c -DASSERT_LEVEL = 1 or 2. The message string \c s is printed on standard output.
#  define dt_assert1(t,s) (void)((t) || (dt_assert_f(#t,s,__FILE__,__LINE__),0))
#endif // ASSERT_LEVEL
    
    //! Abort if \c t is NOT true and output \c s
#define dt_assert(t,s)   (void)((t) || (dt_assert_f(#t,s,__FILE__,__LINE__),0))
    //! Abort if \c t is true and output \c s
#define dt_error_if(t,s) (void)((!(t)) || (dt_error_f(s,__FILE__,__LINE__),0))
    //! Abort and output \c s
#define dt_error(s)      dt_error_f(s,__FILE__,__LINE__)
    //! Output the warning \c s
#define dt_warning(s)    dt_warning_f(s,__FILE__,__LINE__)
}

#endif /* Assert_hpp */
