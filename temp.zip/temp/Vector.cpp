//
//  Vector.cpp
//  CalcLib
//
//  Created by HauLe on 12/2/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "Vector.hpp"

using namespace DT;
using namespace std;

template <class T>
ostream &operator<<(ostream& os, const Vec<T> &v)
{
    int i, sz=v.length();
    
    os << "[" ;
    for (i=0; i<sz; i++) {
        os << v(i);
        if (i < sz-1)
            os << " ";
    }
    os << "]" ;
    
    return os;
}

template <class T>
istream &operator>>(istream& is, Vec<T> &v)
{
    string str;
    
    getline(is, str);
    if (is.eof())
        v.set_size(0, false);
    else
        v.set(str);
    
    return is;
}
