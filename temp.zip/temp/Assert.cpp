//
//  Assert.cpp
//  CalcLib
//
//  Created by HauLe on 12/2/16.
//  Copyright © 2016 DuoTrac. All rights reserved.
//

#include "Assert.hpp"
#include "Config.h"

using namespace std;

static bool warnings_enabled = true;
static bool dt_using_exceptions = DT_DEFAULT_EXCEPTIONS;

namespace DT {
    
    void dt_assert_f(string ass, string msg, string file, int line)
    {
        char line_str[100];
        
        string error = "*** Assertation failed in ";
        error += file;
        error += " on line ";
        sprintf(line_str, "%d", line);
        error += line_str;
        error += ":\n";
        error += msg;
        error += " (";
        error += ass;
        error += ")";
        cerr << error << endl << flush;
        if (dt_using_exceptions)	throw runtime_error(error);
        else
        abort();
    }
    
    void dt_error_f(string msg, string file, int line)
    {
        char line_str[100];
        
        string error = "*** Error in ";
        error += file;
        error += " on line ";
        sprintf(line_str, "%d", line);
        error += line_str;
        error += ":";
        error += msg;
        cerr << error << endl << flush;
        if (dt_using_exceptions)	throw runtime_error(error);
        else
        abort();
    }
    
    void dt_warning_f(string msg, string file, int line)
    {
        if (warnings_enabled)
            cerr << "*** Warning in " << file << " on line " << line << ":" << endl
            << msg << endl << flush;
    }
    
    void dt_enable_exceptions(bool on)
    {
        dt_using_exceptions = on;
    }
    
    void dt_enable_warnings()
    {
        warnings_enabled = true;
    }
    
    void dt_disable_warnings()
    {
        warnings_enabled = false;
    }
}
