//
//  Phone.swift
//  AlamofireSwiftyJSONSample
//
//  Created by rec12 on 4/12/16.
//  Copyright © 2016 Wayfarer. All rights reserved.
//

import Foundation

struct Phone {
    var mobile: String?
    var home: String?
    var office: String?
}