//
//  ViewController.swift
//  AlamofireSwiftyJSONSample
//
//  Created by Hayward on 4/11/16.
//  Copyright © 2016 Wayfarer. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    var arrRes = [[String:AnyObject]]() //Array of dictionary

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        Alamofire.request(.GET, "http://api.androidhive.info/contacts/").responseJSON { (req, res, json) -> Void in
            let swiftyJsonVar = JSON(json.value!)
            
            if let resData = swiftyJsonVar["contacts"].arrayObject {
                self.arrRes = resData as! [[String:AnyObject]]
            }
            if self.arrRes.count > 0 {
                self.tableView.reloadData()
            }
        }
        
//        Alamofire.request(.GET, "http://api.androidhive.info/contacts/").response { (req, res, data, error) -> Void in
////            print(res)
////            let outputString = NSString(data: data!, encoding:NSUTF8StringEncoding)
////            print(outputString)
//            let json = JSON(data: data!)
//            if let resData = json["contacts"].arrayObject {
//                self.arrRes = resData as! [[String:AnyObject]]
//            }
//            if self.arrRes.count > 0 {
//                self.tableView.reloadData()
//            }
//        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell : UITableViewCell = tableView.dequeueReusableCellWithIdentifier("jsonCell")!
        var dict = arrRes[indexPath.row]
        cell.textLabel?.text = dict["name"] as? String
        cell.detailTextLabel?.text = dict["email"] as? String
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrRes.count
    }
}

