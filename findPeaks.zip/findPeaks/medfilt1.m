%! #----------------------------------------------------------------------------
function y = medfilt1(x,n,blksz,DIM)
%MEDFILT1  One dimensional median filter.
%   Y = MEDFILT1(X,N) returns the output of the order N, one dimensional
%   median filtering of X.  Y is the same size as X; for the edge points,
%   zeros are assumed to the left and right of X.  If X is a matrix,
%   then MEDFILT1 operates along the columns of X.
%
%   If you do not specify N, MEDFILT1 uses a default of N = 3.
%   For N odd, Y(k) is the median of X( k-(N-1)/2 : k+(N-1)/2 ).
%   For N even, Y(k) is the median of X( k-N/2 : k+N/2-1 ).
%
%   Y = MEDFILT1(X,N,BLKSZ) uses a for-loop to compute BLKSZ ("block size") 
%   output samples at a time.  Use this option with BLKSZ << LENGTH(X) if 
%   you are low on memory (MEDFILT1 uses a working matrix of size
%   N x BLKSZ).  By default, BLKSZ == LENGTH(X); this is the fastest
%   execution if you have the memory for it.
%
%   For matrices and N-D arrays, Y = MEDFILT1(X,N,[],DIM) or 
%   Y = MEDFILT1(X,N,BLKSZ,DIM) operates along the dimension DIM.
%
%   See also MEDIAN, FILTER, SGOLAYFILT, and MEDFILT2 in the Image
%   Processing Toolbox.

%   Author(s): L. Shure and T. Krauss, 8-3-93
%   Copyright 1988-2004 The MathWorks, Inc.
%   $Revision: 1.8.4.4 $  $Date: 2009/08/11 15:47:50 $

% Validate number of input arguments
error(nargchk(1,4,nargin,'struct'));
if nargin < 2, n = []; end
if nargin < 3, blksz = []; end
if nargin < 4, DIM = []; end

% Check the input data type. Single precision is not supported.
try
    chkinputdatatype(x,n,blksz,DIM);
catch ME
    throwAsCaller(ME);
end

% Check if the input arguments are valid
if isempty(n)
  n = 3;
end

if ~isempty(DIM) && DIM > ndims(x)
  error(generatemsgid('InvalidDimensions'),'Dimension specified exceeds the dimensions of X.')
end

% Reshape x into the right dimension.
if isempty(DIM)
  % Work along the first non-singleton dimension
  [x, nshifts] = shiftdim(x);
else
  % Put DIM in the first (row) dimension (this matches the order 
  % that the built-in filter function uses)
  perm = [DIM,1:DIM-1,DIM+1:ndims(x)];
  x = permute(x,perm);
end

% Verify that the block size is valid.
siz = size(x);
if isempty(blksz),
  blksz = siz(1); % siz(1) is the number of rows of x (default)
else
  blksz = blksz(:);
end

% Initialize y with the correct dimension
y = zeros(siz); 

% Call medfilt1D (vector)
for i = 1:prod(siz(2:end)),
  y(:,i) = medfilt1D(x(:,i),n,blksz);
end

% Convert y to the original shape of x
if isempty(DIM)
  y = shiftdim(y, -nshifts);
else
  y = ipermute(y,perm);
end


%-------------------------------------------------------------------
%                       Local Function
%-------------------------------------------------------------------
function y = medfilt1D(x,n,blksz)
%MEDFILT1D  One dimensional median filter.
%
% Inputs:
%   x     - vector
%   n     - order of the filter
%   blksz - block size

nx = length(x);
if rem(n,2)~=1    % n even
    m = n/2;
else
    m = (n-1)/2;
end
X = [zeros(m,1); x; zeros(m,1)];
y = zeros(nx,1);

% Work in chunks to save memory
indr = (0:n-1)';  %'
indc = 1:nx;
for i=1:blksz:nx
    ind = indc(ones(1,n),i:min(i+blksz-1,nx)) + ...
          indr(:,ones(1,min(i+blksz-1,nx)-i+1));
    xx = reshape(X(ind),n,min(i+blksz-1,nx)-i+1);
    y(i:min(i+blksz-1,nx)) = median(xx,1);
end

%! #----------------------------------------------------------------------------
function y = medfilt1(x,n)

% Check if the input arguments are valid
if isempty(n)
  n = 3;
end

% Reshape x into the right dimension.
% Work along the first non-singleton dimension
[x, nshifts] = shiftdim(x);

% Verify that the block size is valid.
siz = size(x);
blksz = siz(1); % siz(1) is the number of rows of x (default)

% Initialize y with the correct dimension
y = zeros(siz); 

% Call medfilt1D (vector)
for i = 1:prod(siz(2:end)),
  y(:,i) = medfilt1D(x(:,i),n,blksz);
end

% Convert y to the original shape of x
if isempty(DIM)
  y = shiftdim(y, -nshifts);
else
  y = ipermute(y,perm);
end

%! #----------------------------------------------------------------------------
[B,nshifts] = shiftdim(X) returns the array B with the same number of elements as X but with any leading singleton dimensions removed. A singleton dimension is any dimension for which size(A,dim) = 1. nshifts is the number of dimensions that are removed.
n = 3;
[x, nshifts] = shiftdim(x); => x = x; nshifts = 0;
siz = size(x); => [x.size() 1] for column vector, [1 x.size()] for row vector
blksz = siz(1); => blksz = x.size()
y = zeros(siz); => column vector fill 0
prod(siz(2:end)) => 1 for column vector








%! #----------------------------------------------------------------------------
function [y, ns]  = shiftdim1 (x, n)

  if (nargin < 1 || nargin > 2)
    print_usage ();
  endif

  nd = ndims (x);
  orig_dims = size (x);

  if (nargin == 1)
    ## Find the first non-singleton dimension.
    (n = find (orig_dims != 1, 1) - 1) || (n = nd);
  elseif (! (isscalar (n) && n == fix (n)))
    error ("shiftdim: N must be a scalar integer");
  endif

  if (n >= nd)
    n = rem (n, nd);
  endif

  if (n < 0)
    singleton_dims = ones (1, -n);
    y = reshape (x, [singleton_dims, orig_dims]);
  elseif (n > 0)
    ## We need permute here instead of reshape to shift values in a
    ## compatible way.
    y = permute (x, [n+1:nd 1:n]);
  else
    y = x;
  endif

  ns = n;

endfunction

///////////////////////////////////////////////////////////////////////////////

nd = ndims (x); => nd = 2; // is alway 2
orig_dims = size (x); => [x.size() 1] for column vector, [1 x.size()] for row vector
****** sz = size(A) returns a row vector whose elements contain the length of the corresponding dimension of A.
(n = find (orig_dims != 1, 1) - 1) || (n = nd); => n = 2 for column vector; n = 1 for row vector;
if (n >= nd)
  n = rem (n, nd); => n = 0
else
  n will = 1;

=> y = x; ns = n; // 0 or 1