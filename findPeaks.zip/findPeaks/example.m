function [pks idx varargout] = findpeaks (data, varargin)

  if (nargin < 1)
    print_usage ();
  endif

  if (! (isvector (data) && numel (data) >= 3))
    error ("findpeaks:InvalidArgument",
           "findpeaks: DATA must be a vector of at least 3 elements");
  endif

  transpose = (rows (data) == 1);

  if (transpose)
    data = data.';
  endif

  ## --- Parse arguments --- #
  __data__ = abs (detrend (data, 0));

  posscal = @(x) isscalar (x) && x >= 0;

  parser = inputParser ();
  parser.FunctionName = "findpeaks";

  ## FIXME: inputParser was first implemented in the general package in the
  ##        old @class type.  This allowed for a very similar interface to
  ##        Matlab but not quite equal.  classdef was then implemented in
  ##        Octave 4.0 release, which enabled inputParser to be implemented
  ##        properly.  However, this causes problem because we don't know
  ##        what implementation may be running.  A new version of the general
  ##        package is being released to avoid the two implementations to
  ##        co-exist.
  ##
  ##        To keep supporting older octave versions, we have an alternative
  ##        path that avoids inputParser.  And if inputParser is available,
  ##        we check what implementation is is, and act accordingly.

  ## Note that in Octave 4.0, inputParser is classdef and Octave behaves
  ## weird for it. which ("inputParser") will return empty (thinks its a
  ## builtin function).
  if (exist ("inputParser") == 2
      && isempty (strfind (which ("inputParser"),
                           ["@inputParser" filesep "inputParser.m"])))
    ## making use of classdef's inputParser ..
    parser.addParamValue ("MinPeakHeight", 2*std (__data__),posscal);
    parser.addParamValue ("MinPeakDistance", 4, posscal);
    parser.addParamValue ("MinPeakWidth", 2, posscal);
    parser.addSwitch ("DoubleSided");
    parser.parse (varargin{:});
    minH      = parser.Results.MinPeakHeight;
    minD      = parser.Results.MinPeakDistance;
    minW      = parser.Results.MinPeakWidth;
    dSided    = parser.Results.DoubleSided;
  else
    ## either old @inputParser or no inputParser at all...
    lvarargin = lower (varargin);

    ds = strcmpi (lvarargin, "DoubleSided");
    if (any (ds))
      dSided = true;
      lvarargin(ds) = [];
    else
      dSided = false;
    endif

    [~, minH, minD, minW] = parseparams (lvarargin,
                                         "minpeakheight", 2 * std (__data__),
                                         "minpeakdistance", 4,
                                         "minpeakwidth", 2);
    if (! posscal (minH))
      error ("findpeaks: MinPeakHeight must be a positive scalar");
    elseif (! posscal (minD))
      error ("findpeaks: MinPeakDistance must be a positive scalar");
    elseif (! posscal (minW))
      error ("findpeaks: MinPeakWidth must be a positive scalar");
    endif
  endif


  if (dSided)
    [data, __data__] = deal (__data__, data);
  elseif (min (data) < 0)
    error ("findpeaks:InvalidArgument",
           'Data contains negative values. You may want to "DoubleSided" option');
  endif

  ## Rough estimates of first and second derivative
  df1 = diff (data, 1)([1; (1:end)']);
  df2 = diff (data, 2)([1; 1; (1:end)']);

  ## check for changes of sign of 1st derivative and negativity of 2nd
  ## derivative.
  ## <= in 1st derivative includes the case of oversampled signals.
  idx = find (df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0);

  ## Get peaks that are beyond given height
  tf  = data(idx) > minH;
  idx = idx(tf);

  ## sort according to magnitude
  [~, tmp] = sort (data(idx), "descend");
  idx_s = idx(tmp);

  ## Treat peaks separated less than minD as one
  D = abs (bsxfun (@minus, idx_s, idx_s'));
  if (any (D(:) < minD))

    i = 1;
    peak = cell ();
    node2visit = 1:size(D,1);
    visited = [];
    idx_pruned = idx_s;

    ## debug
##    h = plot(1:length(data),data,"-",idx_s,data(idx_s),'.r',idx_s,data(idx_s),'.g');
##    set(h(3),"visible","off");

    while (! isempty (node2visit))

      d = D(node2visit(1),:);

      visited = [visited node2visit(1)];
      node2visit(1) = [];

      neighs  = setdiff (find (d < minD), visited);
      if (! isempty (neighs))
        ## debug
##        set(h(3),"xdata",idx_s(neighs),"ydata",data(idx_s(neighs)),"visible","on")
##        pause(0.2)
##        set(h(3),"visible","off");

        idx_pruned = setdiff (idx_pruned, idx_s(neighs));

        visited    = [visited neighs];
        node2visit = setdiff (node2visit, visited);

        ## debug
##        set(h(2),"xdata",idx_pruned,"ydata",data(idx_pruned))
##        pause
      endif

    endwhile
    idx = idx_pruned;
  endif

  extra = struct ("parabol", [], "height", [], "baseline", [], "roots", []);

  ## Estimate widths of peaks and filter for:
  ## width smaller than given.
  ## wrong concavity.
  ## not high enough
  ## data at peak is lower than parabola by 1%
  if (minW > 0)
    ## debug
##    h = plot(1:length(data),data,"-",idx,data(idx),'.r',...
##          idx,data(idx),'og',idx,data(idx),'-m');
##    set(h(4),"linewidth",2)
##    set(h(3:4),"visible","off");

    idx_pruned = idx;
    n  = numel (idx);
    np = numel (data);
    struct_count = 0;
    for i=1:n
      ind = (round (max(idx(i)-minD/2,1)) : ...
             round (min(idx(i)+minD/2,np)))';
      pp = polyfit (ind, data(ind), 2);
      H  = pp(3) - pp(2)^2/(4*pp(1));

      ## debug
##      x = linspace(ind(1)-1,ind(end)+1,10);
##      set(h(4),"xdata",x,"ydata",polyval(pp,x),"visible","on")
##      set(h(3),"xdata",ind,"ydata",data(ind),"visible","on")
##      pause(0.2)
##      set(h(3:4),"visible","off");

      rz = roots ([pp(1:2) pp(3)-mean([H,minH])]);
      width = abs (diff (rz));
      if (width < minW || pp(1) > 0 || H < minH || data(idx(i)) < 0.99*H)
        idx_pruned = setdiff (idx_pruned, idx(i));
      elseif (nargout > 2)
        struct_count++;
        extra.parabol(struct_count).x  = ind([1 end]);
        extra.parabol(struct_count).pp = pp;

        extra.roots(struct_count,1:2)= rz;
        extra.height(struct_count)   = H;
        extra.baseline(struct_count) = mean ([H minH]);
      endif

      ## debug
##      set(h(2),"xdata",idx_pruned,"ydata",data(idx_pruned))
##      pause(0.2)

    endfor
    idx = idx_pruned;
  endif


  if (dSided)
    pks = __data__(idx);
  else
    pks = data(idx);
  endif

  if (transpose)
    pks = pks.';
    idx = idx.';
  endif

  if (nargout() > 2)
    varargout{1} = extra;
  endif

endfunction

///////////////////////////////////////////////////////////////////////////////

data = [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];
y = data - ones(10,1)*mean(data);
__data__ = abs(y)

[data, __data__] = deal (__data__, data);
df1 = diff (data, 1)([1; (1:end)']);
df2 = diff (data, 2)([1; 1; (1:end)']);
idx = find (df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0);

diff(data, 1) = diff(data)
diff (data, 2) = diff(diff (data, 1))
([1; (1:end)']) => create column vector with row 0 is first value & column value
([1; 1; (1:end)']) => create column vector with row 0 & row 1 is first value & column value

df1
  -1  
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   1 

diff(data, 2)
   0                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   0

df2
   0                                                                                                
   0 
   0                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   0

idx = find (df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0);
[df1(2:end); 0] => column vector with df1 value 2->end & append 0 value
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
  -1                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   0
df1.*[df1(2:end); 0] => create vector with dot element.   
   1                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   1                                                                                                
   0

[df2(2:end); 0]
   0                                                                                                
   0                                                                                                
   0                                                                                                
   0                                                                                                
   1                                                                                                
   1                                                                                                
   0                                                                                                
   0                                                                                                
   0                                                                                                
   0
df1.*[df1(2:end); 0] <= 0 => create vector with boolean value for value <= 0
[df2(2:end); 0] < 0 => create vector with boolean value for value < 0
df1.*[df1(2:end); 0] <= 0 & [df2(2:end); 0] < 0 => & logic each element and return vector with value is index for element has logic true
=> idx: vector with index of value has logic true [5 6 10]

tf  = data(idx) > minH; => filter data by index > minH, return vector with boolean value for this condition. [0 0 1]
idx = idx(tf); => filter index that has boolean is true (return vector with value is index that boolean is true) [10]

## sort according to magnitude
  [~, tmp] = sort (data(idx), "descend"); => sort descend data by idx and return vector index after sorted [3 1 2]
  idx_s = idx(tmp); => arrange idx value by sorted index [10 5 6]

## Treat peaks separated less than minD as one
D = abs (bsxfun (@minus, idx_s, idx_s'));           //'

[10; 5; 6] - [10 5 6]
0   5   4
-5  0   -1
-4  1   0
Mat(3,3);
for i=0; i<3; i++
  for j=0; j<3; j++
    a[i][j] = v[i]-v[j]

##
if (any (D(:) < minD)) => exist any element < minD
peak = cell (); => create array empty
node2visit = 1:size(D,1); => return vector with value from 1->size of D (1,2,3)
d = D(node2visit(1),:); => d is first row of D
visited = [visited node2visit(1)]; => append node2visit(1) to visited
node2visit(1) = []; => remove node2visit(1) on node2visit => [2, 3]
neighs  = setdiff (find (d < minD), visited); => find index d < minD, filter data in result and not in visited, then sort results
% C = setdiff(A,B) returns the data in A that is not in B, with no repetitions. C is in sorted order. (ascend)
idx_pruned = setdiff (idx_pruned, idx_s(neighs)); => idx_s(neighs): return vector by index on neighs
visited    = [visited neighs]; => append neighs to visited
node2visit = setdiff (node2visit, visited);
n  = numel (idx); => number of element in array

ind = (round (max(idx(i)-minD/2,1)) : ...
             round (min(idx(i)+minD/2,np)))';   '=> vector value from min -> max

pp = polyfit (ind, data(ind), 2);   => get polyfit vector
H  = pp(3) - pp(2)^2/(4*pp(1));

rz = roots ([pp(1:2) pp(3)-mean([H,minH])]);
[pp(1:2) pp(3)-mean([3,0.1])] => vector {pp(1), pp(2), pp(3)-mean([3,0.1])}
=> vector with roots

width = abs (diff (rz));
if (width < minW || pp(1) > 0 || H < minH || data(idx(i)) < 0.99*H)
        idx_pruned = setdiff (idx_pruned, idx(i));

==============================================
  template<class T> inline
    Vec<T> Vec<T>::detrend(void)
    {
        Vec<T> temp(datasize);
        T meanVal = mean();
        for (int i=0; i<datasize; i++) {
            temp[i] = data[i] - meanVal;
        }
        return temp;
    }
==============================================

%! #----------------------------------------------------------------------------

https://www.jdoodle.com/execute-octave-matlab-online
http://cpp.sh/

%! #----------------------------------------------------------------------------
function p = fPolyFit(x, y, n)
% Construct Vandermonde matrix:
x = x(:);
V = ones(length(x), n + 1);
for j = n:-1:1
   V(:, j) = V(:, j + 1) .* x;
end
% Solve least squares problem:
[Q, R] = qr(V, 0);
p      = transpose(R \ (transpose(Q) * y(:)));
endfunction

%! #----------------------------------------------------------------------------
http://www.bragitoff.com/2015/09/c-program-for-polynomial-fit-least-squares/
%! #----------------------------------------------------------------------------
//Polynomial Fit
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main()
{
    int i,j,k,n,N;
    cout.precision(4);                        //set precision
    cout.setf(ios::fixed);
    cout<<"\nEnter the no. of data pairs to be entered:\n";        //To find the size of arrays that will store x,y, and z values
    cin>>N;
    double x[N],y[N];
    cout<<"\nEnter the x-axis values:\n";                //Input x-values
    for (i=0;i<N;i++)
        cin>>x[i];
    cout<<"\nEnter the y-axis values:\n";                //Input y-values
    for (i=0;i<N;i++)
        cin>>y[i];
    cout<<"\nWhat degree of Polynomial do you want to use for the fit?\n";
    cin>>n;                                // n is the degree of Polynomial 
    double X[2*n+1];                        //Array that will store the values of sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
    for (i=0;i<2*n+1;i++)
    {
        X[i]=0;
        for (j=0;j<N;j++)
            X[i]=X[i]+pow(x[j],i);        //consecutive positions of the array will store N,sigma(xi),sigma(xi^2),sigma(xi^3)....sigma(xi^2n)
    }
    double B[n+1][n+2],a[n+1];            //B is the Normal matrix(augmented) that will store the equations, 'a' is for value of the final coefficients
    for (i=0;i<=n;i++)
        for (j=0;j<=n;j++)
            B[i][j]=X[i+j];            //Build the Normal matrix by storing the corresponding coefficients at the right positions except the last column of the matrix
    double Y[n+1];                    //Array to store the values of sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
    for (i=0;i<n+1;i++)
    {    
        Y[i]=0;
        for (j=0;j<N;j++)
        Y[i]=Y[i]+pow(x[j],i)*y[j];        //consecutive positions will store sigma(yi),sigma(xi*yi),sigma(xi^2*yi)...sigma(xi^n*yi)
    }
    for (i=0;i<=n;i++)
        B[i][n+1]=Y[i];                //load the values of Y as the last column of B(Normal Matrix but augmented)
    n=n+1;                //n is made n+1 because the Gaussian Elimination part below was for n equations, but here n is the degree of polynomial and for n degree we get n+1 equations
    cout<<"\nThe Normal(Augmented Matrix) is as follows:\n";    
    for (i=0;i<n;i++)            //print the Normal-augmented matrix
    {
        for (j=0;j<=n;j++)
            cout<<B[i][j]<<setw(16);
        cout<<"\n";
    }    
    for (i=0;i<n;i++)                    //From now Gaussian Elimination starts(can be ignored) to solve the set of linear equations (Pivotisation)
        for (k=i+1;k<n;k++)
            if (B[i][i]<B[k][i])
                for (j=0;j<=n;j++)
                {
                    double temp=B[i][j];
                    B[i][j]=B[k][j];
                    B[k][j]=temp;
                }
    
    for (i=0;i<n-1;i++)            //loop to perform the gauss elimination
        for (k=i+1;k<n;k++)
            {
                double t=B[k][i]/B[i][i];
                for (j=0;j<=n;j++)
                    B[k][j]=B[k][j]-t*B[i][j];    //make the elements below the pivot elements equal to zero or elimnate the variables
            }
    for (i=n-1;i>=0;i--)                //back-substitution
    {                        //x is an array whose values correspond to the values of x,y,z..
        a[i]=B[i][n];                //make the variable to be calculated equal to the rhs of the last equation
        for (j=0;j<n;j++)
            if (j!=i)            //then subtract all the lhs values except the coefficient of the variable whose value                                   is being calculated
                a[i]=a[i]-B[i][j]*a[j];
        a[i]=a[i]/B[i][i];            //now finally divide the rhs by the coefficient of the variable to be calculated
    }
    cout<<"\nThe values of the coefficients are as follows:\n";
    for (i=0;i<n;i++)
        cout<<"x^"<<i<<"="<<a[i]<<endl;            // Print the values of x^0,x^1,x^2,x^3,....

    cout<<"\nHence the fitted Polynomial is given by:\ny=";
    for (i=0;i<n;i++)
        cout<<" + ("<<a[i]<<")"<<"x^"<<i;
    cout<<"\n";
    return 0;
}//output attached as .jpg

%! #----------------------------------------------------------------------------
https://www.programiz.com/cpp-programming/examples/quadratic-roots
%! #----------------------------------------------------------------------------
#include <iostream>
#include <cmath>
using namespace std;

int main() {

    float a, b, c, x1, x2, determinant, realPart, imaginaryPart;
    cout << "Enter coefficients a, b and c: ";
    cin >> a >> b >> c;
    determinant = b*b - 4*a*c;
    
    if (determinant > 0) {
        x1 = (-b + sqrt(determinant)) / (2*a);
        x2 = (-b - sqrt(determinant)) / (2*a);
        cout << "Roots are real and different." << endl;
        cout << "x1 = " << x1 << endl;
        cout << "x2 = " << x2 << endl;
    }
    
    else if (determinant == 0) {
        cout << "Roots are real and same." << endl;
        x1 = (-b + sqrt(determinant)) / (2*a);
        cout << "x1 = x2 =" << x1 << endl;
    }

    else {
        realPart = -b/(2*a);
        imaginaryPart =sqrt(-determinant)/(2*a);
        cout << "Roots are complex and different."  << endl;
        cout << "x1 = " << realPart << "+" << imaginaryPart << "i" << endl;
        cout << "x2 = " << realPart << "-" << imaginaryPart << "i" << endl;
    }

    return 0;
}