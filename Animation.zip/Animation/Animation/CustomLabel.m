#import "CustomLabel.h"

@implementation CustomLabel

- (void)drawRect:(CGRect)rect;
{
    [super drawRect:rect];
    
    UIColor *centerColor = [UIColor magentaColor];
    UIColor *edgeColor = [UIColor whiteColor];
    CGFloat maxLength = MAX(rect.size.width, rect.size.height);
    CGFloat endRadius = maxLength / 2;
    
    // Create gradient with colors
    CGFloat locations[] = { 0.0, 1.0 };
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    NSArray *colors = @[(__bridge id)centerColor.CGColor, (__bridge id)edgeColor.CGColor];
    CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)colors, locations);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // Fill color and draw path gradient
    CGContextSaveGState(context);
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:rect];
    CGContextAddPath(context, [path CGPath]);
    CGContextClip(context);
    CGContextSetFillColorWithColor(context, edgeColor.CGColor);
    CGContextSetAlpha(context, 1.0f - self.contrast);
    CGContextFillPath(context);
    CGPoint center = CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
    CGContextDrawRadialGradient(context, gradient, center, 0, center, endRadius, 0);
    CGContextRestoreGState(context);
    
    CGGradientRelease(gradient);
    CGColorSpaceRelease(colorSpace);
}

@end
