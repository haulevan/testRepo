#import "CustomLabel.h"

@implementation CustomLabel

- (void)drawRect:(CGRect)rect;
{
    [super drawRect:rect];
    [self drawOverlayWithRect:rect isContrast:NO];
}

- (void)drawOverlayWithRect:(CGRect)rect isContrast:(BOOL)isContrast;
{
    UIColor *centerColor = [UIColor magentaColor];
    UIColor *edgeColor = [UIColor whiteColor];
    CGFloat maxLength = MAX(rect.size.width, rect.size.height);
    CGFloat endRadius = maxLength / 2;
    
    // Create gradient with colors
    CGFloat locations[] = { 0.0, 1.0 };
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    NSArray *colors = @[(__bridge id)centerColor.CGColor, (__bridge id)edgeColor.CGColor];
    CGGradientRef gradient = CGGradientCreateWithColors(colorSpace, (__bridge CFArrayRef)colors, locations);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // Fill color and draw path gradient
    CGContextSaveGState(context);
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:rect];
    CGContextAddPath(context, [path CGPath]);
    CGContextClip(context);
    CGContextSetFillColorWithColor(context, edgeColor.CGColor);
    CGContextSetAlpha(context, (isContrast ? self.contrast : 1.0f - self.contrast));
    CGContextFillPath(context);
    CGPoint center = CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
    CGContextDrawRadialGradient(context, gradient, center, 0, center, endRadius, 0);
    CGContextRestoreGState(context);
    
    CGGradientRelease(gradient);
    CGColorSpaceRelease(colorSpace);
}

- (UIImage *)imageByTextSize:(CGSize)textSize;
{
    CGFloat width = textSize.width;         // max 1024 due to Core Graphics limitations
    CGFloat height = textSize.height;       // max 1024 due to Core Graphics limitations
    CGRect rect = CGRectMake(0, 0, width, height);
    
    // Create a new bitmap image context
    UIGraphicsBeginImageContext(CGSizeMake(width, height));
    
    // Get context
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // Push context to make it current (need to do this manually because we are not drawing in a UIView)
    UIGraphicsPushContext(context);
    
    // Draw fill object
    [self drawOverlayWithRect:rect isContrast:YES];
    
    // Pop context
    UIGraphicsPopContext();
    
    // Get a UIImage from the image context
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    // Clean up drawing environment
    UIGraphicsEndImageContext();
    
    return image;
}

@end
