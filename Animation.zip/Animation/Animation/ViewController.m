//
//  ViewController.m
//  Animation
//
//  Created by Hayward on 6/22/16.
//  Copyright © 2016 Test. All rights reserved.
//

#import "ViewController.h"
#import "CustomLabel.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet CustomLabel *label;

@property (nonatomic, assign) NSInteger value;
@property (nonatomic, strong) NSTimer *timer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.value = 1;
    self.label.contrast = 0.4f;
    
    [self setupTimer];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setupTimer {
    self.label.text = [NSString stringWithFormat:@"%u", arc4random_uniform(999)];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.01f
                                                  target:self
                                                selector:@selector(updateLabel)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)updateLabel {
    
    self.label.contrast += 0.03 * self.value;
    [self.label setNeedsDisplay];
    
    if (self.label.contrast > 1.0f || self.label.contrast < 0.4f) {
        self.value *= -1;
        
        if (self.label.contrast > 1.0f) {
            [self performSelector:@selector(setupTimer) withObject:nil afterDelay:1.0f];
            [self.timer invalidate];
            self.timer = nil;
        }
    }
}

@end
