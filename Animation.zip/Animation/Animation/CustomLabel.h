#import <UIKit/UIKit.h>

@interface CustomLabel : UILabel

@property (nonatomic, assign) CGFloat contrast;

- (UIImage *)imageByTextSize:(CGSize)textSize;

@end
