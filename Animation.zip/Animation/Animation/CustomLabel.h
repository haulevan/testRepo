#import <UIKit/UIKit.h>

@interface CustomLabel : UILabel

@property (nonatomic, assign) CGFloat contrast;

@end
